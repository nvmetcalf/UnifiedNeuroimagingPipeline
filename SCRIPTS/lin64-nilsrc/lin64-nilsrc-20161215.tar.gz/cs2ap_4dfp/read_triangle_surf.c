/*$Header: /data/petsun4/data1/src_solaris/cs2ap_4dfp/RCS/read_triangle_surf.c,v 1.3 2011/05/11 00:12:51 avi Exp $*/
/*$Log: read_triangle_surf.c,v $
 * Revision 1.3  2011/05/11  00:12:51  avi
 * little endian CPU compliant
 *
 * Revision 1.2  2011/05/09  03:04:46  avi
 * *** empty log message ***
 *
 * Revision 1.1  2011/05/03  04:49:44  avi
 * Initial revision
 *
 * Revision 1.5  2010/12/29  03:09:52  avi
 * minor typo
 *
 * Revision 1.4  2010/12/29  03:04:03  avi
 * options -C and -o
 **/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <assert.h>
#include <math.h>
#include <endianio.h>
#include <Getifh.h>

#define MAXL		256

typedef struct {
	float	x, y, z;
} NODE;

/***********/
/* globals */
/***********/
static char	rcsid[] = "$Id: read_triangle_surf.c,v 1.3 2011/05/11 00:12:51 avi Exp $";
static char	program[MAXL];
static int	swab_flag;

int **calloc_int2 (int n1, int n2) {
	int	i;
	int	**a;

	if (!(a = (int **) malloc (n1 * sizeof (int *)))) errm (program);
	if (!(a[0] = (int *) calloc (n1 * n2, sizeof (int)))) errm (program);
	for (i = 0; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_int2 (int **a) {
	free (a[0]);
	free (a);
}

static int read4 (FILE *fp, char *ptr) {
	int	n;

	n = fread (ptr, 1, 4, fp);
	if (n != 4) return -1;
	if (swab_flag) swab4 (ptr);
	return 0;
}

static int read3 (FILE *fp, char *ptr) {
	int	n;

	n = fread (ptr + 1, 1, 3, fp);
	if (n != 3) return -1;
	if (swab_flag) swab4 (ptr);
	return 0;
}

static int read2 (FILE *fp, char *ptr) {
	int	n;

	n = fread (ptr, 1, 2, fp);
	if (n != 2) return -1;
	if (swab_flag) swab2 (ptr);
	return 0;
}

static int read1 (FILE *fp, char *ptr) {
	int	n;

	n = fread (ptr, 1, 1, fp);
	return (n == 1) ? 0 : -1;
}

int split (char *string, char *srgv[], int maxp) {
	int	i, m;
	char	*ptr;

	if (ptr = strchr (string, '#')) *ptr = '\0';
	i = m = 0;
	while (m < maxp) {
		while (!isgraph ((int) string[i]) && string[i]) i++;
		if (!string[i]) break;
		srgv[m++] = string + i;
		while (isgraph ((int) string[i])) i++;
		if (!string[i]) break;
		string[i++] = '\0';
	}
	return m;
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
	int		i;

	fprintf (outfp, "#%s", program);
	for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
	fprintf (outfp, "\n#%s\n", rcsid);
}

int main (int argc, char *argv[]) {
	FILE		*fp;
	char		*str, *srgv[MAXL], command[MAXL], string[MAXL];
	char		triangfil[MAXL], outroot[MAXL] = "", outfile[MAXL];

/************/
/* topology */
/************/
	int		nvertex = 0, nface = 0;
	NODE		node, *nodes;
	int		**faces;

/***********/
/* utility */
/***********/
	union {int k; unsigned char c[4];} byte4;
	int		c, i, j, k, k0, k1, m, l;

/*********/
/* flags */
/*********/
	int		V_flag = 0;
	int		C_flag = 0;
	int		debug = 0;
	int		status = 0;

	printf ("%s\n", rcsid);
	if (!(str = strrchr (argv[0], '/'))) str = argv[0]; else str++;
	strcpy (program, str);

/*********************************/
/* set global variable swab_flag */
/*********************************/
	swab_flag = (CPU_is_bigendian()) ? 0 : 1;

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); str = command;
			while (c = *str++) switch (c) {
				case 'd': debug++;			break;
				case 'V': V_flag++;			break;
				case 'C': C_flag++;			break;
				case 'o': strcpy (outroot, str);	*str = '\0'; break;
			}
		} else switch (k) {
			case 0: strncpy (triangfil, argv[i], MAXL - 1);	k++; break;
		}
	}
	if (k < 1) {
		printf ("Usage:\t%s <triangle surface file>)\n", program);
		printf (" e.g.:\t%s /data/nil-bluearc/corbetta/Hacker/Surfaces/FS_Output/rest_ctl_2/surf/rh.orig2\n", program);
		printf ("	[option]\n");
		printf ("	-o	specify output fileroot (default triangle surface fileroot)\n");
		printf ("	-V	create vtx file from surface file nodes\n");
		printf ("	-C	create Caret coord and topo files\n");
		exit (1);
	}

/******************/
/* read quad file */
/******************/
	fprintf (stdout, "Reading: %s\n", triangfil);
	if (!(fp = fopen (triangfil, "rb"))) errr (program, triangfil);

if (0) {
	for (i = 0; i < 8; i++) {
		if (read1 (fp, (char *) command)) errr (program, triangfil);
		printf ("%10d%10c\n", i, command[0]);
	}
	if (fclose (fp)) errr (program, triangfil);
	exit (0);
}

	k = 0; if (read3 (fp, (char *) &k)) errr (program, triangfil);
	if (debug) printf ("k=%d\n", k);
	if (k != 16777214) {
		fprintf (stderr, "%s: %s format error\n", program , triangfil);
		exit (-1);
	}
	k = 0; do {
		read1 (fp, string + k++);
	} while (string[k - 1] != '\n');
		read1 (fp, string + k++);	/* awlays a second '\n' */
	string[k] = '\0';
	if (0) printf ("k=%d\n", k);
	printf ("%s\n", string);
	read4 (fp, (char *) &nvertex);
	read4 (fp, (char *) &nface);
	printf ("nvertex=%d nface=%d\n", nvertex, nface);

	if (!(nodes = (NODE *) malloc (nvertex * sizeof (NODE)))) errm (program); 
	for (i = 0; i < nvertex; i++) {
		read4 (fp, (char *) &nodes[i].x);
		read4 (fp, (char *) &nodes[i].y);
		read4 (fp, (char *) &nodes[i].z);
		if (i < 10) printf ("%10d%10.4f%10.4f%10.4f\n", i, nodes[i].x, nodes[i].y, nodes[i].z);
	}

	faces = calloc_int2 (nface, 3);
	for (j = 0; j < nface; j++) {
		for (k = 0; k < 3; k++) read4 (fp, (char *) &faces[j][k]);
		if (j < 10) printf ("%10d%10d%10d%10d\n", j, faces[j][0], faces[j][1], faces[j][2]);
	}
	if (fclose (fp)) errr (program, triangfil);

/*******************/
/* compute outroot */
/*******************/
	if (!strlen (outroot)) {
		if (!(str = strrchr (triangfil, '/'))) str = triangfil; else str++;
		strcpy (outroot, str);
	}

	if (C_flag) {
/***************************/
/* output Caret coord file */
/***************************/
		sprintf (outfile, "%s.coord", outroot);
		fprintf (stdout, "Writing: %s\n", outfile);
		if (!(fp = fopen (outfile, "w"))) errr (program, outfile);
		fprintf (fp, "BeginHeader\ncoord_file\n");
		write_command_line (fp, argc, argv);
		fprintf (fp, "EndHeader\n");
		fprintf (fp, "%d\n", nvertex);
		for (i = 0; i < nvertex; i++) {
			fprintf (fp, "%8d%12.4f%12.4f%12.4f\n", i, nodes[i].x, nodes[i].y, nodes[i].z);
		}
		if (fclose (fp)) errw (program, outfile);
/**************************/
/* output Caret topo file */
/**************************/
		sprintf (outfile, "%s.topo", outroot);
		fprintf (stdout, "Writing: %s\n", outfile);
		if (!(fp = fopen (outfile, "w"))) errr (program, outfile);
		fprintf (fp, "BeginHeader\ntopo_file\n");
		write_command_line (fp, argc, argv);
		fprintf (fp, "EndHeader\ntag-version 1\n");
		fprintf (fp, "%d\n", nface);
		for (i = 0; i < nface; i++) {
			fprintf (fp, "%8d%8d%8d\n", faces[i][0], faces[i][1], faces[i][2]);
		}
		if (fclose (fp)) errw (program, outfile);
	}

	if (V_flag) {
/***************************************/
/* output nodes in 4-column vtx format */
/***************************************/
		sprintf (outfile, "%s.vtx", outroot);
		fprintf (stdout, "Writing: %s\n", outfile);
		if (!(fp = fopen (outfile, "w"))) errr (program, outfile);
		fprintf (fp, "%-12s%12s%12s%12s\n", "#vtx", "x", "y", "z");
		for (i = 0; i < nvertex; i++) {
			fprintf (fp, "%-12d%12.4f%12.4f%12.4f\n", i, nodes[i].x, nodes[i].y, nodes[i].z);
		}
		if (fclose (fp)) errw (program, outfile);
	}

	free (nodes);
	free_int2 (faces);
	exit (0);
}
