/*$Header: /data/petsun4/data1/src_solaris/gauss_4dfp/RCS/RSNs_fft_4dfp.c,v 1.1 2013/10/06 23:29:08 avi Exp $*/
/*$Log: RSNs_fft_4dfp.c,v $
 * Revision 1.1  2013/10/06  23:29:08  avi
 * Initial revision
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>
#include <librms.h>

#define MAXL      256	

/***********/
/* globals */
/***********/
static char	rcsid[] = "$Id: RSNs_fft_4dfp.c,v 1.1 2013/10/06 23:29:08 avi Exp $";
static char 	program[MAXL];

/*************/
/* externals */
/*************/
void		fft3d_ (float *imgt, int *nx, int *ny, int *nz, float *a, float *b, int *idir);		/* fft3d.f */
void		smoothf (float *f, int nxp, int nyp, int nzp, int nsmooth);				/* modelf.c */

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void usage (char* program) {
	printf ("Usage:\t%s <(4dfp) RSNs>\n", program);
	printf (" e.g.,\t%s mlp_RSNs\n", program);
	printf ("\toptions\n");
	printf ("\t-d\tdebug mode\n");
	printf ("\t-z\tzero-mean input\n");
	printf ("\t-@<b|l>\toutput big or little endian (default input endian)\n");
	printf ("\t-b<int>\tsmooth log(fft) specified number of times\n");
	exit (1);
}

int main (int argc, char **argv) {
	FILE 		*imgfp = NULL, *outfp = NULL;
	IFH		ifh;
	char 		imgroot[MAXL], imgfile[MAXL];
	char 		outroot[MAXL], outfile[MAXL];
	char		control = '\0';

        int  		imgdim[4], isbig;
        float	 	voxdim[3];	
	float		*imgt, *imgr, *imgp, *a, *b, *f, *w, theta;
	int		ix, iy, iz, nx, ny, nz;
	int		nxp, nyp, nzp, jndex, kndex;
	int		margin, vdim, pdim;
	int		posone = 1, negone = -1, nout = 0;
	int		nsmooth = 0;

/***********/
/* utility */
/***********/
	char 		command[MAXL], *ptr;
	int		c, i, j, k;
	float		t;

/*********/
/* flags */
/*********/
	int		debug = 0;
	int		status = 0;
	int		save_logFFT = 1;
	int		zero_mean = 0;

	fprintf (stdout, "%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]);
			ptr = command;
			while ((c = *ptr++)) switch (c) {
				case 'd': debug++;		break;
				case 'z': zero_mean++;		break;
				case 'b': nsmooth = atoi (ptr);	*ptr = '\0'; break;
				case '@': control = *ptr++;	*ptr = '\0'; break;
			}
		}
		else switch (k) {
			case 0:	getroot (argv[i], imgroot);	k++; break;
		}	
	}
	if (k < 1) usage (program);

/*******************************************/
/* get 4dfp dimensions and open read/write */
/*******************************************/
	sprintf (imgfile, "%s.4dfp.img", imgroot);
	printf ("Reading: %s\n", imgfile);
	if (Getifh (imgfile, &ifh)) errr (program, imgfile);
	for (k = 0; k < 4; k++) imgdim[k] = ifh.matrix_size[k];
	for (k = 0; k < 3; k++) voxdim[k] = ifh.scaling_factor[k];
	isbig = strcmp (ifh.imagedata_byte_order, "littleendian");
	if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);
	nx = imgdim[0];
	ny = imgdim[1];
	nz = imgdim[2];
	vdim = nx*ny*nz;
	margin = nx/4; nxp = npad_ (&nx, &margin);
	margin = ny/4; nyp = npad_ (&ny, &margin);
	margin = nz/4; nzp = npad_ (&nz, &margin);
	pdim = nxp*nyp*nzp;

/********************/
/* allocate buffers */
/********************/
	printf ("image dimensions %d %d %d padded to %d %d %d\n", nx, ny, nz, nxp, nyp, nzp);
	if (!(imgt = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgr = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgp = (float *) calloc (pdim, sizeof (float)))) errm (program);
	if (!(a =    (float *) calloc (pdim, sizeof (float)))) errm (program);
	if (!(b =    (float *) calloc (pdim, sizeof (float)))) errm (program);
	if (!(f =    (float *) calloc (pdim, sizeof (float)))) errm (program);

	if (!debug) printf ("reading volume");
	for (k = 0; k < imgdim[3]; k++) {
		if (!debug) {printf(" %d", k + 1); fflush (stdout);}
		if (eread (imgt, vdim, isbig, imgfp)) errr (program, imgfile);
		for (j = 1; j < 8; j++) {
			for (i = 0; i < vdim; i++) imgr[i] = (imgt[i] == (float) j) ? 1. : 0.;
			if (zero_mean) {
/*******************************/
/* make input images zero mean */
/*******************************/
				for (t = i = 0; i < vdim; i++) t += imgt[i];
				t /= vdim;
				for (i = 0; i < vdim; i++) imgt[i] -= t;
			}
			imgpad_ (imgt, &nx,  &ny,  &nz, imgp, &nxp, &nyp, &nzp);
			fft3d_  (imgp, &nxp, &nyp, &nzp, a, b, &negone);
			for (i = 0; i < pdim; i++) f[i] += a[i]*a[i] + b[i]*b[i];
		}
	}
	if (!debug) printf("\n");
	for (i = 0; i < pdim; i++) {
		f[i] /= 7*imgdim[3];
		f[i] = sqrt (f[i]);
	}

	if (0) {
		for (iz = 0; iz < nzp;   iz++) {
		for (iy = 0; iy < nyp;   iy++) {
		for (ix = 1; ix < nxp/2; ix++) {
			jndex = ix         + nxp*(iy + nyp*iz);
			kndex = (nxp - ix) + nxp*(iy + nyp*iz);
			f[jndex] = 0.5*(f[jndex] + f[kndex]);
			f[kndex] = f[jndex];
		}}}
		for (iz = 0; iz < nzp;   iz++) {
		for (iy = 1; iy < nyp/2; iy++) {
		for (ix = 0; ix < nxp;   ix++) {
			jndex = ix + nxp*(iy         + nyp*iz);
			kndex = ix + nxp*((nyp - iy) + nyp*iz);
			f[jndex] = 0.5*(f[jndex] + f[kndex]);
			f[kndex] = f[jndex];
		}}}
		for (iz = 1; iz < nzp/2; iz++) {
		for (iy = 0; iy < nyp;   iy++) {
		for (ix = 0; ix < nxp;   ix++) {
			jndex = ix + nxp*(iy + nyp*iz);
			kndex = ix + nxp*(iy + nyp*(nzp - iz));
			f[jndex] = 0.5*(f[jndex] + f[kndex]);
			f[kndex] = f[jndex];
		}}}
	}
	if (nsmooth) smoothf (f, nxp, nyp, nzp, nsmooth);

	if (save_logFFT) {
/********************************/
/* output fft3d as padded image */
/********************************/
		if (!(w = (float *) calloc (pdim, sizeof (float)))) errm (program);
		if (save_logFFT) {
			for (i = 0; i < pdim; i++) w[i] = log (f[i]);
			sprintf (outroot, "%s_logfft", imgroot);
		} else {
			for (i = 0; i < pdim; i++) w[i] = f[i];
			sprintf (outroot, "%s_fft", imgroot);
		}
		sprintf (outfile, "%s.4dfp.img", outroot);
		if (!(outfp = fopen (outfile, "wb"))) errw (program, outfile);
		if (!control) control = (isbig) ? 'b' : 'l';
		printf ("Writing: %s\n", outfile);
		if (ewrite (w, pdim, control, outfp)) errw (program, outfile);
		printf ("Writing: %s\n", outfile);
		ifh.matrix_size[0] = nxp;
		ifh.matrix_size[1] = nyp;
		ifh.matrix_size[2] = nzp;
		ifh.matrix_size[3] = 1;
		for (t = i = 0; i < pdim; i++) if (w[i] > t) t = w[i];
		if (Writeifh (program, outfile, &ifh, control)) errw (program, outroot);
		if (fclose (outfp)) errw (program, outfile);	
		sprintf (command, "ifh2hdr -r%d %s", (int) (t + 0.5), outroot);
		status |= system (command);
		free (w);
	}

DONE:	free (imgp); free (imgt); free (imgr); free (a); free (b); free (f);
	exit (status);
}
