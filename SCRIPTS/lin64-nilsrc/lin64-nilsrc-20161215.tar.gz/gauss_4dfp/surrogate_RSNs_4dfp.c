/*$Header: /data/petsun4/data1/src_solaris/gauss_4dfp/RCS/surrogate_RSNs_4dfp.c,v 1.3 2013/09/16 22:17:44 avi Exp avi $*/
/*$Log: surrogate_RSNs_4dfp.c,v $
 * Revision 1.3  2013/09/16  22:17:44  avi
 * correect operation of option -S
 *
 * Revision 1.2  2013/09/16  05:37:56  avi
 * options -s and -S
 *
 * Revision 1.1  2013/09/16  03:20:10  avi
 * Initial revision
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>
#include <librms.h>

#define MAXL      256	

/***********/
/* globals */
/***********/
static char	rcsid[] = "$Id: surrogate_RSNs_4dfp.c,v 1.3 2013/09/16 22:17:44 avi Exp avi $";
static char 	program[MAXL];

/*************/
/* externals */
/*************/
extern double	dnormal (void);
void		fft3d_ (float *imgt, int *nx, int *ny, int *nz, float *a, float *b, int *idir);		/* fft3d.f */
float		modelf (float *f, int nxp, int nyp, int nzp, float *betas);				/* modelf.c */
void		smoothf (float *f, int nxp, int nyp, int nzp, int nsmooth);				/* modelf.c */

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

float om (int ix, int nx) {
	return (ix <= nx/2) ? (float) ix : (float) (nx - ix);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void usage (char* program) {
	printf ("Usage:\t%s <4dfp|models>\n", program);
	printf (" e.g.,\t%s MLP_RLB100_avg_333 -n100\n", program);
	printf ("\toptions\n");
	printf ("\t-d\tdebug mode\n");
	printf ("\t-f\tsave estimated FFT\n");
	printf ("\t-A\tanalytically regularize FFT\n");
	printf ("\t-S\tenforce symmetry about yz plane in output surrogate RSNs\n");
	printf ("\t-@<b|l>\toutput big or little endian (default input endian)\n");
	printf ("\t-b<int>\tsmooth log(fft) specified number of times\n");
	printf ("\t-n<int>\tspecify number of surrogate outputs\n");
	printf ("\t-s<int>\tspecify random number generator seed\n");
	exit (1);
}

int main (int argc, char **argv) {
	FILE 		*imgfp = NULL, *outfp = NULL;
	IFH		ifh;
	char 		imgroot[MAXL], imgfile[MAXL];
	char 		outroot[MAXL], outfile[MAXL];
	char		control = '\0';

        int  		imgdim[4], isbig;
        float	 	voxdim[3];	
	float		*imgt, *imgp, *a, *b, *f, *w, theta;
	int		ix, iy, iz, nx, ny, nz;
	int		nxp, nyp, nzp, jndex, kndex;
	int		margin, vdim, pdim;
	int		posone = 1, negone = -1, nout = 0;
	long int	iseed = 1;

/*******************************/
/* analytic FFT regularization */
/*******************************/
	float		ox, oy, oz, betas[3], C;
	int		nsmooth = 0;

/***********/
/* utility */
/***********/
	char 		command[MAXL], *ptr;
	int		c, i, j, k;
	float		t;

/*********/
/* flags */
/*********/
	int		debug = 0;
	int		status = 0;
	int		save_FFT = 0;
	int		save_logFFT = 0;
	int		S_flag = 0;
	int		A_flag = 0;
	int		isreal;

	fprintf (stdout, "%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]);
			ptr = command;
			while ((c = *ptr++)) switch (c) {
				case 'd': debug++;		break;
				case 'f': save_FFT++;		break;
				case 'A': A_flag++;		break;
				case 'S': S_flag++;		break;
				case 's': iseed = atoi (ptr);	*ptr = '\0'; break;
				case 'b': nsmooth = atoi (ptr);	*ptr = '\0'; break;
				case 'n': nout = atoi (ptr);	*ptr = '\0'; break;
				case '@': control = *ptr++;	*ptr = '\0'; break;
			}
		}
		else switch (k) {
			case 0:	getroot (argv[i], imgroot);	k++; break;
		}	
	}
	if (k < 1) usage (program);

/*******************************************/
/* get 4dfp dimensions and open read/write */
/*******************************************/
	sprintf (imgfile, "%s.4dfp.img", imgroot);
	printf ("Reading: %s\n", imgfile);
	if (Getifh (imgfile, &ifh)) errr (program, imgfile);
	for (k = 0; k < 4; k++) imgdim[k] = ifh.matrix_size[k];
	for (k = 0; k < 3; k++) voxdim[k] = ifh.scaling_factor[k];
	isbig = strcmp (ifh.imagedata_byte_order, "littleendian");
	if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);
	nx = imgdim[0];
	ny = imgdim[1];
	nz = imgdim[2];
	vdim = nx*ny*nz;
	margin = nx/4; nxp = npad_ (&nx, &margin);
	margin = ny/4; nyp = npad_ (&ny, &margin);
	margin = nz/4; nzp = npad_ (&nz, &margin);
	pdim = nxp*nyp*nzp;

/********************/
/* allocate buffers */
/********************/
	printf ("image dimensions %d %d %d padded to %d %d %d\n", nx, ny, nz, nxp, nyp, nzp);
	if (!(imgt = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgp = (float *) calloc (pdim, sizeof (float)))) errm (program);
	if (!(a =    (float *) calloc (pdim, sizeof (float)))) errm (program);
	if (!(b =    (float *) calloc (pdim, sizeof (float)))) errm (program);
	if (!(f =    (float *) calloc (pdim, sizeof (float)))) errm (program);

	if (!debug) printf ("reading volume");
	for (k = 0; k < imgdim[3]; k++) {
		if (!debug) {printf(" %d", k + 1); fflush (stdout);}
		if (eread (imgt, vdim, isbig, imgfp)) errr (program, imgfile);
/*******************************/
/* make input images zero mean */
/*******************************/
		for (t = i = 0; i < vdim; i++) t += imgt[i];
		t /= vdim;
		for (i = 0; i < vdim; i++) imgt[i] -= t;
		imgpad_ (imgt, &nx,  &ny,  &nz, imgp, &nxp, &nyp, &nzp);
		fft3d_  (imgp, &nxp, &nyp, &nzp, a, b, &negone);
/*********************************************/
/* verify complex conjugate structure of FFT */
/*********************************************/
		if (debug) {
			for (iz = 0; iz < nzp; iz++) {
			for (iy = 0; iy < nyp; iy++) {
			for (ix = 0; ix < nxp; ix++) {
				jndex = ix         + nxp*(iy         + nyp*iz);
				kndex = (nxp - ix) + nxp*((nyp - iy) + nyp*(nzp - iz));
				isreal = (!ix || ix == nxp/2) && (!iy || iy == nyp/2) && (!iz || iz == nzp/2);
				if (isreal)
					printf ("%10d%10d%10d %10.1f %10.1f\n", ix, iy, iz, a[jndex], b[jndex]);
				if (fabs (b[jndex]) < 1.e-2)
					printf ("%10d%10d%10d %10.1f %10.1f\n", ix, iy, iz, a[jndex], b[jndex]);
				if (!ix || !iy || !iz) {
					printf ("%10d%10d%10d %10.1f %10.1f\n", ix, iy, iz, a[jndex], b[jndex]);
				} else {
					printf ("%10d%10d%10d %10.1f %10.1f%10d%10d%10d %10.1f %10.1f\n",
					ix, iy, iz, a[jndex], b[jndex], nxp - ix, nyp - iy, nzp - iz, a[kndex], b[kndex]);
				}
			}}}
		}
		for (i = 0; i < pdim; i++) f[i] += a[i]*a[i] + b[i]*b[i];
	}
	if (!debug) printf("\n");
	for (i = 0; i < pdim; i++) {
		f[i] /= imgdim[3];
		f[i] = sqrt (f[i]);
	}

	if (1) {
		for (iz = 0; iz < nzp;   iz++) {
		for (iy = 0; iy < nyp;   iy++) {
		for (ix = 1; ix < nxp/2; ix++) {
			jndex = ix         + nxp*(iy + nyp*iz);
			kndex = (nxp - ix) + nxp*(iy + nyp*iz);
			f[jndex] = 0.5*(f[jndex] + f[kndex]);
			f[kndex] = f[jndex];
		}}}
		for (iz = 0; iz < nzp;   iz++) {
		for (iy = 1; iy < nyp/2; iy++) {
		for (ix = 0; ix < nxp;   ix++) {
			jndex = ix + nxp*(iy         + nyp*iz);
			kndex = ix + nxp*((nyp - iy) + nyp*iz);
			f[jndex] = 0.5*(f[jndex] + f[kndex]);
			f[kndex] = f[jndex];
		}}}
		for (iz = 1; iz < nzp/2; iz++) {
		for (iy = 0; iy < nyp;   iy++) {
		for (ix = 0; ix < nxp;   ix++) {
			jndex = ix + nxp*(iy + nyp*iz);
			kndex = ix + nxp*(iy + nyp*(nzp - iz));
			f[jndex] = 0.5*(f[jndex] + f[kndex]);
			f[kndex] = f[jndex];
		}}}
	}

	if (A_flag) {
		C = modelf (f, nxp, nyp, nzp, betas);
		for (iz = 0; iz < nzp; iz++) { oz = iz - nzp/2.;
		for (iy = 0; iy < nyp; iy++) { oy = iy - nyp/2.;
		for (ix = 0; ix < nxp; ix++) { ox = ix - nxp/2.;
			jndex = ix + nxp*(iy + nyp*iz);
			t = C*cosh(betas[0]*ox)*cosh(betas[1]*oy)*cosh(betas[2]*oz);
if (0)			printf ("%10d%10d%10d%10.4f%10.4f\n", ix, iy, iz, log(f[jndex]), t);
			f[jndex] = exp (t);
		}}}
	}

	if (nsmooth) smoothf (f, nxp, nyp, nzp, nsmooth);

	save_logFFT = 1;
	if (save_FFT) {
/********************************/
/* output fft3d as padded image */
/********************************/
		if (!(w = (float *) calloc (pdim, sizeof (float)))) errm (program);
		if (save_logFFT) {
			for (i = 0; i < pdim; i++) w[i] = log (f[i]);
			sprintf (outroot, "%s_logfft", imgroot);
		} else {
			for (i = 0; i < pdim; i++) w[i] = f[i];
			sprintf (outroot, "%s_fft", imgroot);
		}
		sprintf (outfile, "%s.4dfp.img", outroot);
		if (!(outfp = fopen (outfile, "wb"))) errw (program, outfile);
		if (!control) control = (isbig) ? 'b' : 'l';
		printf ("Writing: %s\n", outfile);
		if (ewrite (w, pdim, control, outfp)) errw (program, outfile);
		printf ("Writing: %s\n", outfile);
		ifh.matrix_size[0] = nxp;
		ifh.matrix_size[1] = nyp;
		ifh.matrix_size[2] = nzp;
		ifh.matrix_size[3] = 1;
		for (t = i = 0; i < pdim; i++) if (w[i] > t) t = w[i];
		if (Writeifh (program, outfile, &ifh, control)) errw (program, outroot);
		if (fclose (outfp)) errw (program, outfile);	
		sprintf (command, "ifh2hdr -r%d %s", (int) (t + 0.5), outroot);
		status |= system (command);
		free (w);
	}

	printf ("nout=%d\n", nout);
	if (!nout) goto DONE;
/*****************************/
/* generate surrogate output */
/*****************************/
	srand48 (iseed);	/* initialize drand48() */
	sprintf (outroot, "%s_surr%d", imgroot, nout);
	sprintf (outfile, "%s.4dfp.img", outroot);
	printf ("Writing: %s\n", outfile);
	if (!(outfp = fopen (outfile, "wb"))) errw (program, outfile);
	if (!control) control = (isbig) ? 'b' : 'l';
	printf ("volume");
	for (k = 0; k < nout; k++) {printf(" %d", k + 1); fflush (stdout);
		for (iz = 0; iz <= nzp/2; iz++) {
		for (iy = 0; iy <  nyp;   iy++) {
		for (ix = 0; ix <  nxp;   ix++) {
			jndex = ix         + nxp*(iy         + nyp*iz);
			kndex = (nxp - ix) + nxp*((nyp - iy) + nyp*(nzp - iz));
			isreal = (!ix || ix == nxp/2) && (!iy || iy == nyp/2) && (!iz || iz == nzp/2);
			theta = (isreal) ? 0.0 : 2.*M_PI*drand48();
			a[jndex] = cos(theta)*f[jndex];
			b[jndex] = sin(theta)*f[jndex];
			if (ix && iy && iz) {
				a[kndex] =  a[jndex];
				b[kndex] = -b[jndex];
			}
		}}}
		fft3d_  (imgp, &nxp, &nyp, &nzp, a, b, &posone);
		imgdap_ (imgt, &nx, &ny, &nz, imgp, &nxp, &nyp, &nzp);
		if (S_flag) {
			for (iz = 0; iz < nz;   iz++) {
			for (iy = 0; iy < ny;   iy++) {
			for (ix = 0; ix < nx/2; ix++) {
				jndex = ix            + nx*(iy + ny*iz);
				kndex = (nx - ix - 1) + nx*(iy + ny*iz);
				imgt[kndex] = imgt[jndex];
			}}}
		}
		if (ewrite (imgt, vdim, control, outfp)) errw (program, outfile);
	}
	printf("\n");
	if (fclose (outfp)) errw (program, outfile);

/***************/
/* ifh hdr rec */
/***************/
	ifh.matrix_size[0] = nx;
	ifh.matrix_size[1] = ny;
	ifh.matrix_size[2] = nz;
	ifh.matrix_size[3] = nout;
	if (Writeifh (program, outfile, &ifh, control)) errw (program, outroot);
	sprintf (command, "ifh2hdr %s -r-1to1", outroot);
	status |= system (command);
	startrece (outfile, argc, argv, rcsid, control);
	catrec (imgfile);
	endrec ();

DONE:	free (imgp); free (imgt); free (a); free (b); free (f);
	exit (status);
}
