#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>

float modelf (float *f, int nxp, int nyp, int nzp, float *betas) {
	float	*logf, ox, oy, oz, betaxn, betayn, betazn, dloglogf, logFbar, logFhatbar, C;
	int	jndex, kndex, ix, iy, iz, pdim;
	int	i0 = 0, i1 = 3, n, iter;

	pdim = nxp*nyp*nzp;
	logf = (float *) calloc (pdim, sizeof (float));
	for (jndex = 0; jndex < pdim; jndex++) logf[jndex] = log(f[jndex]);
	
	betas[0] = betas[1] = betas[2] = 0.03; C = 1.;
	for (iter = 0; iter < 15; iter++) {
		printf ("betas,C %10.6f%10.6f%10.6f%10.6f\n", betas[0], betas[1], betas[2], C);
		logFbar = logFhatbar = betaxn = betayn = betazn = n = 0;
		for (iz = i0; iz < i1; iz++) { oz = iz - nzp/2.;
		for (iy = i0; iy < i1; iy++) { oy = iy - nyp/2.;
		for (ix = i0; ix < i1; ix++) { ox = ix - nxp/2.;
			jndex = ix + nxp*(iy + nyp*iz);
			kndex = jndex + 1;
			dloglogf = 2.*(logf[kndex] - logf[jndex])/(logf[kndex] + logf[jndex]);
			betaxn += dloglogf/tanh (betas[0]*(ox + 0.5));
			if (0) printf ("%5d%5d%5d dloglogf = %10.6f tanh = %10.6f\n", ix, iy, iz, dloglogf, tanh (betas[0]*(ox + 0.5)));
			kndex = jndex + nxp;
			dloglogf = 2.*(logf[kndex] - logf[jndex])/(logf[kndex] + logf[jndex]);
			betayn += dloglogf/tanh (betas[1]*(oy + 0.5));
			kndex = jndex + nxp*nyp;
			dloglogf = 2.*(logf[kndex] - logf[jndex])/(logf[kndex] + logf[jndex]);
			betazn += dloglogf/tanh (betas[2]*(oz + 0.5));
			logFbar += logf[kndex];
			logFhatbar += cosh(betas[0]*ox)*cosh(betas[1]*oy)*cosh(betas[2]*oz);
			n++;
		}}}
		betas[0] = betaxn/n;
		betas[1] = betayn/n;
		betas[2] = betazn/n;
		C = logFbar/logFhatbar;
	}
	free (logf);
	return C;
}

void smoothf (float *f, int nxp, int nyp, int nzp, int nsmooth) {
	float	*logf, *temp;
	int	jndex, kndex, ix, iy, iz, pdim, ismooth;

	if (nsmooth <= 0) return;
	pdim = nxp*nyp*nzp;
	logf = (float *) calloc (pdim, sizeof (float));
	temp = (float *) calloc (pdim, sizeof (float));
	for (jndex = 0; jndex < pdim; jndex++) logf[jndex] = log(f[jndex]);
	
	printf ("smoothing ");
	for (ismooth = 0; ismooth < nsmooth; ismooth++) {printf (" %d", ismooth + 1);
		for (iz = 0; iz < nzp; iz++) for (iy = 0; iy < nyp; iy++) {
			jndex = 0       + nxp*(iy + nyp*iz);
			temp[jndex] = logf[jndex];
			jndex = nxp - 1 + nxp*(iy + nyp*iz);
			temp[jndex] = logf[jndex];
			for (ix = 1; ix < nxp - 1; ix++) {
				jndex = ix + nxp*(iy + nyp*iz);
				temp[jndex] = 0.25*(logf[jndex - 1] + 2.*logf[jndex] + logf[jndex + 1]);
			}
		}
		for (jndex = 0; jndex < pdim; jndex++) logf[jndex] = temp[jndex];
		for (iz = 0; iz < nzp; iz++) for (ix = 0; ix < nxp; ix++) {
			jndex = ix + nxp*(0         + nyp*iz);
			temp[jndex] = logf[jndex];
			jndex = ix + nxp*((nyp - 1) + nyp*iz);
			temp[jndex] = logf[jndex];
			for (iy = 1; iy < nyp - 1; iy++) {
				jndex = ix + nxp*(iy + nyp*iz);
				temp[jndex] = 0.25*(logf[jndex - nxp] + 2.*logf[jndex] + logf[jndex + nxp]);
			}
		}
		for (jndex = 0; jndex < pdim; jndex++) logf[jndex] = temp[jndex];
		for (iy = 0; iy < nyp; iy++) for (ix = 0; ix < nxp; ix++) {
			jndex = ix + nxp*(iy + nyp*0);
			temp[jndex] = logf[jndex];
			jndex = ix + nxp*(iy + nyp*(nzp - 1));
			temp[jndex] = logf[jndex];
			for (iz = 1; iz < nzp - 1; iz++) {
				jndex = ix + nxp*(iy + nyp*iz);
				temp[jndex] = 0.25*(logf[jndex - nxp*nyp] + 2.*logf[jndex] + logf[jndex + nxp*nyp]);
			}
		}
		for (jndex = 0; jndex < pdim; jndex++) logf[jndex] = temp[jndex];
	}
	printf ("\n");
	for (jndex = 0; jndex < pdim; jndex++) f[jndex] = exp(logf[jndex]);
	free (logf); free (temp);
}
