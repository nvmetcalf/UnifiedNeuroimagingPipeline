/*$Id: imgreg_nifti.c,v 1.3 2010/08/11 20:04:30 coalsont Exp $*/
/*$Log: imgreg_nifti.c,v $
 * Revision 1.3  2010/08/11  20:04:30  coalsont
 * uses ->order to attempt to deal with non-transverse nifti
 *
 * Revision 1.2  2010/06/21  17:12:38  coalsont
 * changed to read only first frame, to not segfault on multiframe volumes
 *
 * Revision 1.1  2010/06/18  21:09:15  coalsont
 * Initial revision
 *
 * From imgreg_4dfp:
 *
 * Revision 1.15  2007/08/10  03:27:30  avi
 * eliminate f_init () and f_exit ()
 *
 * Revision 1.14  2007/05/04  01:39:42  avi
 * quiet gcc -Wall
 *
 * Revision 1.13  2006/09/26  19:25:43  avi
 * Solaris 10
 *
 * Revision 1.12  2004/12/06  21:02:31  rsachs
 * Reinstated #include <mri/ifh.h>.
 *
 * Revision 1.11  2004/09/24  19:31:23  rsachs
 * Installed 'errm','errr','errw','getroot','get_4dfp_dimo'. Removed 'Get4dfpDimN'.
 *
 * Revision 1.10  1999/02/03  08:16:33  avi
 * correct stdout center: listing
 *
 * Revision 1.9  1998/12/24  07:41:24  avi
 * remove #include <mri/mri.h>
 *
 * Revision 1.8  1998/12/23  07:18:12  avi
 * correct reading mask into image memory
 *
 * Revision 1.7  1998/12/14  07:51:22  avi
 * minor changes
 *
 * Revision 1.6  1998/12/12  22:37:34  avi
 * file_image -> imgroot
 * file_mask  -> mskroot
 * cleaner output t4file
 *
 * Revision 1.5  1998/12/12  22:05:30  avi
 * executes
 **/
/******************************************************************/
/*  Program:	        imgreg                                    */
/*  Description:	compute image-image registration (affinefile) */
/*  Authors:	        Avi Snyder                                */
/*  History:	        Jul-26-95                                 */
/*  SunOS -> Solaris:	12/98    AZS and Mark McAvoy              */
/******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <endianio.h>
#include <Getifh.h>
#include "common-format.h"
#include "nifti-format.h"
#include "transform.h"

#define MAXL	256
#define FIND	4096

/*************/
/* externals */
/*************/
extern void	tparam2warp_  (int *mode, float *params, float *t4);	/* t4_sub.f */
extern void	warp2tparam_  (int *mode, float *t4, float *params);	/* t4_sub.f */
extern void	ffind_   (float *img1, short *msk1, int *nx1, int *ny1, int *nz1, float *mmppix1, float *center1,
			  float *img2, short *msk2, int *nx2, int *ny2, int *nz2, float *mmppix2, float *center2, float *params, int *mode);
extern void	fimgreg_ (float *img1, short *msk1, int *nx1, int *ny1, int *nz1, float *mmppix1, float *center1,
			  float *img2, short *msk2, int *nx2, int *ny2, int *nz2, float *mmppix2, float *center2, float *params, int *mode);
	
void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void read_first_frame_float (common_format *file, float *stack) {
	int32_t temp = file->length[3];
	file->length[3] = 1;
	auto_orient((void*)stack, file, 0);
	file->length[3] = temp;
}

void read_affine(char* filename, float affine[3][4])
{
	FILE* fp = fopen(filename, "r");
	int read = 0, i, j;
	if (fp != NULL)
	{
		for (i = 0; i < 3; ++i)
		{
			read += fscanf(fp, "%f %f %f %f", &affine[i][0], &affine[i][1], &affine[i][2], &affine[i][3]);
		}
		fclose(fp);
	}
	if (read != 12)
	{
		for (i = 0; i < 3; ++i)
		{
			for (j = 0; j < 4; ++j)
			{
				affine[i][j] = 0.0f;
				if (i == j) affine[i][j] = 1.0f;
			}
		}
	}
}

int write_affine(char* filename, float affine[3][4])
{
	FILE* fp = fopen(filename, "w");
	int success = 1, i;
	if (fp != NULL)
	{
		for (i = 0; i < 3; ++i)
		{
			if (fprintf(fp, "%f %f %f %f\n", affine[i][0], affine[i][1], affine[i][2], affine[i][3]) < 0)
				success = 0;
		}
		if (fprintf(fp, "0 0 0 1\n") < 0)
			success = 0;
	}
	return !success;
}

static char rcsid[] = "$Id: imgreg_nifti.c,v 1.3 2010/08/11 20:04:30 coalsont Exp $";
int main (int argc, char **argv) {
/************/
/* imag I/O */
/************/
	FILE		*fp;
	char		command[MAXL];
	char		affinefile[MAXL], program[MAXL];
	char		imgroot[2][MAXL], mskroot[2][MAXL];

/**************/
/* processing */
/**************/
	float		param[13], t4[16];
	float		affine[3][4], invaffine[3][4];
	float		mmppix[2][3], center[2][3];
	common_format *images[2], *masks[2];
	char	revorder[4];
	float		*imag[2];
	short		*mask[2];
	int		mode;
	int		imgdim[4], mskdim[4], isbig, isbigm;
	int		nx[2], ny[2], nz[2], dimension, orientation, orientm;

/***********/
/* utility */
/***********/
	int		i, j, k;
	fprintf (stdout, "%s\n", rcsid);
	setprog (program, argv);

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') strcpy (command, argv[i]);
		 else switch (k) {
			case 0: getroot (argv[i], imgroot[0]);		k++; break;
			case 1: getroot (argv[i], mskroot[0]); 		k++; break;
			case 2: getroot (argv[i], imgroot[1]); 		k++; break;
			case 3: getroot (argv[i], mskroot[1]); 		k++; break;
			case 4: strcpy (affinefile,      argv[i]); 		k++; break;
			case 5: mode = atoi (argv[i]);			k++; break;
		}
	}
	if (k < 6) {
		printf ("Usage:\t%s target_imag target_mask source_imag source_mask affinefile mode\n", program);
		printf ("or:\t%s target_imag        none source_imag source_mask affinefile mode\n", program);
		printf ("or:\t%s target_imag        none source_imag        none affinefile mode\n", program);
		exit (1);
	}

/*********/
/* start */
/*********/
	for (j = 0; j < 2; j++) {
		/*sprintf (filespc, "%s.4dfp.img", imgroot[j]);
		if (get_4dfp_dimoe (filespc, imgdim, voxdim, &orientation, &isbig) < 0) errr (program, filespc);
		nx[j] = imgdim[0];
		ny[j] = imgdim[1];
		nz[j] = imgdim[2];
        	Getifh (filespc, ifh + j);//*/
		printf ("Reading image: %s\n", imgroot[j]);
		images[j] = parse_nifti(imgroot[j], 0);//no rec file open?
		to_lpi(images[j]);
		for (i = 0; i < 4; ++i)
		{
			revorder[images[j]->order[i]] = i;
		}
		printf ("dimensions:%9d%10d%10d\n", images[j]->length[0], images[j]->length[1], images[j]->length[2]);
		for (i = 0; i < 3; ++i) printf ("sform[%i]:   %10.4f%10.4f%10.4f%10.4f\n", i, images[j]->sform[i][0], images[j]->sform[i][1], images[j]->sform[i][2], images[j]->sform[i][3]);
		char oblique = 0;
		for (i = 0; !oblique && i < 3; ++i)
		{
			for (k = 0; k < 3; ++k)
			{
				if (images[j]->order[i] != k && images[j]->sform[i][k] != 0.0)
				{
					oblique = 1;
					break;
				}
			}
		}
		if (oblique)
		{
			fprintf(stderr, "Input volumes must not be oblique.\n");
			if (j)
			{
				free((void*)imag[0]);
				free((void*)mask[0]);
			}
			return -1;
		}
		dimension = images[j]->length[0] * images[j]->length[1] * images[j]->length[2];
		imag[j] = (float *) malloc (dimension * sizeof (float));
		mask[j]	= (short *) malloc (dimension * sizeof (short));
		if (!imag[j] || !mask[j]) errm (program);

		if (strcmp (mskroot[j], "none")) {
			/*sprintf (filespc, "%s.4dfp.img", mskroot[j]);
			get_4dfp_dimoe (filespc, mskdim, voxdim, &orientm, &isbigm);
        		Getifh (filespc, &ifhm);//*/
			masks[j] = parse_nifti(mskroot[j], 0);
			to_lpi(masks[j]);
			char mismatch = 0;
			for (i = 0; !mismatch && i < 3; i++)
			{
				if (images[j]->length[i] != masks[j]->length[i] || images[j]->order[i] != masks[j]->order[i])
				{
					mismatch = 1;
					break;
				}
				for (k = 0; k < 4; ++k)
				{
					if (images[j]->sform[i][k] - masks[j]->sform[i][k] > 0.0001)
					{
						mismatch = 1;
						break;
					}
				}
			}
			if (mismatch) {
				fprintf (stderr, "imgreg_4dfp: %s %s mismatch\n", imgroot[j], mskroot[j]);
				exit (-1);
			}
			printf ("Reading mask: %s", mskroot[j]);
			masks[j]->orientation ^= 1 << revorder[0];//inherent flips to match orientation 2
			masks[j]->orientation ^= 1 << revorder[1];//x and y anatomical, so RAI
			auto_orient_header(masks[j]);/* orient header to match voxel flips */
			masks[j]->orientation ^= 1 << revorder[0];//and some more quirkyness to match the actual data flips
			masks[j]->orientation ^= 1 << revorder[2];
			read_first_frame_float (masks[j], imag[j]);//because processing stream is ecat
			/*x4dfp2ecat (imag[j], imgdim, orientation);//*/
			k = 0;
			for (k = i = 0; i < dimension; i++) if ((mask[j][i] = (short) imag[j][i])) k++;
			printf (" (%d pixels)\n", k);
			//for (i = 0; i < dimension; i++) mask[j][i] = (short) imag[j][i];//twice?
		} else {
			for (i = 0; i < dimension; i++) mask[j][i] = 1;
		}
		images[j]->orientation ^= 1 << revorder[0];//inherent flips to match orientation 2
		images[j]->orientation ^= 1 << revorder[1];//x and y anatomical, so RAI
		auto_orient_header(images[j]);/* orient header to match voxel flips */
		images[j]->orientation ^= 1 << revorder[0];//and some more quirkyness to match the actual data flips
		images[j]->orientation ^= 1 << revorder[2];
		read_first_frame_float (images[j], imag[j]);
		/*if (x4dfp2ecat (imag[j], imgdim, orientation)) {
			fprintf (stderr, "fimgreg: %s orientation=%d not valid\n", imgroot[j], orientation);
			exit (-1);
		}//*/
	}

/****************/
/* access check */
/****************/
	if (!access (affinefile, R_OK) && access (affinefile, W_OK)) {
		fprintf (stderr, "%s has read but not write permission\n", affinefile);
		exit (-1);
 	}

/****************************/
/* read affinefile if it exists */
/****************************/
	//t4file2param_ (&mode, t4file, param);
	read_affine(affinefile, affine);//read
	invert_affine(affine, invaffine);//convert it to a t4 (inverse affine)
	for (i = 0; i < 3; ++i)//transcribe to linear array
		for (j = 0; j < 4; ++j)
			t4[i + j * 4] = invaffine[i][j];
	warp2tparam_(&mode, t4, param);//convert to whatever "param" is

/***********/
/* compute */
/***********/
	nx[0] = images[0]->length[images[0]->order[0]];//length is not changed by auto_orient_header
	ny[0] = images[0]->length[images[0]->order[1]];
	nz[0] = images[0]->length[images[0]->order[2]];
	nx[1] = images[1]->length[images[1]->order[0]];
	ny[1] = images[1]->length[images[1]->order[1]];
	nz[1] = images[1]->length[images[1]->order[2]];
	/* the horror: the registration functions rely on the 4dfp interpretation of mmppix and center */
	//step one: i and j axes are actually negative (after flips, spacings are +, -, -)
	/* satisfy 4dfp 1, -1, -1 spacing convention so slice number doesnt jump in some viewers */
	/* NOTE: orientation was already set up to change to 1, 1, 1 spacing, and quirks flip the x and z spacing again later, so x and y need flipping now */
	for (i = 0; i < 3; ++i)
	{//sform was fixed by auto_orient_header, don't need to use ->order
		mmppix[0][i] = images[0]->sform[i][i];
		mmppix[1][i] = images[1]->sform[i][i];
		center[0][i] = images[0]->sform[i][3];
		center[1][i] = images[1]->sform[i][3];
	}
	for (i = 0; i < 3; ++i)
	{//step two: flip center and add spacing
		center[0][i] = mmppix[0][i] - center[0][i];
		center[1][i] = mmppix[1][i] - center[1][i];
	}//step three: do vrtflip on x and z
	center[0][0] = center[0][0] - mmppix[0][0] * (nx[0] + 1);
	mmppix[0][0] = -mmppix[0][0];
	center[1][0] = center[1][0] - mmppix[1][0] * (nx[1] + 1);
	mmppix[1][0] = -mmppix[1][0];
	center[0][2] = center[0][2] - mmppix[0][2] * (nz[0] + 1);
	mmppix[0][2] = -mmppix[0][2];
	center[1][2] = center[1][2] - mmppix[1][2] * (nz[1] + 1);
	mmppix[1][2] = -mmppix[1][2];
	//Getifh actually gives + - - for the mmppix and center, ready for use
	//could condense these, but it is nice to keep the different levels of quirkiness separated
	printf("%i, %i, %i, %f, %f, %f, %f, %f, %f\n", nx[0], ny[0], nz[0], mmppix[0][0], mmppix[0][1], mmppix[0][2], center[0][0], center[0][1], center[0][2]);
	printf("%i, %i, %i, %f, %f, %f, %f, %f, %f\n", nx[1], ny[1], nz[1], mmppix[1][0], mmppix[1][1], mmppix[1][2], center[1][0], center[1][1], center[1][2]);
	if (mode & FIND) {
		ffind_   (imag[0], mask[0], &nx[0], &ny[0], &nz[0], mmppix[0], center[0],
	  		  imag[1], mask[1], &nx[1], &ny[1], &nz[1], mmppix[1], center[1], param, &mode);
 	} else {
		fimgreg_ (imag[0], mask[0], nx + 0, ny + 0, nz + 0, mmppix[0], center[0],
                          imag[1], mask[1], nx + 1, ny + 1, nz + 1, mmppix[1], center[1], param, &mode); 
 	}

/****************/
/* write affinefile */
/****************/
 	tparam2warp_ (&mode, param, t4);
	/*fp = fopen (affinefile, "w");
	for (k = 0; k < argc; k++) fprintf (fp, "%s ", argv[k]);
	fprintf (fp, "\n%s\nt4\n", rcsid);
	for (k = 0; k < 4; k++) fprintf (fp, "%10.6f%10.6f%10.6f%10.4f\n",t4[0+k],t4[4+k],t4[8+k],t4[12+k]);
	if (mode & 256) fprintf (fp, "scale:    %10.6f\n", param[12]);
	fclose (fp);*/
	for (i = 0; i < 3; ++i)//transcribe from linear array
		for (j = 0; j < 4; ++j)
			invaffine[i][j] = t4[i + j * 4];
	invert_affine(invaffine, affine);//convert it from a t4
	write_affine(affinefile, affine);//save


	for (j = 0; j < 2; j++) {
		free (imag[j]);
		free (mask[j]);
		free_common_format(images[j]);
		if (strcmp (mskroot[j], "none")) free_common_format(masks[j]);
	}
	return 0;
}
