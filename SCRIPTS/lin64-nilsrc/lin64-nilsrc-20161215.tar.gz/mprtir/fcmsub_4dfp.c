/*$Header: /data/petsun4/data1/src_solaris/mprtir/RCS/fcmsub_4dfp.c,v 1.1 2010/11/12 18:06:24 larsc Exp larsc $*/
/*$Log*/
static char rcsid[] = "$Id: fcmsub_4dfp.c,v 1.1 2010/11/12 18:06:24 larsc Exp larsc $";

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <float.h>
#include "fcmsub_4dfp.h"

static float	pct_thresh = PCT_THRESH;
static float	hard_crit = HARD_CRIT;
static float	axis_crit = AXIS_CRIT;
static int	fcm_force = FCM_FORCE;
void set_pct_thresh	(double f)	{pct_thresh = f;}
void set_hard_crit	(double f)	{hard_crit = f;}
void set_axis_crit	(double f)	{axis_crit = f;}
void set_fcm_force	(int i)		{fcm_force = i;}

static KDRU	kdru[MAXCAT];
static float	fv[MAXIMG][MAXCAT], range[MAXIMG], axlen[MAXCAT][MAXCAT];
static float	bias[MAXCAT] = {5.0, 0.8, 1.0};

void fcmset (int ncat, int nimg, float thresh[], float ceil[], float fv1[MAXIMG][MAXCAT]) {
	int		i1, i2, j, k;
	double		a, t;

	for (j = 0; j < nimg; j++) {
		range[j] = ceil[j] - thresh[j];
		for (k = 0; k < ncat; k++) fv[j][k] = fv1[j][k];
	}
	for (i1 = 0; i1 < ncat; i1++) for (i2 = 0; i2 < ncat; i2++) {
		for (a = j = 0; j < nimg; j++) {
			t = (fv[j][i1] - fv[j][i2]) / range[j];
			a += t*t;
		}
		axlen[i1][i2] = sqrt(a);
	}
}

/*static int kdrucmp (KDRU *d1, KDRU *d2) {return (d1->d  > d2->d)  ? 1 : -1;}
*/
static int kdrucmp (const void *d1, const void *d2) {return (((KDRU *)d1)->d  > ((KDRU *)d2)->d)  ? 1 : -1;}

void getdist2 (int ncat, int nimg, float *fimg) {
	int 		j, k;
	double		q, dist2;
	int		debug = 0;

	for (k = 0; k < ncat; k++) {
		for (dist2 = j = 0; j < nimg; j++) {
			q = kdru[k].r[j] = (fimg[j] - fv[j][k]) / range[j];
			dist2 += q * q;
		}
		kdru[k].k = k;
		kdru[k].d = dist2;
	}
}

void getku (int ncat, int nimg, float *fimg) {
	double		q;
	int 		i, j, k, debug = 0;

	getdist2 (ncat, nimg, fimg);
	qsort (kdru, ncat, sizeof (KDRU), kdrucmp);
	for (q = i = 0; i < ncat; i++) {
		kdru[i].u = (kdru[i].d > FLT_EPSILON*FLT_EPSILON) ? 1.0/kdru[i].d : FLT_MAX;
		q += kdru[i].u;
	}
	for (i = 0; i < ncat; i++) kdru[i].u /= q;
}

int onaxis (int ncat, int nimg, float *fimg) {
	double		q, qlow;
	int 		i1, i2, j1, j2, k;

	getdist2 (ncat, nimg, fimg);
	qlow = FLT_MAX;
	for (i1 = 0; i1 < ncat - 1; i1++) {
		for (i2 = i1 + 1; i2 < ncat; i2++) {
			q = sqrt(kdru[i1].d) + sqrt(kdru[i2].d) - axlen[kdru[i1].k][kdru[i2].k];
			if (q < qlow) {qlow = q; j1 = i1; j2 = i2;}
		}
	}
	if (qlow > axis_crit) return -1;
	k = (kdru[j1].d < kdru[j2].d) ? kdru[j1].k : kdru[j2].k;
	if (0) {
		printf ("fimg = {");
		for (j1 = 0; j1 < nimg; j1++) printf ("%10.2f", fimg[j1]);
		printf ("} ");
		for (i1 = 0; i1 < ncat; i1++) printf ("%5d%10.6f", kdru[i1].k, kdru[i1].d);
		printf (" k=%d\n", k);
	}
	return k;
}

void getudelu (int ncat, int nimg, float *fimg, float u[], float delu[MAXIMG][MAXCAT]) {
	double		g, f2, f[MAXCAT], delf[MAXIMG][MAXCAT], delg[MAXIMG];
	int 		i, j, k, debug = 0;

	getdist2 (ncat, nimg, fimg);
	for (j = 0; j < nimg; j++) delg[j] = 0.0;
	for (g = i = 0; i < ncat; i++) {
		f[i] = (kdru[i].d > FLT_EPSILON*FLT_EPSILON) ? 1.0/kdru[i].d : FLT_MAX;
		g += f[i];
	}
	for (i = 0; i < ncat; i++) {
		u[i] = kdru[i].u = f[i]/g;
		f2 = 2.0*f[i]*f[i];
		for (j = 0; j < nimg; j++) delg[j] += (delf[j][i] = -f2*kdru[i].r[j]);
	}
	for (i = 0; i < ncat; i++) {
		for (j = 0; j < nimg; j++) delu[j][i] = (delf[j][i] - f[i]*delg[j]/g)/(g*range[j]);
	}
}

int fcmget (int nimg, float *imag[], int dimension, float thresh[], float ceil[],
float fv1[MAXIMG][MAXCAT], int ncat, int verbose) {
	int 		i, j, k, go, iter, nvox;
	float		fimg[MAXIMG];
	float		percent[MAXIMG][MAXCAT];
	double		sum_uu[MAXCAT], sum_uuy[MAXIMG][MAXCAT];
	double		q, t, sum_uuh, memb_old, memb;
	int		test, debug = 0;

	fcmset (ncat, nimg, thresh, ceil, fv1);
	memb_old = iter = 0;
	do {
		for (k = 0; k < ncat; k++) {
			for (j = 0; j < nimg; j++) sum_uuy[j][k] = 0.0;
			sum_uu[k] = 0.0;
		}
		sum_uuh = nvox = 0;

		for (i = 0; i < dimension; i++) {
			for (test = j = 0; j < nimg; j++) {
				fimg[j] = t = imag[j][i];
				test |= (t < thresh[j] || t > ceil[j]);
			}
			if (test) continue;
			getku (ncat, nimg, fimg);
			nvox++;
			for (k = 0; k < ncat; k++) {
				t = kdru[k].u * kdru[k].u;
				if (!k) sum_uuh += t;
				sum_uu[kdru[k].k] += t;
				for (j = 0; j < nimg; j++) sum_uuy[j][kdru[k].k] += t * fimg[j];
			}
		}
		memb = sqrt (sum_uuh / nvox);
		for (go = k = 0; k < ncat; k++) for (j = 0; j < nimg; j++) {
			if (fcm_force || memb > memb_old) {
				fv1[j][k] = fv[j][k];
				fv [j][k] = sum_uuy[j][k] / sum_uu[k];
			} else {
				fv [j][k] = fv1[j][k];
			}
			percent[j][k] = 100.0 * (fv[j][k] - fv1[j][k]) / fv1[j][k];
			go |= (fabs (percent[j][k]) > pct_thresh);
		}
		if (verbose) {
			printf ("fcmget: iteration %d rms class membership %10.6f", iter, memb);
			for (k = 0; k < ncat; k++) {
				printf ("\n%2d", k + 1);
				for (j = 0; j < nimg; j++) printf ("%10.2f%8.2f", fv1[j][k], percent[j][k]);
			}
			printf ("\n");
		}
		memb_old = memb;
		iter++;
	} while (go);
	return iter;
}

void fuzzy2hard (int nimg, float *imag[], int dimension, float thresh[], float ceil[],
float fv1[MAXIMG][MAXCAT], int ncat, int ccount[], float *imgo) {
	int 		i, j, k, nvox;
	float		fimg[MAXIMG];
	double		u[MAXCAT], dist2[MAXCAT];
	double		q, sum_uuh;
	int		test, debug = 0;

	fcmset (ncat, nimg, thresh, ceil, fv1);
	for (k = 0; k < ncat; k++) ccount[k] = 0;
	sum_uuh = nvox = 0;
	for (i = 0; i < dimension; i++) {
		imgo[i] = 0;
		for (test = j = 0; j < nimg; j++) {
			fimg[j] = imag[j][i];
			test |= (fimg[j] < thresh[j] || fimg[j] > ceil[j]);
		}
		if (test) continue;
			
		getku (ncat, nimg, fimg);
		if ((q = kdru[0].u) > hard_crit) {
			imgo[i] = (float) kdru[0].k + 1;
			ccount[kdru[0].k]++;
			sum_uuh += q*q;
			nvox++;
		}
	}
	printf ("fuzzy2hard: nvox = %d rms class membership %10.6f\n", nvox, sqrt (sum_uuh / nvox));	
}

void axis2hard (int nimg, float *imag[], int dimension, float thresh[], float ceil[],
float fv1[MAXIMG][MAXCAT], int ncat, int ccount[], float *imgo) {
	float		fimg[MAXIMG];
	double		t;
	int 		i, j, k, nvox;
	int		test, debug = 0;

	if (axis_crit < FLT_EPSILON) return;

	fcmset (ncat, nimg, thresh, ceil, fv1);
	for (nvox = i = 0; i < dimension; i++) {
		if (imgo[i]) continue;
		for (test = j = 0; j < nimg; j++) {
			fimg[j] = t =  imag[j][i];
			test |= (t < thresh[j] || t > ceil[j]);
		}
		if (test) continue;
		if ((k = onaxis (ncat, nimg, fimg)) >= 0) {
			imgo[i] = (float) k + 1;
			ccount[k]++;
			nvox++;
		}
	}
	printf ("axis2hard: %d additional voxels assigned\n", nvox);	
}
