#define MAXL		256	/* maximum string length */
#define MAXCAT		8	/* maximum number of tissue classes */
#define	MAXIMG		4	/* maximum multispectral dimensionality */
#define NORDER		2	/* order of 3D polynomial gain field correction */
#define DIFFCRIT	0.02	/* fcm_fitgain3d convergence test change in gain field coefficient */
#define PCT_THRESH	0.5	/* fcmget convergence test threshold percent coordinate change */
#define HARD_CRIT	0.0	/* fuzzy2hard criterion class membership */
#define AXIS_CRIT	0.0	/* onaxis() inclusion threshold */
#define FCM_FORCE	0	/* when set fcmget continues despite mean class membership decrease */

typedef struct {
	int	k;
	double	d;
	double	r[MAXIMG];
	double	u;
} KDRU;

void set_pct_thresh	(double f);
void set_hard_crit	(double f);
void set_axis_crit	(double f);
void set_fcm_force	(int i);

void fcmset	(int ncat, int nimg, float thresh[], float ceil[], float fv1[MAXIMG][MAXCAT]);
void getdist2	(int ncat, int nimg, float *fimg);
void getku	(int ncat, int nimg, float *fimg);
int onaxis	(int ncat, int nimg, float *fimg);
void getudelu	(int ncat, int nimg, float *fimg, float u[], float delu[MAXIMG][MAXCAT]);
int fcmget	(int nimg, float *imag[], int dimension, float thresh[], float ceil[], float fv1[MAXIMG][MAXCAT], int ncat, int verbose);
void fuzzy2hard	(int nimg, float *imag[], int dimension, float thresh[], float ceil[], float fv1[MAXIMG][MAXCAT], int ncat, int ccount[], float *imgo);
void axis2hard	(int nimg, float *imag[], int dimension, float thresh[], float ceil[], float fv1[MAXIMG][MAXCAT], int ncat, int ccount[], float *imgo);
