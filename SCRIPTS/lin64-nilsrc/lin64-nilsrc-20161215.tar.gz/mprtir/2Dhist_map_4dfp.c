#include <stdlib.h>
#include <stdio.h>
#include <string.h> 
#include <math.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>

#define MAXL		256

void getrangef (char *string, float *minval, float *maxval) {
	char	*str;

	str = strstr (string, "to");
	if (str) {
		*str = '\0';
		*minval = atof (string);
		*maxval = atof (str + 2);
	} else {
		*minval = 0;
		*maxval = atof (string);
	}
}

void usage (char *program) {
	printf ("usage:\t%s <(4dfp)img1> <(4dfp)img2> <(4dfp)2Dhist_ROI> <(4dfp)outfile>\n", program);
	printf ("\tooptions\n");
	printf ("\t-m<(4dfp)mask>\tmask input using (non-zero voxels of) specified mask\n");
	printf ("\t-r<1|2>:[<float>to]<float>\tspecify voxel range for <img1> or <img2>\n");
	printf ("\t-@<b|l>\toutput big or little endian (default CPU endian)\n");
	exit (1);
}

static char rcsid[] = "$Id$";
int main (int argc, char *argv[]) {
	FILE 		*fp;
	char            in1root[MAXL];
	char            in2root[MAXL];
	char		hstroot[MAXL];
	char		outroot[MAXL];
	char		imgfile[MAXL];
	char		mskroot[MAXL] = "";
	char            program[MAXL], string[MAXL], *ptr;

	IFH		ifh;
	float		*img1, *img2, *mask, *hist, *imgo;
	int		img1dim[4], img2dim[4], dimension, nbin1, nbin2;
	float		vox1dim[3], vox2dim[3];
	float		img1max = 0, img2max = 0;
	float		img1min = 0, img2min = 0;
	float		binwid1, binwid2;
	int		isbig1 = 0, isbig2 = 0, isbigm = 0, isbigh = 0;
	int		orient1, orient2, orientm;
	char		control = '\0';

	int		c, i, j, k;
	int		status = 0;

	if (ptr = strrchr (argv[0], '/')) ptr++; else ptr = argv[0];
	strcpy (program, ptr);
	printf ("%s\n", rcsid);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) if (*argv[i] == '-') {
		strcpy (string, argv[i]); ptr = string;
		while (c = *ptr++) switch (c) {
			case 'm': getroot (ptr, mskroot);	*ptr = '\0'; break;
			case '@': control = *ptr++;	*ptr = '\0'; break;
			case 'r': j = atoi (ptr++);
				ptr++;		/* skip over ":" */
				switch (j) {
					case 1: getrangef (ptr, &img1min, &img1max);	break;
					case 2: getrangef (ptr, &img2min, &img2max);	break;
					default: usage (program);			break;
				}			*ptr = '\0'; break;
		}
	} else switch (k) {
		case 0: getroot (argv[i], in1root);	k++; break;
		case 1: getroot (argv[i], in2root);	k++; break;
		case 2: getroot (argv[i], hstroot);	k++; break;
		case 3: getroot (argv[i], outroot);	k++; break;
	}
	if (k < 4) usage (program);
	fprintf (stdout, "img1: %s\nimg2: %s\n", in1root, in2root);

	if (get_4dfp_dimoe (in1root, img1dim, vox1dim, &orient1, &isbig1) < 0) errr (program, in1root);
	if (get_4dfp_dimoe (in2root, img2dim, vox2dim, &orient2, &isbig2) < 0) errr (program, in2root);
	status = orient1 != orient2;
	for (k = 0; k < 4; k++) status |= (img1dim[k] != img2dim[k]);
	for (k = 0; k < 3; k++) status |= (fabs (vox1dim[k] - vox2dim[k]) > 0.0001);
	if (status) {
		fprintf (stderr, "%s: %s %s dimension mismatch\n", program, in1root, in2root);
		exit (-1);
	}
	if (Getifh (hstroot, &ifh)) errr (program, hstroot);
	isbigh = !strcmp (ifh.imagedata_byte_order, "bigendian");
	if (!ifh.matrix_size[0] || !ifh.matrix_size[1]) {
		fprintf (stderr, "%s: %s has dimensions %d by %d\n", program, hstroot, ifh.matrix_size[0], ifh.matrix_size[1]);
		exit (0);
	}
	nbin1 = ifh.matrix_size[0];
	if (!img1max && !img1min) {
		binwid1 = ifh.scaling_factor[0];
		img1min = -ifh.center[0];
		img1max = img1min + binwid1 * nbin1;
	} else {
		binwid1 = (img1max - img1min) / nbin1;
	}
	nbin2 = ifh.matrix_size[1];
	if (!img2max && !img2min) {
		binwid2 = ifh.scaling_factor[1];
		img2min = -ifh.center[1];
		img2max = img2min + binwid2 * nbin2;
	} else {
		binwid2 = (img2max - img2min) / nbin2;
	}

	dimension = img1dim[0] * img1dim[1] * img1dim[2];

	img1 = (float *) malloc (dimension * sizeof (float));
	img2 = (float *) malloc (dimension * sizeof (float));
	mask = (float *) malloc (dimension * sizeof (float));
	imgo = (float *) calloc (dimension,  sizeof (float));
	hist = (float *) malloc (ifh.matrix_size[0] * ifh.matrix_size[1] * sizeof (float));
	if (!img1 || !img2 || !mask || !hist || !imgo) errm (program);

	if (strlen (mskroot)) {
		sprintf (imgfile, "%s.4dfp.img", mskroot);
		if (get_4dfp_dimoe (mskroot, img2dim, vox2dim, &orientm, &isbigm) < 0) errr (program, mskroot);
		status = orient1 != orientm;
		for (k = 0; k < 3; k++) status |= (img2dim[k] != img2dim[k]);
		for (k = 0; k < 3; k++) status |= (fabs (vox1dim[k] - vox2dim[k]) > 0.0001);
		if (status) {
			fprintf (stderr, "%s: %s %s dimension mismatch\n", program, in1root, mskroot);
			exit (-1);
		}
		printf ("Reading: %s\n", imgfile);
		if (!(fp = fopen (imgfile, "rb")) || eread (mask, dimension, isbigm, fp) || fclose (fp)) errr (program, imgfile);
	} else {
		for (i = 0; i < dimension; i++) mask[i] = 1;
	}

	sprintf (imgfile, "%s.4dfp.img", outroot); startrece (imgfile, argc, argv, rcsid, control);
	sprintf (imgfile, "%s.4dfp.img", in1root); catrec (imgfile);
	if (strlen (mskroot)) {sprintf (imgfile, "%s.4dfp.img", mskroot); catrec (imgfile);}
	printf ("Reading: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "rb")) || eread (img1, dimension, isbig1, fp) || fclose (fp)) errr (program, imgfile);
	sprintf (imgfile, "%s.4dfp.img", in2root); catrec (imgfile);
	printf ("Reading: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "rb")) || eread (img2, dimension, isbig2, fp) || fclose (fp)) errr (program, imgfile);
	sprintf (imgfile, "%s.4dfp.img", hstroot); catrec (imgfile);
	if (!(fp = fopen (imgfile, "rb")) || eread (hist, nbin1*nbin2, isbigh, fp) || fclose (fp)) errr (program, imgfile);

	for (k = 0; k < dimension; k++) if (mask[k]) {
		i = (int) ((img1[k] - img1min) / binwid1);
		j = (int) ((img2[k] - img2min) / binwid2);
		if (i < 0 || i >= nbin1 || j < 0 || j >= nbin2) continue;
		imgo[k] = hist[nbin1 * j + i];
	}

	sprintf (imgfile, "%s.4dfp.img", outroot); fprintf (stdout, "Writing: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "wb")) || ewrite (imgo, dimension, control, fp) || fclose (fp)) errw (program, imgfile);

	if (writeifhe (program, outroot, img1dim, vox1dim, orient1, control)) errw (program, outroot);

	sprintf (string, "ifh2hdr %s", outroot);
	system (string);

	free (img1); free (img2); free (imgo);
	free (hist); free (mask);
	endrec ();

	exit (status);
}
	
