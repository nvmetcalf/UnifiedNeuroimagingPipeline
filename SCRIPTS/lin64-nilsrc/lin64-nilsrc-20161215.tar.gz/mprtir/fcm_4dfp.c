/*$Header: /data/petsun4/data1/src_solaris/mprtir/RCS/fcm_4dfp.c,v 1.1 2010/11/12 18:06:03 larsc Exp larsc $*/
/*$Log: fcm_4dfp.c,v $
 * Revision 1.1  2010/11/12  18:06:03  larsc
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <string.h> 
#include <math.h>
#include <float.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>
#include "fcmsub_4dfp.h"

static char rcsid[] = "$Id: fcm_4dfp.c,v 1.1 2010/11/12 18:06:03 larsc Exp larsc $";
int main (int argc, char *argv[]) {
	/* image I/O */
	FILE		*imgfp, *lstfp;
	char		imgroot[MAXIMG][MAXL], outroot[MAXL] = "", recfile[MAXL], filespc[MAXL];

	/* image */
	int		nx, ny, nz, dimension, isbig[MAXIMG], imgdim[4], imgdimt[4], orient, orientt;
	float		*img[MAXIMG], *imgo, voxdim[3], voxdimt[3];
	float		imgmax, imgmin;

	/* fcm */
	char		lstfile[MAXL], fcmfile[MAXL];
	int		ncat = 0, nimg = 0, ccount[MAXCAT], excluded;
	float		thresh[MAXIMG], ceil[MAXIMG], fv[MAXIMG][MAXCAT];
	float		weight[MAXIMG], maxweight;
	double		sxx, sx;

	/* utility */
	int 		t, i, j, k, iter;
	char		*str, string[MAXL], program[MAXL], control = '\0';

	/* flags */
	int		debug = 0;
	int		verbose = 1;
	int		status = 0;
	int		norm_flag = 0;

	printf ("%s\n", rcsid);
	if (!(str = strrchr (argv[0], '/'))) str = argv[0]; else str++;
	strcpy (program, str);

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) if (*argv[i] == '-') {
		strncpy (string, argv[i], MAXL); str = string;
		while (t = *str++) {
			switch (t) {
				case 'n': norm_flag++;	break;
				case '@': control = *str++;     *str = '\0'; break;
			}
		}
	} else switch (k) {
		case 0: strncpy (lstfile, argv[i], MAXL); k++;  break;
		case 1: strncpy (fcmfile, argv[i], MAXL); k++;  break;
		case 2: getroot (argv[i], outroot);       k++;	break;
	}
	if (k < 2) {
		fprintf (stderr, "Usage:\t%s [options] <lstfile> <fcmfile> [<(4dfp)outroot>]\n", program);
		fprintf (stderr, " e.g.,\t%s vm6_mpr_tse3_gfc.lst mpr_tse3_gfc.fcm\n", program);
		fprintf (stderr, "\toptions\n");
		fprintf (stderr, "\t-n\tset image weights inversely proportional to standard deviation\n");
		fprintf (stderr, "\t-@<b|l>\toutput big or little endian (default first input endian)\n");
		fprintf (stderr, " N.B.: default outroot = lstroot\"_fcm\"\n");
		exit (1);
	}
	if (!strlen (outroot)) {
		strcpy (outroot, lstfile);
		if (str = strchr (outroot, '.')) *str = '\0';
		strcat (outroot, "_fcm");
	}

	if (!(lstfp = fopen (lstfile, "r"))) errr (program, lstfile);
	while (nimg < MAXIMG) {
/********************************************/
/* parse out filename extensions if present */
/********************************************/
/*		if (fscanf (lstfp, "%s %f %f", string, thresh + nimg, ceil + nimg) != 3) break;
*/		if ((k = fscanf (lstfp, "%s %f %f %f", string, thresh + nimg, ceil + nimg, weight + nimg)) < 3) break;
		if (k < 4) weight[nimg] = 1;
		getroot (string, imgroot[nimg]);
/******************/
/* read input ifh */
/******************/
		if (nimg == 0) {
			if (get_4dfp_dimoe (imgroot[nimg], imgdim,  voxdim,  &orient,  isbig+nimg)) errr (program, imgroot[nimg]);
			if (!control) control = (*isbig) ? 'b' : 'l';
		}
		else {
			if (get_4dfp_dimoe (imgroot[nimg], imgdimt, voxdimt, &orientt, isbig+nimg)) errr (program, imgroot[nimg]);
			for (k = 0; k < 3; k++) status |= (imgdim[k] != imgdimt[k]);
			for (k = 0; k < 3; k++) status |= (fabs (voxdim[k] - voxdimt[k]) > 0.0001);
			if (status) {
				fprintf (stderr, "%s: %s %s dimension mismatch\n", program, imgroot[nimg], imgroot[0]);
				exit (-1);
			}
		}
		nimg++;
	}
	fclose (lstfp);

/********************************/
/* read fcm initialization file */
/********************************/
	if (!(lstfp = fopen (fcmfile, "r"))) errr (program, fcmfile);
	while (ncat < MAXCAT) {
		for (j = 0; j < nimg; j++) {
			k = fscanf (lstfp, "%s", string);
			if (k < 1) break;
			if (str = strchr (string, 'x')) *str = '\0';
			sscanf (string, "%f", &fv[j][ncat]);
		}
		if (k < 1) break;
		ncat++;
	} 
	fclose (lstfp);

/*****************/
/* alloc buffers */
/*****************/
	nx = imgdim[0];
	ny = imgdim[1];
	nz = imgdim[2];
	dimension = nx * ny * nz;
	for (j = 0; j < nimg; j++) if (!(img[j] = (float *) malloc (dimension * sizeof (float)))) errm (program);
	if (!(imgo = (float *) malloc (dimension * sizeof (float)))) errm (program);
       
/***************/
/* read images */
/***************/
	for (j = 0; j < nimg; j++) {
		sprintf (filespc, "%s.4dfp.img", imgroot[j]);
		if (!(imgfp = fopen (filespc, "rb")) || eread (img[j], dimension, isbig[j], imgfp) || fclose (imgfp)) errr (program, filespc);
	}

/********************************************************/
/* find weights and normalize images and related values */
/********************************************************/
	if (norm_flag) {
		for (maxweight = j = 0; j < nimg; j++) {
			for (sxx = sx = k = 0; k < dimension; k++) {sx += img[j][k]; sxx += img[j][k] * img[j][k];}
			weight[j] = (float) sqrt (dimension / (sxx - sx*sx / dimension));
			if (weight[j] > maxweight) maxweight = weight[j];
		}
		for (j = 0; j < nimg; j++) weight[j] /= maxweight;
	}
	printf ("Applying weights\n");
	for (j = 0; j < nimg; j++) {
		printf ("%10d%10.6f\n", j+1, weight[j]);
		for (k = 0; k < dimension; k++) img[j][k] *= weight[j];
		for (k = 0; k < ncat; k++) fv[j][k] *= weight[j];
		thresh[j] *= weight[j];
		ceil[j]   *= weight[j];
	}

/******************************/
/* compute global class means */
/******************************/
	iter = fcmget (nimg, img, dimension, thresh, ceil, fv, ncat, 1);

/*********************************/
/* compute hard class membership */
/*********************************/
	fuzzy2hard (nimg, img, dimension, thresh, ceil, fv, ncat, ccount, imgo);
	printf ("hard class counts\n");
	for (excluded = dimension, k = 0; k < ncat; k++) {
		excluded -= ccount[k];
		printf ("%10d%10d\n", k + 1, ccount[k]);
	}
	printf ("  excluded%10d\n", excluded);

/**********************/
/* write segmentation */
/**********************/
/*	for (k = 0; k < dimension; k++) imgo[k] *= 1000;
*/	sprintf (filespc, "%s.4dfp.img", outroot);
	fprintf (stderr, "Writing: %s\n", filespc);
	if (!(imgfp = fopen (filespc, "wb")) || ewrite (imgo, dimension, control, imgfp) || fclose (imgfp)) errw (program, filespc);

	startrec (filespc, argc, argv, rcsid);
	printrec ("lstfile\n"); catrec (lstfile); printrec ("endlstfile\n");
	printrec ("fcmfile\n"); catrec (fcmfile); printrec ("endfcmfile\n");
	sprintf (string, "output         count");					printrec (string);
	for (k = 0; k < ncat; k++) {
		sprintf (string, "\nclass%5d%10d", k + 1, ccount[k]);			printrec (string);
		for (j = 0; j < nimg; j++) {sprintf (string, "%10.4f", fv[j][k]);	printrec (string);}
	}
	sprintf (string, "\nexcluded  %10d\n", excluded);				printrec (string);
	endrec ();

	
	imgdim[4] = 1;
	sprintf (filespc, "%s.4dfp.ifh", outroot);
	if (writeifhe (program, filespc, imgdim, voxdim, orient, control)) errw (program, filespc);
	
	sprintf (string, "ifh2hdr %s -r%dto%d", outroot, 0, ncat);
	system (string);

	for (j = 0; j < nimg; j++) free (img[j]);
	free (imgo);
	exit (0);
}
