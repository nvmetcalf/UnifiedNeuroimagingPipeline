/*$Header: /data/petsun4/data1/src_solaris/mprtir/RCS/2Dhist_4dfp.c,v 1.2 2012/02/11 00:49:52 avi Exp avi $*/
/*$Log: 2Dhist_4dfp.c,v $
 * Revision 1.2  2012/02/11  00:49:52  avi
 * revisions by Lars
 *
 * Revision 1.1  2010/11/12  18:05:04  larsc
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <string.h> 
#include <math.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>
#include <flip_4dfp.h>

#define MAXL		256
#define NBIN		256
#define CUM_D		0.000005
#define TRANSVERSE	2
#define MAXFLOAT	1.e37

void getrangef (char *string, float *minval, float *maxval) {
	char	*str;

	str = strstr (string, "to");
	if (str) {
		*str = '\0';
		*minval = atof (string);
		*maxval = atof (str + 2);
	} else {
		*minval = 0;
		*maxval = atof (string);
	}
}

void usage (char *program) {
	printf ("usage:\t%s <(4dfp)img1> <(4dfp)img2> <(4dfp)2Dhist_out>\n", program);
	printf ("\tooptions\n");
	printf ("\t-g\tsuppress grid burn-in\n");
	printf ("\t-m<(4dfp)mask>\tmask input using (non-zero voxels of) specified mask\n");
	printf ("\t-n<int>\tspecify bin number (default %d)\n", NBIN);
	printf ("\t-r<1|2>:[<float>to]<float>\tspecify usable voxel value range for <img1> or <img2>\n");
	printf ("\t-a\tdisable range adjust\n");
	printf ("\t-t\toutput histogram text file\n");
	printf ("\t-@<b|l>\toutput big or little endian (default CPU endian)\n");
	printf ("e.g.,\t%s va1701_tir_ecatt va1701_mpr_S va1701_tir_mpr_2Dhist\n", program);
	printf ("e.g.,\t%s va1701_tir_ecatt va1701_mpr_S va1701_tir_mpr_2Dhist -r1:0to2500\n", program);
	printf ("e.g.,\t%s va1701_tir_ecatt va1701_mpr_S va1701_tir_mpr_2Dhist -r1:2500\n", program);
	exit (1);
}

static char rcsid[] = "$Id: 2Dhist_4dfp.c,v 1.2 2012/02/11 00:49:52 avi Exp avi $";
int main (int argc, char *argv[]) {
	FILE 		*fp;
	char            in1root[MAXL];
	char            in2root[MAXL];
	char		outroot[MAXL];
	char		imgfile[MAXL];
	char		mskroot[MAXL] = "";
	char            program[MAXL], string[MAXL], *ptr;

	float		*img1, *img2, *mask, *imgo;
	int		img1dim[4], img2dim[4], dimension;
	float		vox1dim[3], vox2dim[3], center[3];
	float		img1max = 0, img2max = 0;
	float		img1min = 0, img2min = 0;
	int		isbig1 = 0, isbig2 = 0, isbigm = 0;
	int		orient1, orient2, orientm;
	char		control = '\0';

	int		nbin = NBIN, ONE = 1;
	int		*hist;
	int		*mrg1, *mrg2;
	int		histmax = 0;
	float		range1, range2;
	float		binwid1, binwid2;
	float		grid1, grid2, ftmp;
	float		valmax = 0;

	int		c, i, j, k;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		debug = 0;
	int		do_grid = 1;
	int		text_flag = 0;
	int		fix_flag = 0;

	if (ptr = strrchr (argv[0], '/')) ptr++; else ptr = argv[0];
	strcpy (program, ptr);
	printf ("%s\n", rcsid);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) if (*argv[i] == '-') {
		strcpy (string, argv[i]); ptr = string;
		while (c = *ptr++) switch (c) {
			case 'd': debug++;			break;
			case 'g': do_grid = 0;			break;
			case 'm': getroot (ptr, mskroot);	*ptr = '\0'; break;
			case 'n': nbin = atoi (ptr++);		*ptr = '\0'; break;
			case 't': text_flag++;			break;
			case 'a': fix_flag++;			break;
			case '@': control = *ptr++;		*ptr = '\0'; break;
			case 'r': j = atoi (ptr++);
				ptr++;		/* skip over ":" */
				switch (j) {
					case 1: getrangef (ptr, &img1min, &img1max);	break;
					case 2: getrangef (ptr, &img2min, &img2max);	break;
					default: usage (program);			break;
				}				*ptr = '\0'; break;
		}
	} else switch (k) {
		case 0: getroot (argv[i], in1root);	k++; break;
		case 1: getroot (argv[i], in2root);	k++; break;
		case 2: getroot (argv[i], outroot);	k++; break;
	}
	if (k < 3) usage (program);
	fprintf (stdout, "img1: %s\nimg2: %s\n", in1root, in2root);

	if (get_4dfp_dimoe (in1root, img1dim, vox1dim, &orient1, &isbig1) < 0) errr (program, in1root);
	if (get_4dfp_dimoe (in2root, img2dim, vox2dim, &orient2, &isbig2) < 0) errr (program, in2root);
	status = orient1 != orient2;
	for (k = 0; k < 4; k++) status |= (img1dim[k] != img2dim[k]);
	for (k = 0; k < 3; k++) status |= (fabs (vox1dim[k] - vox2dim[k]) > 0.0001);
	if (status) {
		fprintf (stderr, "%s: %s %s dimension mismatch\n", program, in1root, in2root);
		exit (-1);
	}

	dimension = img1dim[0] * img1dim[1] * img1dim[2];
	img1 = (float *) malloc (dimension * sizeof (float));
	img2 = (float *) malloc (dimension * sizeof (float));
	mask = (float *) malloc (dimension * sizeof (float));
	mrg1 = (int *) calloc (nbin, sizeof (int));
	mrg2 = (int *) calloc (nbin, sizeof (int));
	hist = (int *) calloc (nbin*nbin, sizeof (int));
	imgo = (float *) malloc (nbin*nbin * sizeof (float));
	if (!img1 || !img2 || !mask || !hist || !mrg1 || !mrg2 || !imgo) errm (program);

	if (strlen (mskroot)) {
		sprintf (imgfile, "%s.4dfp.img", mskroot);
		if (get_4dfp_dimoe (mskroot, img2dim, vox2dim, &orientm, &isbigm) < 0) errr (program, mskroot);
		status = orient1 != orientm;
		for (k = 0; k < 3; k++) status |= (img2dim[k] != img2dim[k]);
		for (k = 0; k < 3; k++) status |= (fabs (vox1dim[k] - vox2dim[k]) > 0.0001);
		if (status) {
			fprintf (stderr, "%s: %s %s dimension mismatch\n", program, in1root, mskroot);
			exit (-1);
		}
		printf ("Reading: %s\n", imgfile);
		if (!(fp = fopen (imgfile, "rb")) || eread (mask, dimension, isbigm, fp) || fclose (fp)) errr (program, imgfile);
	} else {
		for (i = 0; i < dimension; i++) mask[i] = 1;
	}

	sprintf (imgfile, "%s.4dfp.img", outroot); startrece (imgfile, argc, argv, rcsid, control);
	sprintf (imgfile, "%s.4dfp.img", in1root); catrec (imgfile);
	printf ("Reading: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "rb")) || eread (img1, dimension, isbig1, fp) || fclose (fp)) errr (program, imgfile);
	sprintf (imgfile, "%s.4dfp.img", in2root); catrec (imgfile);
	printf ("Reading: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "rb")) || eread (img2, dimension, isbig2, fp) || fclose (fp)) errr (program, imgfile);
	if (strlen (mskroot)) {sprintf (imgfile, "%s.4dfp.img", mskroot); catrec (imgfile);}

	if (!img1max && !img1min) {
		img1max = -MAXFLOAT; img1min = MAXFLOAT;
		for (i = 0; i < dimension; i++) if (mask[i]) {
			if (img1[i] > img1max) img1max = img1[i];
			if (img1[i] < img1min) img1min = img1[i];
		}
	} else {
		for (i = 0; i < dimension; i++) if (mask[i]) {
			if (img1[i] > img1max) img1[i] = img1max;
			if (img1[i] < img1min) img1[i] = img1min;
		}
	}
	range1 = img1max - img1min;
	if (!img2max && !img2min) {
		img2max = -MAXFLOAT; img2min = MAXFLOAT;
		for (i = 0; i < dimension; i++) if (mask[i]) {
			if (img2[i] > img2max) img2max = img2[i];
			if (img2[i] < img2min) img2min = img2[i];
		}
	} else {
		for (i = 0; i < dimension; i++) if (mask[i]) {
			if (img2[i] > img2max) img2[i] = img2max;
			if (img2[i] < img2min) img2[i] = img2min;
		}
	}
	range2 = img2max - img2min;

	fprintf (stdout, "img1: min=%10.2f\tmax=%10.2f\trange=%10.2f\n", img1min, img1max, range1);
	fprintf (stdout, "img2: min=%10.2f\tmax=%10.2f\trange=%10.2f\n", img2min, img2max, range2);
	sprintf (string, "before auto range adjust\n"); printrec (string);
	sprintf (string, "img1: min=%10.2f\tmax=%10.2f\trange=%10.2f\n", img1min, img1max, range1); printrec (string);
	sprintf (string, "img2: min=%10.2f\tmax=%10.2f\trange=%10.2f\n", img2min, img2max, range2); printrec (string);

	if (!fix_flag) {
		for (i = 0; i < dimension; i++) if (mask[i]) {
			k = (int) (nbin * (img1[i] - img1min)) / range1;
			if (k < nbin && k > 0) mrg1[k]++;
			k = (int) (nbin * (img2[i] - img2min)) / range2;
			if (k < nbin && k > 0) mrg2[k]++;
		}
		for (k = 2; k < nbin; k++) {
			mrg1[k] += mrg1[k - 1];
			mrg2[k] += mrg2[k - 1];
		}
		if (debug) for (k = 0; k < nbin; k++) {
			printf ("%6d  %10.6f  %10.6f\n", k,
				(float) mrg1[k] / (float) mrg1[nbin - 1], (float) mrg2[k] / (float) mrg2[nbin - 1]);
		}
		for (i = 1; i < nbin; i++) if (((float) mrg1[i] / (float) mrg1[nbin - 1]) > CUM_D) break;
		for (j = 1; j < nbin; j++) if (((float) mrg1[j] / (float) mrg1[nbin - 1]) > 1.0-CUM_D) break;
		if (debug) printf ("img1: first_bin=%d\tlast_bin=%d\n", i, j);
		img1min += (float) (range1 * i) / nbin;
		range1  *= (float) (j - i) / nbin;
		binwid1 = (float) range1 / nbin;
		if (!binwid1) binwid1++;
		range1 = binwid1 * nbin;
		img1min += binwid1 - fmod (img1min + range1, binwid1);
		for (i = 1; i < nbin; i++) if (((float) mrg2[i] / (float) mrg2[nbin - 1]) > CUM_D) break;
		for (j = 1; j < nbin; j++) if (((float) mrg2[j] / (float) mrg2[nbin - 1]) > 1.0-CUM_D) break;
		if (debug) printf ("img2: first_bin=%d\tlast_bin=%d\n", i, j);
		img2min += (float) (range2 * i) / nbin;
		range2  *= (float) (j - i) / nbin;
		binwid2 = (float) range2 / nbin;
		if (!binwid2) binwid2++;
		range2 = binwid2 * nbin;
		img2min += binwid2 - fmod (img2min + range2, binwid2);
	} else {
		binwid1 = (float) range1 / nbin;
		binwid2 = (float) range2 / nbin;
	}
	fprintf (stdout, "img1: min=%10.2f\tmax=%10.2f\trange=%10.2f\tbinwidth=%10.2f\n", img1min, img1min + range1, range1, binwid1);
	fprintf (stdout, "img2: min=%10.2f\tmax=%10.2f\trange=%10.2f\tbinwidth=%10.2f\n", img2min, img2min + range2, range2, binwid2);
	sprintf (string, "after auto range adjust\n");
		printrec (string);
	sprintf (string, "img1: min=%10.2f\tmax=%10.2f\trange=%10.2f\tbinwidth=%10.2f\n", img1min, img1min + range1, range1, binwid1);
		printrec (string);
	sprintf (string, "img2: min=%10.2f\tmax=%10.2f\trange=%10.2f\tbinwidth=%10.2f\n", img2min, img2min + range2, range2, binwid2);
		printrec (string);
	if (!range1 || !range2) exit (-1);

	for (k = 0; k < dimension; k++) if (mask[k]) {
		i = (int) ((img1[k] - img1min) / binwid1);
		j = (int) ((img2[k] - img2min) / binwid2);
		if (i < 0 || i >= nbin || j < 0 || j >= nbin) continue;
		hist[nbin*j + i]++;
		if (hist[nbin*j + i] > histmax) histmax = hist[nbin*j + i];
	}
	fprintf (stdout, "maximum bin count=%d\n", histmax);

/***************************/
/* write histogram to imgo */
/***************************/
	for (k = 0; k < nbin*nbin; k++) {
		if (hist[k] > 0) imgo[k] = log ((double) hist[k]);
		else imgo[k] = 0;
		if (imgo[k] > valmax) valmax = imgo[k];
	}

	if (text_flag) {
		sprintf (imgfile, "%s.txt", outroot); fprintf (stdout, "Writing: %s\n", imgfile);
		if (!(fp = fopen (imgfile, "w"))) errw (program, imgfile);
		for (i = 0; i < nbin; i++) for (j = 0; j < nbin; j++) {
			if (fprintf (fp, "%10.2f\t%10.2f\t%10.2f\n", img1min+(i+1/2)*binwid1, img2min+(j+1/2)*binwid2, imgo[nbin*j+i]) < 0)
			errw (program, imgfile);
		}
		if (fclose (fp)) errw (program, imgfile);
	}

	if (do_grid) {
		grid1 = range1 / 10;
		for (i = ftmp = 0; i < nbin; ftmp += grid1) {
			i = (int) (ftmp - img1min) / binwid1;
			if (i >= 0 && i < nbin) for (j = 0; j < nbin; j++) imgo[nbin * j + i] = valmax / 2;
		}
		sprintf (string, "img1: grid interval=%d\n", grid1); printrec (string);

		grid2 = range2 / 10;
		for (j = ftmp = 0; j < nbin; ftmp += grid2) {
			j = (int) (ftmp - img2min) / binwid2;
			if (j >= 0 && j < nbin) for (i = 0; i < nbin; i++) imgo[nbin * j + i] = valmax / 2;
		}
		sprintf (string, "img2: grid interval=%d\n", grid2); printrec (string);
	}

	flipy (imgo, &nbin, &nbin, &ONE);	/* comply with 4dfp convention for transverse images */
	sprintf (imgfile, "%s.4dfp.img", outroot); fprintf (stdout, "Writing: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "wb")) || ewrite (imgo, nbin*nbin, control, fp) || fclose (fp)) errw (program, imgfile);

	img1dim[0] = img1dim[1] = nbin;
	img1dim[2] = 1;
	vox1dim[0] = binwid1;
	vox1dim[1] = binwid2;
	vox1dim[2] = 1;
	center[0]  = -img1min;
	center[1]  = -img2min;
	center[2]  = 0.5;
	orient1 = TRANSVERSE;
	if (writeifhmce (program, outroot, img1dim, vox1dim, orient1, vox1dim, center, control)) errw (program, outroot);

	sprintf (string, "ifh2hdr %s -r%dto%f", outroot, 0, valmax);
	system (string);

	free (img1); free (img2); free (imgo);
	free (mrg1); free (mrg2);
	free (hist); free (mask);
	endrec ();

	exit (status);
}
