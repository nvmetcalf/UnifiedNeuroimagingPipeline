/*$Header: /data/petsun4/data1/src_solaris/qnt_4dfp/RCS/ICA_test.c,v 1.5 2013/01/17 04:17:15 avi Exp avi $*/
/*$Log: ICA_test.c,v $
 * Revision 1.5  2013/01/17  04:17:15  avi
 * Bell-Sejnowski variant works but converges slowly
 *
 * Revision 1.4  2012/11/26  05:18:38  avi
 * Bell-Sejnowski natural gradient algorithm seems to work
 *
 * Revision 1.3  2012/11/16  05:48:50  avi
 * natural gradient Bell-Sejnowki Table 9.1 p 210 Hyvarinen, Karhunen, Oja
 *
 * Revision 1.2  2012/11/12  04:01:41  avi
 * Original Bell-Sejnowski
 *
 * Revision 1.1  2012/11/12  03:00:57  avi
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* getpid () */
#include <string.h>
#include <math.h>
#include <float.h>
#include <assert.h>
#ifndef _FEATURES_H		/* defined by math.h in Linux */
	#include <sunmath.h>	/* isnormal() */
	#include <ieeefp.h>
#endif
#include <librms.h>
#include <dsvdcmp0.h>		/* dsvdinv() */

#define MIN(a,b)	((a) < (b) ? (a) : (b))
#define MAXL	256
#define K	5		/* dimensionality of system */
#define N	10000		/* number of observations */

/*************/
/* externals */
/*************/
void fast_ICAg (int ig, double **z, int mdat, int npts, double **W, int mout, double **y);

/********************/
/* global variables */
/********************/
char	program[MAXL];
static char rcsid[]= "$Id: ICA_test.c,v 1.5 2013/01/17 04:17:15 avi Exp avi $";

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation errmaxor\n", program);
	exit (-1);
}

void errr (char* program, char* filespc) {
	fprintf (stderr, "%s: %s read errmaxor\n", program, filespc);
	exit (-1);
}

void errw (char* program, char* filespc) {
	fprintf (stderr, "%s: %s write errmaxor\n", program, filespc);
	exit (-1);
}

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm (program);
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

int prewhiten (double **x, int kdim, int npts, double **z, double tol) {
	double	**C, **G, **V, *W, q;
	int	i, j, k, l, n;
	int	debug = 0;

	if (debug) G = calloc_double2 (kdim, kdim);
	C = calloc_double2 (kdim, kdim);
	V = calloc_double2 (kdim, kdim);
	if (!(W = (double *) malloc (kdim*sizeof (double)))) errm (program);

/**************************************/
/* compute C = xxt = input covariance */
/**************************************/
	for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
		for (C[i][j] = l = 0; l < npts; l++) C[i][j] += x[i][l]*x[j][l];
		C[i][j] /= npts;
	}
if (debug) {
	printf ("original      x covariance\n");
	for (i = 0; i < kdim; i++) {
		for (j = 0; j < kdim; j++) printf ("%10.6f", C[i][j]);
		printf ("\n");
	}
}
/*******/
/* SVD */
/*******/
	     dsvdcmp0 (C, kdim, kdim, W, V);
	n = ndsvdcmp0 (C, kdim, kdim, W, V, 0.);
	printf ("eigenvalues\n");
	for (j = 0; j < kdim; j++) printf ("%10.6f", W[j]); printf ("\n");

/************/
/* test svd */
/************/
if (debug) {
	for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
		for (G[i][j] = k = 0; k < kdim; k++) G[i][j] += V[j][k]*V[i][k];
	}
	printf ("VtV should be I\n");
	for (i = 0; i < kdim; i++) {
		for (j = 0; j < kdim; j++) printf ("%10.6f", G[i][j]);
		printf ("\n");
	}
	for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
		for (G[i][j] = k = 0; k < kdim; k++) G[i][j] += C[j][k]*C[i][k];
	}
	printf ("UtU should be I\n");
	for (i = 0; i < kdim; i++) {
		for (j = 0; j < kdim; j++) printf ("%10.6f", G[i][j]);
		printf ("\n");
	}
	for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
		for (G[i][j] = k = 0; k < kdim; k++) G[i][j] += V[i][k]*W[k]*V[j][k];
	}
	printf ("reconstituted x covariance\n");
	for (i = 0; i < kdim; i++) {
		for (j = 0; j < kdim; j++) printf ("%10.6f", G[i][j]);
		printf ("\n");
	}
}
	q = W[0]; n = kdim;
	for (i = 0; i < kdim; i++) {
		if (W[i]/q > tol) {
			W[i] = 1./sqrt(W[i]);
		} else {
			n = i;
			break;
		}
	}
/*******************************/
/* generate prewhitened output */
/*******************************/
	for (i = 0; i < n; i++) for (l = 0; l < npts; l++) {
		for (z[i][l] = j = 0; j < kdim; j++) z[i][l] += V[j][i]*W[i]*x[j][l];
	}
	free (W);  free_double2 (V); free_double2 (C);
	if (debug) free_double2 (G);
	return n;
}

double dzeromean (double *f, int npts) {
	int		i;
	double		u;

	for (u = i = 0; i < npts; i++) u += f[i];
	u /= npts;
	for (i = 0; i < npts; i++) f[i] -= u;
	return u;
}

double dunitvar (double *f, int npts) {
	int		i;
	double		v;

	for (v = i = 0; i < npts; i++) v += f[i]*f[i];
	v /= npts;
	for (i = 0; i < npts; i++) f[i] /= sqrt (v);
	return v;
}

void normalize (double *x, int n) {
	double		q;
	int		i;

	for (q = i = 0; i < n; i++) q += x[i]*x[i];
	q = sqrt (q);
	for (i = 0; i < n; i++) x[i] /= q;
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
	int		i;

	fprintf (outfp, "#%s", program);
	for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
	fprintf (outfp, "\n");
	fprintf (outfp, "#%s\n", rcsid);
}

static void usage (char *program) {
	printf ("%s\n", rcsid);
	printf ("Usage:\t%s\n", program);
	printf ("\toption\n");
	exit (1);
}

static void populate_Laplace (double *s, int npts) {
	int	l;
	double	q;

	for (l = 0; l < npts; l++) {
		do {q = log (drand48())/M_SQRT2;} while (!isnormal(q));
		if (drand48() < 0.5) q *= -1.;
		s[l] = q;
	}
}

static void populate_tanh (double *s, int npts) {
	int	l;
	double	t, q;

	for (l = 0; l < npts; l++) {
		do {
			t = drand48();
			q = log(t) - log(1. - t);
		} while (!isnormal(q));
		s[l] = q;
	}
}

double g (double y, double *gp) {
	double q;

	q = tanh(y);
	*gp = 1. - q*q;
	return q;
}

static void nat_grad_ICA (double **x, int kdim, int npts, double **W, double **y, double eta) {
/*************************************************************/
/* natural gradient variant of Bell-Sejnowski ICA HKO p. 208 */
/*************************************************************/
	double		**dW, **T, **Egy;
	double		errmax, rmserr = 0., rmserr0 = 0.;
	double		q, t;
	int		iter;
	int             i, j, k, l;
	int		debug = 0;

	Egy	= calloc_double2 (kdim, kdim);
	dW	= calloc_double2 (kdim, kdim);
	T	= calloc_double2 (kdim, kdim);

	iter = 0;
	do {
		for (l = 0; l < npts; l++) {
			for (i = 0; i < kdim; i++) {
				for (t = j = 0; j < kdim; j++) t += W[i][j]*x[j][l];
				y[i][l] = t;
			}
		}
		for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
			for (t = l = 0; l < npts; l++) t += tanh(y[i][l])*y[j][l];
			Egy[i][j] = t;
		}
		for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {Egy[i][j] /= npts; Egy[i][j] *= 2.;}
if (debug) {
		printf ("Egy\n");
		for (i = 0; i < kdim; i++) {
			for (j = 0; j < kdim; j++) printf ("%10.6f", Egy[i][j]);
			printf ("\n");
		}
}
		rmserr0 = rmserr;
		for (rmserr = errmax = i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
			T[i][j] = ((i == j) ? 1. : 0.) - Egy[i][j];
			q = fabs (T[i][j]); if (q > errmax) errmax = q;
			rmserr += q*q;
		}
		rmserr /= (kdim*kdim); rmserr = sqrt (rmserr);

		for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
			for (dW[i][j] = k = 0; k < kdim; k++) dW[i][j] += T[i][k]*W[k][j];
		}
if (debug) {
		printf ("T\n");
		for (i = 0; i < kdim; i++) {
			for (j = 0; j < kdim; j++) printf ("%10.6f", T[i][j]);
			printf ("\n");
		}
		printf ("dW\n");
		for (i = 0; i < kdim; i++) {
			for (j = 0; j < kdim; j++) printf ("%10.6f", dW[i][j]);
			printf ("\n");
		}
}
		for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) W[i][j] += eta*dW[i][j];

		iter++;
if (debug)	printf ("iter %5d  rmserr0 = %.6f  rmserr = %.6f  errmax = %.6f\n", iter, rmserr0, rmserr, errmax);
	} while (rmserr > 1.e-7 && iter < 200);
if (!debug)	printf ("iter %5d  rmserr0 = %.6f  rmserr = %.6f  errmax = %.6f\n", iter, rmserr0, rmserr, errmax);

	free_double2 (Egy);
	free_double2 (dW);
	free_double2 (T);
}

static void fast_ICA0 (double **z, int kdim, int npts, double **W, double **y) {
/**************/
/* HKO p. 196 */
/**************/
	double		**WWt, **Ezgy, **Egpy, **T, **W0;
	double		det, errmax, rmserr = 0., rmserr0 = 0.;
	double		t, gp;
	int		iter;
	int             i, j, k, l;
	int		debug = 1;

	Ezgy	= calloc_double2 (kdim, kdim);
	Egpy	= calloc_double2 (kdim, kdim);
	WWt	= calloc_double2 (kdim, kdim);
	W0	= calloc_double2 (kdim, kdim);
	T	= calloc_double2 (kdim, kdim);

	iter = 0;
	do {
/****************/
/* save W in W0 */
/****************/
		for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) W0[i][j] = W[i][j];
		printf ("W0\n");
		for (i = 0; i < kdim; i++) {
			for (j = 0; j < kdim; j++) printf ("%10.6f", W0[i][j]);
			printf ("\n");
		}

/**********/
/* y <- z */
/**********/
		for (l = 0; l < npts; l++) {
			for (i = 0; i < kdim; i++) {
				for (y[i][l] = j = 0; j < kdim; j++) y[i][l] += W[i][j]*z[j][l];
			}
		}

/***********************/
/* update columns of W */
/***********************/
		printf ("W before ICA\n");
		for (i = 0; i < kdim; i++) {
			for (j = 0; j < kdim; j++) printf ("%10.6f", W[i][j]);
			printf ("\n");
		}
		for (k = 0; k < kdim; k++) {
			for (i = 0; i < kdim; i++) {
				Ezgy[i][k] = Egpy[i][k] = 0.;
				for (l = 0; l < npts; l++) {
					t = g(y[k][l], &gp);
					Ezgy[i][k] += z[i][l]*t;
					Egpy[i][k] += gp;
				}
				Ezgy[i][k] /= npts;
				Egpy[i][k] /= npts;
				W[i][k] = Ezgy[i][k] - Egpy[i][k]*W[i][k];
			}
		}

/********************************************/
/* perform symmetric orthogonalization on W */
/********************************************/
		for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
			T[i][j] = W[i][j];
			for (WWt[i][j] = k = 0; k < kdim; k++) WWt[i][j] += W[i][k]*W[j][k];
		}
		dsvdsqrtinv (WWt, kdim, &det); printf ("det = %10.6e\n", det);
		for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
			for (W[i][j] = k = 0; k < kdim; k++) W[i][j] += WWt[i][k]*T[k][j];
		}
		printf ("W  after ICA\n");
		for (i = 0; i < kdim; i++) {
			for (j = 0; j < kdim; j++) printf ("%10.6f", W[i][j]);
			printf ("\n");
		}

/*********************/
/* check convergence */
/*********************/
		for (rmserr = i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
			t = T[i][j] = (W[i][j] - W0[i][j]);
			rmserr += t*t;
		}
		rmserr /= kdim*kdim;
		printf ("W - W0\n");
		for (i = 0; i < kdim; i++) {
			for (j = 0; j < kdim; j++) printf ("%10.6f", T[i][j]);
			printf ("\n");
		}

		iter++;
if (debug)	printf ("iter %5d rmserr = %.6f\n", iter, rmserr);
	} while (rmserr > 1.e-7 && iter < 200);
if (!debug)	printf ("iter %5d rmserr = %.6f\n", iter, rmserr);

	free_double2 (Ezgy);
	free_double2 (Egpy);
	free_double2 (WWt);
	free_double2 (W0);
	free_double2 (T);
}

int main (int argc, char *argv[]) {
/**************/
/* processing */
/**************/
	double		s[K][N];
	double		**x, **y, **u, **z, **C, **A, **W, **V;
	double		eta = .5, tol = 0.1;
	int		kdim = K, npts = N, mdat, mout = 2;

/***********/
/* utility */
/***********/
	FILE            *datfp;
	char            *ptr, command[2*MAXL];
	double		q, t;
	int             c, i, j, k, l, m, n;

/*********/
/* flags */
/*********/
	int		debug = 0;
	int		status = 0;

	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (j = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'd': debug++;		break; 
				default:			break;
			}
		} else switch (j) {
			default:				break;
		}
	}

/*********************************/
/* construct independent sources */
/*********************************/
	for (i = 0; i < kdim; i++) populate_Laplace (s[i], N);
	printf ("Writing: signals.dat\n");
	if (!(datfp = fopen ("signals.dat", "w"))) errw (program, "signals.dat");
	for (l = 0; l < npts; l++) fprintf (datfp, "%10.4f%10.4f\n", s[0][l], s[1][l]);
	fclose (datfp);

	A	= calloc_double2 (kdim, kdim);
	V	= calloc_double2 (kdim, kdim);
	C	= calloc_double2 (kdim, kdim);
	x 	= calloc_double2 (kdim, npts);
	z 	= calloc_double2 (kdim, npts);

/************************/
/* compute s covariance */
/************************/
	for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
		for (C[i][j] = l = 0; l < N; l++) C[i][j] += s[i][l]*s[j][l];
		C[i][j] /= N;
	}
	printf ("s covariance matrix\n");
	for (i = 0; i < kdim; i++) {
		for (j = 0; j < kdim; j++) printf ("%10.6f", C[i][j]);
		printf ("\n");
	}

/******************************/
/* construct observed signals */
/******************************/
do {
	for (i = 0; i < kdim; i++) for (j = 0; j < kdim; j++) {
		A[i][j] = 1. - 2.*drand48();
		if (0) A[i][j] = (i == j) ? 1. : 0.;

	}
	for (i = 0; i < kdim; i++) for (l = 0; l < N; l++) {
		for (x[i][l] = j = 0; j < K; j++) x[i][l] += A[i][j]*s[j][l];
	}

/***************/
/* zero mean x */
/***************/
	for (i = 0; i < kdim; i++) dzeromean (x[i], npts);
/********************/
/* prewhiten z <- x */
/********************/
	printf ("kdim before prewhitening = %d\n", kdim);
	mdat = prewhiten (x, kdim, npts, z, tol);\
	printf ("mdat  after prewhitening = %d\n", mdat);
} while (mdat < 2);

	printf ("Writing: observed.dat\n");
	if (!(datfp = fopen ("observed.dat", "w"))) errw (program, "observed.dat");
	for (l = 0; l < npts; l++) fprintf (datfp, "%10.4f%10.4f\n", x[0][l], x[1][l]);
	fclose (datfp);

	printf ("Writing: prewhitened.dat\n");
	if (!(datfp = fopen ("prewhitened.dat", "w"))) errw (program, "prewhitened.dat");
	for (l = 0; l < npts; l++) fprintf (datfp, "%10.4f%10.4f\n", z[0][l], z[1][l]);
	fclose (datfp);
/*********************/
/* verify z is white */
/*********************/
	for (i = 0; i < mdat; i++) for (j = 0; j < mdat; j++) {
		for (C[i][j] = l = 0; l < npts; l++) C[i][j] += z[i][l]*z[j][l];
		C[i][j] /= npts;
	}
	printf ("z covariance matrix\n");
	for (i = 0; i < mdat; i++) {
		for (j = 0; j < mdat; j++) printf ("%10.6f", C[i][j]);
		printf ("\n");
	}

	if (1) mout = mdat;
	W = calloc_double2 (mdat, mout); for (i = 0; i < mout; i++) W[i][i] = 1.;
	y = calloc_double2 (mout, npts);
	
	printf ("W before ICA\n");
	for (i = 0; i < mdat; i++) {
		for (j = 0; j < mout; j++) printf ("%10.6f", W[i][j]);
		printf ("\n");
	}
/***********/
/* run ICA */
/***********/
	fast_ICAg (2, z, mdat, npts, W, mout, y);
	printf ("Writing: ICs.dat\n");
	if (!(datfp = fopen ("ICs.dat", "w"))) errw (program, "ICs.dat");
	for (l = 0; l < npts; l++) fprintf (datfp, "%10.4f%10.4f\n", y[0][l], y[1][l]);
	fclose (datfp);

	for (i = 0; i < mout; i++) for (j = 0; j < mout; j++) {
		for (C[i][j] = l = 0; l < npts; l++) C[i][j] += y[i][l]*y[j][l];
		C[i][j] /= npts;
	}
	printf ("y covariance matrix\n");
	for (i = 0; i < mout; i++) {
		for (j = 0; j < mout; j++) printf ("%10.6f", C[i][j]);
		printf ("\n");
	}

	free_double2 (V);
	free_double2 (A);
	free_double2 (W);
	free_double2 (C);
	free_double2 (x);
	free_double2 (y);
	free_double2 (z);
	exit (status);
}
