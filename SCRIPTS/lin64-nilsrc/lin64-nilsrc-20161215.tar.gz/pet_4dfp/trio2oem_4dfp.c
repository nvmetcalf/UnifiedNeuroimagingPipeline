/******************************************************************************
Application:  This program is to create OEF and CMRO2 images based on the model
	      [OO]  := m1[HO] + m2[OC]; 
	      OEF   := ([OO]-m2[OC])/(m1[HO]/0.4);
	      CMRO2 := [OO] - m2[OC];	
	      where [OO] := oxygen
	            [OH] := water
	            [OC] := carbon monoxide
******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <float.h>
#include <assert.h>
#ifndef _FEATURES_H		/* defined by math.h in Linux */
	#include <sunmath.h>	/* isnormal() */
	#include <ieeefp.h>
#endif
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>

#define MAXL	256

static char	rcsid[] = "$Id: trio2oem_4dfp.c,v 1.5 2013/11/21 20:47:01 larsc Exp $";
static char	program[MAXL];

void setprog (char *program, char **argv)
{
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

int checkdimensions (char *program, char *imgroot, IFH *ifh)
{
	IFH	ifht;

	if (Getifh (imgroot, &ifht)) errr (program, imgroot);
	if (ifh->matrix_size[0] != ifht.matrix_size[0] || (fabs (ifh->scaling_factor[0] - ifht.scaling_factor[0]) > 1.e-5)
	 || ifh->matrix_size[1] != ifht.matrix_size[1] || (fabs (ifh->scaling_factor[1] - ifht.scaling_factor[1]) > 1.e-5)
	 || ifh->matrix_size[2] != ifht.matrix_size[2] || (fabs (ifh->scaling_factor[2] - ifht.scaling_factor[2]) > 1.e-5)
	 || ifh->orientation    != ifht.orientation)
	{
		fprintf (stderr, "%s: %s dimension mismatch\n", program, imgroot);
		exit (-1);
	}
	return (!strcmp (ifht.imagedata_byte_order, "bigendian"));
}

void readimage (char *program, char *imgroot, int vol, int isbig, float *img)
{
	char	imgfile[MAXL];
	FILE	*fp;

	sprintf (imgfile, "%s.4dfp.img", imgroot);
	fprintf (stdout, "Reading: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "rb"))
	 || eread  (img, vol, isbig, fp)
	 || fclose (fp)) errr (program, imgfile);
}

int isvalid (float f)
{
	return (isnormal (f) && f != (float) 1.e-37 && f != 0.);
}

int main (int argc, char *argv[])
{
	FILE	*fp;
	IFH	ifh;
	char	ooroot[MAXL], horoot[MAXL], coroot[MAXL], mskroot[MAXL], omroot[MAXL], oeroot[MAXL];
	char	string[MAXL], command[MAXL];
	int	i, j, vol, mskvol, isbigo, isbigh, isbigc, isbigm;
	char	control = '\0', c, *ptr;
	float	*oo, *ho, *co, *out;
	double	oooo, ooho, ooco, hoho, hoco, coco, m1, m2, rms;
	short	*msk;
	int	u_flag = 0;

	printf ("%s\n", rcsid);
	setprog (program, argv);

	for (j = 0, i = 1; i < argc; i++) if (*argv[i] == '-') {
		strncpy (string, argv[i], MAXL); ptr = string;
		while (c = *ptr++) switch (c) {
			case 'u': u_flag++;	break;
		}
	} else switch (j) {
		case 0: getroot (argv[i], ooroot);		j++; break;
		case 1: getroot (argv[i], horoot);		j++; break;
		case 2: getroot (argv[i], coroot);		j++; break;
		case 3: getroot (argv[i], mskroot);		j++; break;
		case 4: getroot (argv[i], omroot);		j++; break;
		case 5: getroot (argv[i], oeroot);		j++; break;
	}
	if (j != 6) {
		fprintf (stderr, "Usage:\t%s <(4dfp)oxygen> <(4dfp)water> <(4dfp)carbon monoxide> <(4dfp)mask> <(4dfp)cmro2 outroot> <(4dfp)oef outroot>\n", program);
		fprintf (stderr, "\toption\n");
		fprintf (stderr, "\t-u\twrite values to all voxels (not just those within the mask)\n");
		exit (1);
	}

	sprintf (string, "%s.4dfp.ifh", ooroot);
	if (Getifh (string, &ifh)) errr (program, string);

	isbigo = !strcmp (ifh.imagedata_byte_order, "bigendian");
	if (!control) control = (isbigo) ? 'b' : 'l';

	isbigh = checkdimensions (program, horoot,  &ifh);
	isbigc = checkdimensions (program, coroot,  &ifh);
	isbigm = checkdimensions (program, mskroot, &ifh);

	vol = ifh.matrix_size[0] * ifh.matrix_size[1] * ifh.matrix_size[2];

	if (!(oo  = (float *) malloc (vol * sizeof (float)))
	 || !(ho  = (float *) malloc (vol * sizeof (float)))
	 || !(co  = (float *) malloc (vol * sizeof (float)))
	 || !(out = (float *) malloc (vol * sizeof (float)))
	 || !(msk = (short *) malloc (vol * sizeof (short)))) errm (program);

	readimage (program, ooroot,  vol, isbigo, oo);
	readimage (program, horoot,  vol, isbigh, ho);
	readimage (program, coroot,  vol, isbigc, co);
	readimage (program, mskroot, vol, isbigm, out);
	for (i = 0; i < vol; i++) msk[i] = isvalid (out[i]);

	oooo = ooho = ooco = hoho = hoco = coco = 0;
	for (mskvol = i = 0; i < vol; i++) if (msk[i] && isvalid (oo[i]) && isvalid (ho[i]) && isvalid (co[i])) {
		oooo += oo[i] * oo[i];
		ooho += oo[i] * ho[i];
		ooco += oo[i] * co[i];
		hoho += ho[i] * ho[i];
		hoco += ho[i] * co[i];
		coco += co[i] * co[i];
		mskvol++;
	}

	m1 = (ooho*coco - ooco*hoco) / (hoho*coco - hoco*hoco);
	m2 = (ooco*hoho - ooho*hoco) / (hoho*coco - hoco*hoco);
	rms = sqrt ((oooo + m1*hoho + m2*coco - 2*m1*ooho - 2*m2*ooco + 2*m1*m2*coco) / mskvol);

	fprintf (stdout, "m1 := %f\nm2 := %f\nrms := %f\n", m1, m2, rms);

	if (! u_flag) for (i = 0; i < vol; i++) out[i] = (msk[i] && isvalid (oo[i]) && isvalid (ho[i]) && isvalid (co[i]) ? (oo[i] - m2*co[i]) / (m1*ho[i]/0.4) : 0);
	else	      for (i = 0; i < vol; i++) out[i] = (          isvalid (oo[i]) && isvalid (ho[i]) && isvalid (co[i]) ? (oo[i] - m2*co[i]) / (m1*ho[i]/0.4) : 0);
	sprintf (string, "%s.4dfp.img", oeroot);
	fprintf (stdout, "Writing: %s\n", string);
	if (!(fp = fopen (string, "wb"))
	 || ewrite (out, vol, control, fp)
	 || fclose (fp)) errw (program, string);
	startrece (string, argc, argv, rcsid, control);
	sprintf (string, "m1 := %f\nm2 := %f\n", m1, m2);
	printrec (string);
	sprintf (string, "%s.4dfp.img.rec",  ooroot); catrec (string);
	sprintf (string, "%s.4dfp.img.rec",  horoot); catrec (string);
	sprintf (string, "%s.4dfp.img.rec",  coroot); catrec (string);
	sprintf (string, "%s.4dfp.img.rec", mskroot); catrec (string);
	endrec ();
	sprintf (string, "%s.4dfp.ifh", oeroot);
	if (Writeifh (program, string, &ifh, control)) errw (program, string);
	sprintf (command, "ifh2hdr %s", string);
	system (command);

	if (! u_flag) for (i = 0; i < vol; i++) out[i] = (msk[i] && isvalid (oo[i]) && isvalid (co[i]) ? oo[i] - m2*co[i] : 0);
	else	      for (i = 0; i < vol; i++) out[i] = (          isvalid (oo[i]) && isvalid (co[i]) ? oo[i] - m2*co[i] : 0);
	sprintf (string, "%s.4dfp.img", omroot);
	fprintf (stdout, "Writing: %s\n", string);
	if (!(fp = fopen (string, "wb"))
	 || ewrite (out, vol, control, fp)
	 || fclose (fp)) errw (program, string);
	startrece (string, argc, argv, rcsid, control);
	sprintf (string, "m1 := %f\nm2 := %f\nrms := %f\n", m1, m2, rms);
	printrec (string);
	sprintf (string, "%s.4dfp.img.rec",  ooroot); catrec (string);
	sprintf (string, "%s.4dfp.img.rec",  horoot); catrec (string);
	sprintf (string, "%s.4dfp.img.rec",  coroot); catrec (string);
	sprintf (string, "%s.4dfp.img.rec", mskroot); catrec (string);
	endrec ();
	sprintf (string, "%s.4dfp.ifh", omroot);
	if (Writeifh (program, string, &ifh, control)) errw (program, string);
	sprintf (command, "ifh2hdr %s", string);
	system (command);

	free (oo);
	free (ho);
	free (co);
	free (msk);
	free (out);

	exit (0);
}
