#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#ifndef _FEATURES_H		/* defined by math.h in Linux */
	#include <sunmath.h>	/* isnormal() */
	#include <ieeefp.h>
#endif
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>

#define MAXL	256

static char	rcsid[] = "$Id: residual_4dfp.c,v 1.5 2013/11/21 20:48:12 larsc Exp $";
static char	program[MAXL];

void setprog (char *program, char **argv)
{
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

int checkdimensions (char *program, char *imgroot, IFH *ifh)
{
	IFH	ifht;

	if (Getifh (imgroot, &ifht)) errr (program, imgroot);
	if (ifh->matrix_size[0] != ifht.matrix_size[0] || (fabs (ifh->scaling_factor[0] - ifht.scaling_factor[0]) > 1.e-5)
	 || ifh->matrix_size[1] != ifht.matrix_size[1] || (fabs (ifh->scaling_factor[1] - ifht.scaling_factor[1]) > 1.e-5)
	 || ifh->matrix_size[2] != ifht.matrix_size[2] || (fabs (ifh->scaling_factor[2] - ifht.scaling_factor[2]) > 1.e-5)
	 || ifh->orientation    != ifht.orientation)
	{
		fprintf (stderr, "%s: %s dimension mismatch\n", program, imgroot);
		exit (-1);
	}
	return (!strcmp (ifht.imagedata_byte_order, "bigendian"));
}

void readimage (char *program, char *imgroot, int vol, int isbig, float *img)
{
	char	imgfile[MAXL];
	FILE	*fp;

	sprintf (imgfile, "%s.4dfp.img", imgroot);
	fprintf (stdout, "Reading: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "rb"))
	 || eread  (img, vol, isbig, fp)
	 || fclose (fp)) errr (program, imgfile);
}

int isvalid (float f)
{
	return (isnormal (f) && f != (float) 1.e-37 && f != 0.);
}

int main (int argc, char *argv[])
{
	FILE	*fp;
	IFH	ifh;
	char	inroot1[MAXL], inroot2[MAXL], mskroot[MAXL] = "", outroot[MAXL];
	char	string[MAXL], command[MAXL];
	int	i, j, vol, mskvol, isbig1, isbig2, isbigm, text_flag = 0;
	char	control = '\0', c, *ptr;
	float	*img1, *img2, *out;
	double	xx, xy, yy, x, y, slope, intercept, correlation, pearson, normal = 0;
	short	*msk;

	printf ("%s\n", rcsid);
	setprog (program, argv);

	for (j = 0, i = 1; i < argc; i++) if (*argv[i] == '-') {
		strncpy (string, argv[i], MAXL); ptr = string;
		while (c = *ptr++) switch (c) {
			case 'm': getroot (ptr, mskroot);	*ptr = '\0';	break;
			case 'n': normal = atof (ptr);		*ptr = '\0';	break;
			case 't': text_flag++;					break;
		}
	} else switch (j) {
		case 0: getroot (argv[i], inroot1);		j++; break;
		case 1: getroot (argv[i], inroot2);		j++; break;
		case 2: getroot (argv[i], outroot);		j++; break;
	}
	if (j != 3) {
		fprintf (stderr, "Usage:\t%s <(4dfp)image1> <(4dfp)image2> <(4dfp)outroot>\n", program);
		fprintf (stderr, " e.g.:\t%s om fdg out -mmask -n1000\n", program);
		fprintf (stderr, "\toptions\n");
		fprintf (stderr, "\t-m<(4dfp)mask>\tuse only within mask voxels\n");
		fprintf (stderr, "\t-n<float>\tscale image2 mean to <float>\n");
		fprintf (stderr, "\t-t\trecord voxel values in a text file\n");
		fprintf (stderr, " N.B.: the example illustrates the standard command for producing a GI image\n");
		exit (1);
	}

	sprintf (string, "%s.4dfp.ifh", inroot1);
	if (Getifh (string, &ifh)) errr (program, string);

	isbig1 = !strcmp (ifh.imagedata_byte_order, "bigendian");
	if (!control) control = (isbig1) ? 'b' : 'l';

	isbig2 = checkdimensions (program, inroot2, &ifh);
	if (strlen (mskroot)) isbigm = checkdimensions (program, mskroot, &ifh);

	vol = ifh.matrix_size[0] * ifh.matrix_size[1] * ifh.matrix_size[2];

	if (!(img1 = (float *) malloc (vol * sizeof (float)))
	 || !(img2 = (float *) malloc (vol * sizeof (float)))
	 || !(out  = (float *) malloc (vol * sizeof (float)))
	 || !(msk  = (short *) malloc (vol * sizeof (short)))) errm (program);

	readimage (program, inroot1, vol, isbig1, img1);
	readimage (program, inroot2, vol, isbig2, img2);
	if (strlen (mskroot)) {
		readimage (program, mskroot, vol, isbigm, out);
		for (i = 0; i < vol; i++) msk[i] = isvalid (out[i]);
	} else	for (i = 0; i < vol; i++) msk[i] = 1;

	xx = xy = yy = x = y = 0;
	for (mskvol = i = 0; i < vol; i++) if (msk[i] && isvalid (img1[i]) && isvalid (img2[i])) {
		xx += img1[i] * img1[i];
		xy += img1[i] * img2[i];
		yy += img2[i] * img2[i];
		x  += img1[i];
		y  += img2[i];
		mskvol++;
	}

	slope     = (mskvol*xy - x*y) / (mskvol*xx - x*x);
	intercept = (y - slope * x) / mskvol;
	pearson   = (mskvol*xy - x*y) / (sqrt (mskvol*xx-x*x) * sqrt (mskvol*yy - y*y));

	if (normal) {
		normal    /= (y / mskvol);
		slope     *= normal;
		intercept *= normal;
	} else	normal  = 1;
	fprintf (stdout, "scale    := %f\n", normal);
	fprintf (stdout, "slope     := %f\nintercept := %f\npearson   := %f\n", slope, intercept, pearson);

	if (text_flag) {
		sprintf (string, "%s.txt", outroot);
		if (!(fp = fopen (string, "w"))) errw (program, string);
		for (i = 0; i < vol; i++) if (msk[i] && isvalid (img1[i]) && isvalid (img2[i])) fprintf (fp, "%10.6f\t%10.6f\n", img1[i], img2[i]);
		if (fclose (fp)) errw (program, string);
	}

/*	for (i = 0; i < vol; i++) out[i] = (msk[i] ? (img2[i]-slope*img1[i]-intercept) : 0);
*/	for (i = 0; i < vol; i++) out[i] = (isvalid (img1[i]) && isvalid (img2[i]) ? normal*img2[i]-slope*img1[i]-intercept : 0);
	sprintf (string, "%s.4dfp.img", outroot);
	fprintf (stdout, "Writing: %s\n", string);
	if (!(fp = fopen (string, "wb"))
	 || ewrite (out, vol, control, fp)
	 || fclose (fp)) errw (program, string);
	startrece (string, argc, argv, rcsid, control);
	sprintf (string, "scale     := %f\nslope     := %f\nintercept := %f\npearson   := %f\n", normal, slope, intercept, pearson);
	printrec (string);
	sprintf (string, "%s.4dfp.img.rec", inroot1); catrec (string);
	sprintf (string, "%s.4dfp.img.rec", inroot2); catrec (string);
	if (strlen (mskroot)) {sprintf (string, "%s.4dfp.img.rec", mskroot); catrec (string);}
	endrec ();
	sprintf (string, "%s.4dfp.ifh", outroot);
	if (Writeifh (program, string, &ifh, control)) errw (program, string);
	sprintf (command, "ifh2hdr %s", string);
	system (command);

	free (img1);
	free (img2);
	free (msk);
	free (out);

	exit (0);
}
