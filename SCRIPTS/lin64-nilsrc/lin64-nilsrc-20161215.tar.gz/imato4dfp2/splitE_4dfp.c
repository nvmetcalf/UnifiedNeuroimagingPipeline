/*$Header: /data/petsun4/data1/src_solaris/imato4dfp2/RCS/splitE_4dfp.c,v 1.1 2015/07/05 23:23:39 avi Exp $*/
/*$Log: splitE_4dfp.c,v $
 * Revision 1.1  2015/07/05  23:23:39  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include <float.h>
#include <string.h>
#include <stdio.h>
#include <Getifh.h>
#include <endianio.h>
#include <rec.h>

#define MAXL			256

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

static char rcsid[] = "$Id: splitE_4dfp.c,v 1.1 2015/07/05 23:23:39 avi Exp $";
int main (int argc, char *argv[]) {
/*******/
/* I/O */
/*******/
	FILE		*imgfp, *outfp;
	char		imgroot[MAXL], imgfile[MAXL], ifhfile[MAXL];
	char		outroot[MAXL], outfile[MAXL];
	char		trailer[MAXL] = "echo";
	IFH		imgifh;
	char		control = '\0';

/***********/
/* process */
/***********/
	int		iECHO, nECHO;
	int		imgdim[4], outdim[4], ivol, nvol, vdim;
	float		*imgf, voxdim[3];

/***********/
/* utility */
/***********/
	char		*ptr, command[MAXL], program[MAXL];
	int		c, i, j, k;

/*********/
/* flags */
/*********/
	int		debug = 0;
	int		status = 0;
	int		isbig;

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'd': debug++;		break;
			}
		}
		else switch (k) {
			case 0:	getroot (argv[i], imgroot);	k++; break;
			case 1:	nECHO = atof (argv[i]);		k++; break;
		}	
	}
	if (k < 2) {
		printf ("Usage:\t%s <file_4dfp> <nECHO>\n", program);
		printf ("\toption\n");
		printf ("	-d	debug mode\n");
		printf (" N.B.:\t%s splits <file_4dfp> into <nECHO> images\n", program);
		exit (1);
	}

/************/
/* read ifh */
/************/
	sprintf (ifhfile, "%s.4dfp.ifh", imgroot);
	fprintf (stdout, "Reading: %s\n", ifhfile);
	if (Getifh (ifhfile, &imgifh)) errr (program, ifhfile);
	if (imgifh.matrix_size[3] % nECHO) {
		fprintf (stderr, "%s: input number of volumes not a multiple of %d\n", program, nECHO);
		exit (-1);
	}
	for (k = 0; k < 4; k++) imgdim[k] = outdim[k] = imgifh.matrix_size[k];
	outdim[3] = nvol = imgdim[3]/nECHO;
	for (k = 0; k < 3; k++) voxdim[k] = imgifh.scaling_factor[k];
	isbig = !strcmp (imgifh.imagedata_byte_order, "bigendian");
	if (!control) control = (isbig) ? 'b' : 'l';
	printf ("input image dimensions \t%10d%10d%10d%10d\n", 
		imgifh.matrix_size[0], imgifh.matrix_size[1], imgifh.matrix_size[2], imgifh.matrix_size[3]);
	printf ("input image voxdim     \t%10.6f%10.6f%10.6f\n",
			imgifh.scaling_factor[0], imgifh.scaling_factor[1], imgifh.scaling_factor[2]);
	printf ("input image orientation\t%10d\n", imgifh.orientation);

	vdim = imgdim[0]*imgdim[1]*imgdim[2];
	if (!(imgf = (float *) malloc (vdim * sizeof (float)))) errm (program);

	sprintf (imgfile, "%s.4dfp.img", imgroot);
	if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);
	printf ("Reading: %s\n", imgfile);

/******************/
/* loop on echoes */
/******************/
	for (iECHO = 0; iECHO < nECHO; iECHO++) {
		printf ("processing echo %d\n", iECHO + 1);
/****************************/
/* compute output file root */
/****************************/
		sprintf (outroot, "%s_%s%d", imgroot, trailer, iECHO + 1);
		sprintf (outfile, "%s.4dfp.img", outroot);
		fprintf (stderr, "Writing: %s\n", outfile);
		if (!(outfp = fopen (outfile, "wb"))) errw (program, outfile);

/*******************/
/* loop on volumes */
/*******************/
		for (ivol = 0; ivol < nvol; ivol++) {
			if (fseek (imgfp, (long) (nECHO*ivol + iECHO)*vdim*sizeof (float), SEEK_SET)
			||  fread (imgf, sizeof (float), vdim, imgfp) != vdim) errr (program, imgfile);
/****************/
/* write volume */
/*****************/
			if (fwrite (imgf, sizeof (float), vdim, outfp) != vdim) errw (program, outfile);
		}
		if (fclose (outfp)) errw (program, outfile);
/*******/
/* ifh */
/*******/
		writeifhe (program, outfile, outdim, voxdim, imgifh.orientation, control);
/*******/
/* hdr */
/*******/
		sprintf (command, "ifh2hdr %s.4dfp.ifh", outroot); status = system (command);
		if (status) break;
/*******/
/* rec */
/*******/
		sprintf (outfile, "%s.4dfp.img", outroot); startrec (outfile, argc, argv, rcsid);
		endrec ();
	}

	free (imgf);
        exit (status);
}
