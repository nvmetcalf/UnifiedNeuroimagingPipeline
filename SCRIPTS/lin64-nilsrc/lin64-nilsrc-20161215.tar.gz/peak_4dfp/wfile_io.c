/*$Header$*/
/*$Log$*/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <Getifh.h>
#include <endianio.h>

/***********/
/* globals */
/***********/
static	char		program[] = "wfile_io";
static	char		rcsid[] = "$Id$";
static	int		CPU_is_littleendian;

void errx (char *filspc) {
	fprintf (stderr, "%s: %s format error\n", program, filspc);
	exit (-1);
}

typedef union {
	short		s;
	char		buf[sizeof(short)];
} SWAP_SHORT;

typedef union {
	float		f;
	int		i;
	unsigned int	ui;
	char		buf[4];
	short		s[2];
} SWAP_FLOATINT;

short	swapShort	(short s);
int	swapInt		(int i);
float	swapFloat	(float f);
int	fread2		(short *v, FILE *fp);
int	fread3		(int *v, FILE *fp);
int	fread4		(float *v, FILE *fp);
int	freadInt	(FILE *fp);
float	freadFloat	(FILE *fp);
int	fwrite2		(short i, FILE *fp);
int	fwrite3		(int i, FILE *fp);
int	fwriteFloat	(float f, FILE *fp);

int read_wfile  (char *fname, float *vals, int vertexcnt);
int write_wfile (char *fname, float *vals, int vertexcnt);

int read_wfile (char *fname, float *vals, int vertexcnt) {
	int		i, k;
	short		ilat;
	FILE		*fp;

	CPU_is_littleendian = !CPU_is_bigendian();

	if (!(fp = fopen (fname, "rb"))) errr (program, fname);
	printf ("Reading: %s\n", fname);
	fseek (fp, (long) 0, SEEK_END);
	if ((ftell(fp) - 5) % 7) errx (fname);
	k = (ftell(fp) - 5)/7;
	if (k != vertexcnt) errx (fname);

	rewind (fp);
	fread2 (&ilat, fp);	/* for rm'd int latencies, MRISwriteValue def=0 */
	if (ilat) {
		printf ("ilat = %d\n", ilat);
		errx (fname);
	}
	fread3 (&k, fp);
	if (k != vertexcnt) errx (fname);
	for (i = 0; i < vertexcnt; i++) {
		fread3 (&k, fp);
		if (i != k) errx (fname);
		fread4 (vals + k, fp);
		if (0) printf ("%10d%10d%10.4f\n", i, k, vals[k]);
	}
	fclose (fp);
	return 0;
}

int write_wfile (char *fname, float *vals, int vertexcnt) {
	int		i;
	FILE		*fp;

	CPU_is_littleendian = !CPU_is_bigendian();

	if (!(fp = fopen (fname, "wb"))) errw (program, fname);
	printf ("Writing: %s\n", fname);
	fwrite2 ((short) 0, fp);
	fwrite3 (vertexcnt, fp);
	for (i = 0; i < vertexcnt; i++) {
		fwrite3 (i, fp);
		fwriteFloat (vals[i], fp);
	}
	fclose (fp);

	return (0);
}

short swapShort (short s) {
	SWAP_SHORT	ss;
	char		c;

	ss.s = s;
	c = ss.buf[0];
	ss.buf[0] = ss.buf[1];
	ss.buf[1] = c;

	return (ss.s);
}

int swapInt(int i) {
	SWAP_FLOATINT		sfi;
	short			s;

	sfi.i = i;
	sfi.s[0] = swapShort (sfi.s[0]);
	sfi.s[1] = swapShort (sfi.s[1]);
	s = sfi.s[0];
	sfi.s[0] = sfi.s[1];
	sfi.s[1] = s;

	return(sfi.i) ;
}

float swapFloat(float f) {
	SWAP_FLOATINT	sfi;
	short		s;

	sfi.f = f;
	sfi.s[0] = swapShort (sfi.s[0]);
	sfi.s[1] = swapShort (sfi.s[1]);
	s = sfi.s[0];
	sfi.s[0] = sfi.s[1];
	sfi.s[1] = s;

	return (sfi.f);
}

int fwrite2 (short i, FILE *fp)	{	/* short */
	short		k;

	k = (CPU_is_littleendian) ? swapShort (i) : i;
	return fwrite (&k, 2, 1, fp) - 2;
}

int fwrite3 (int i, FILE *fp) {		/* unsigned int */
	unsigned int	k;

	k = i << 8;
	k = (CPU_is_littleendian) ? (unsigned int) swapInt(k) : k;
	return fwrite (&k, 3, 1, fp) - 3;
}

int fwriteFloat (float f, FILE *fp) {	/* float */
	float	g;

	g = (CPU_is_littleendian) ? swapFloat (f) : f;
	return fwrite (&g, 4, 1, fp) - 4;
}

int fread2 (short *v, FILE *fp)	{	/* short */
	short		k;
	int		ret;

	ret = fread (&k, 2, 1, fp);
	if (CPU_is_littleendian) k = swapShort (k);
	*v = k;

	return (ret);
}

int fread3 (int *v, FILE *fp) {		/* unsigned int */
	unsigned int	i = 0;
	int		ret;

	ret = fread (&i, 3, 1, fp);
	if (CPU_is_littleendian) i = (unsigned int) swapInt(i);
	*v = ((i >> 8) & 0xffffff);
	return (ret);
}

int fread4 (float *v, FILE *fp)	{	/* float */
	float		f;
	int		ret;

	ret = fread (&f, 4, 1, fp);
	if (CPU_is_littleendian) f = swapFloat (f);
	*v = f;

	return (ret);
}

int freadInt (FILE *fp) {
	int		i, nread;

	nread = fread (&i, sizeof(int), 1, fp);
	if (CPU_is_littleendian) i = swapInt (i);

	return (i);
}

float freadFloat (FILE *fp) {
	float		f;
	int		ret;

	ret = fread (&f, 4, 1, fp);
	if (CPU_is_littleendian) f = swapFloat (f);
	return (f);
}
