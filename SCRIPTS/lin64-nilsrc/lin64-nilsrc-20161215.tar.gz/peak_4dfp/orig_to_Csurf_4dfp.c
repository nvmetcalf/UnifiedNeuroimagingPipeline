/*$Header: /data/petsun4/data1/src_solaris/peak_4dfp/RCS/orig_to_Csurf_4dfp.c,v 1.2 2013/09/23 22:24:54 avi Exp $*/
/*$Log: orig_to_Csurf_4dfp.c,v $
 * Revision 1.2  2013/09/23  22:24:54  avi
 * change orig volume center 128. -> 127. in read_orig() to get better results in Csurf display
 *
 * Revision 1.1  2013/09/23  20:32:09  avi
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <Getifh.h>
#include <endianio.h>

#define MAXL		256

/*************/
/* externals */
/*************/
void	imgblur3d_ (float* fwhm, float* alpha, float* voxsiz, float* img0, int* imgdim, float* img1);	/* fimgblur.f */
int	read_wfile  (char *fname, float *vals, int vertexcnt);		/* wfile_io.c */
int	write_wfile (char *fname, float *vals, int vertexcnt);		/* wfile_io.c */

/********************/
/* global variables */
/********************/
static	char		program[MAXL];
static	char		rcsid[] = "$Id: orig_to_Csurf_4dfp.c,v 1.2 2013/09/23 22:24:54 avi Exp $";
static	float		*imgv;
static	int		nx, ny, nz;

typedef struct {
	float	x[3];			/* vertex coord */
	float	n[3];			/* surface norm */
	float	val;
} VTX;

/****************************************/
/* quoted from embed_Csurf_patch_4dfp.c */
/****************************************/
void burn (float *x, float bval) {
	int	ix, iy, iz;

	ix = 128. - x[0];	/* negative sign because surf coords run positive -> right */
	iy = 128. - x[1];	/* negative sign compensates for COR analyze<->4dfp flips */
	iz = 128. - x[2];	/* negative sign compensates for COR analyze<->4dfp flips */
	if (ix < 0 || ix >= nx
	||  iy < 0 || iy >= ny
	||  iz < 0 || iz >= nz) {
		fprintf (stderr, "%s: voxel index out of range %d %d %d\n", program, ix, iy, iz);
		exit (-1);
	}
	imgv[ix + nx*(iz + nz*iy)] = bval;	/* y and z swap because orig is coronal */
}

float read_orig (float *x) {
	int	ix, iy, iz;
	float	fx, fy, fz, wx, wy, wz, val;

	fx = 127. - x[0];	/* negative sign because surf coords run positive -> right */
	fy = 127. - x[1];	/* negative sign compensates for COR analyze<->4dfp flips */
	fz = 127. - x[2];	/* negative sign compensates for COR analyze<->4dfp flips */
	ix = (int) fx; wx = fx - (float) ix;
	iy = (int) fy; wy = fy - (float) iy;
	iz = (int) fz; wz = fz - (float) iz;

	if (fx < 0. || ix + 1 >= nx
	||  fy < 0. || iy + 1 >= ny
	||  fz < 0. || iz + 1 >= nz) {
		fprintf (stderr, "%s: voxel index out of range %d %d %d\n", program, ix, iy, iz);
		exit (-1);
	}

/**************************************************************/
/* y and z swap in offest computation because orig is coronal */
/**************************************************************/
	val =	(1. - wx)*(1. - wy)*(1. - wz)*imgv[(ix + 0) + nx*((iz + 0) + nz*(iy + 0))]+
		(0. + wx)*(1. - wy)*(1. - wz)*imgv[(ix + 1) + nx*((iz + 0) + nz*(iy + 0))]+
	  	(1. - wx)*(0. + wy)*(1. - wz)*imgv[(ix + 0) + nx*((iz + 0) + nz*(iy + 1))]+
		(0. + wx)*(0. + wy)*(1. - wz)*imgv[(ix + 1) + nx*((iz + 0) + nz*(iy + 1))]+
		(1. - wx)*(1. - wy)*(0. + wz)*imgv[(ix + 0) + nx*((iz + 1) + nz*(iy + 0))]+
		(0. + wx)*(1. - wy)*(0. + wz)*imgv[(ix + 1) + nx*((iz + 1) + nz*(iy + 0))]+
	 	(1. - wx)*(0. + wy)*(0. + wz)*imgv[(ix + 0) + nx*((iz + 1) + nz*(iy + 1))]+
	 	(0. + wx)*(0. + wy)*(0. + wz)*imgv[(ix + 1) + nx*((iz + 1) + nz*(iy + 1))];
	return val;
}

void errq (char *filspc) {
	fprintf (stderr, "%s: %s file format error\n", program, filspc);
	exit (-1);
}

int split (char *string, char *srgv[], int maxp) {
	int	i, m;
	char	*ptr;

	if (ptr = strchr (string, '#')) *ptr = '\0';
	i = m = 0;
	while (m < maxp) {
		while (!isgraph ((int) string[i]) && string[i]) i++;
		if (!string[i]) break;
		srgv[m++] = string + i;
		while (isgraph ((int) string[i])) i++;
		if (!string[i]) break;
		string[i++] = '\0';
	}
	return m;
}

static void usage () {
	printf ("Usage:	%s <(4dfp) orig space imgroot> <(Csurf vertex file> <output .w file>\n", program);
	printf ("\toption\n");
	printf ("\t-t<flt>\taverage outward from gray-white boundary by specified mm\n");
	printf ("\t-b<flt>\tsmooth volume using blur of specified FWHM in mm\n");
	printf ("N.B.:	%s reads only the first volume of <(4dfp) orig space imgroot>\n", program);
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*imgfp;			/* 4dfp i/o */
	FILE		*fp;			/* Csurf file i/o */

/*************/
/* image i/o */
/*************/
	IFH		imgifh;
	char		*ptr, *srgv[MAXL], command[MAXL];
	char		imgroot[MAXL], imgfile[MAXL], ifhfile[MAXL];
	char		vtxfile[MAXL], nrmfile[MAXL];
	char		wfile[MAXL], wout[MAXL];
	int		isbig;

/*********************/
/* optional pre-blur */
/*********************/
	float		alpha = 0.02;
	float		*imgt;

/***************/
/* computation */
/***************/
	VTX		*vtx;
	int		nvtx, vdim;
	int		c, i, j, k, m;
	float		fwhm = 0.0, thickness = 0.0;
	float		t, x[3], *vals;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		debug = 0;

	printf ("%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

/******************************/
/* get command line arguments */
/******************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'd': debug++;			break;
				case 't': thickness = atof (ptr);	*ptr = '\0'; break;
				case 'b': fwhm = atof (ptr);		*ptr = '\0'; break;
			}
		} else switch (k) {
		 	case 0: getroot (argv[i], imgroot);		k++; break;
		 	case 1: strcpy  (vtxfile, argv[i]);		k++; break;
		 	case 2: strcpy  (wout,    argv[i]);		k++; break;
		}
	}
	if (k < 3) usage ();

/*****************/
/* read vtx file */
/*****************/
	if (!(fp = fopen (vtxfile, "r"))) errr (program, vtxfile);
	printf ("Reading: %s\n", vtxfile);
	nvtx = 0; while (fgets (command, MAXL, fp)) {
		if (debug) printf ("%s", command);
		if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
		if (m != 4) errq (vtxfile);
		nvtx++;
	}
	if (!(vtx = (VTX *) calloc (nvtx, sizeof (VTX)))) errm (program);
	rewind (fp);
	nvtx = 0; while (fgets (command, MAXL, fp)) {
		if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
		if ((i = atoi (srgv[0])) != nvtx) errq (vtxfile);
		for (k = 0; k < 3; k++) vtx[nvtx].x[k] = atof (srgv[k + 1]);
		nvtx++;
	}
	fclose (fp);
	printf ("nvtx = %d\n", nvtx);
	if (0) for (i = 0; i < 5; i++) {
		printf ("%10d%10.4f%10.4f%10.4f\n", i, vtx[i].x[0], vtx[i].x[1], vtx[i].x[2]);
	}

/******************/
/* read norm file */
/******************/
	if (thickness > 0.) {
		strcpy (nrmfile, vtxfile);
		if (!(ptr = strrchr (nrmfile, '.'))) errq (nrmfile);
		strcpy (ptr, ".norm");
		if (!(fp = fopen (nrmfile, "r"))) errr (program, nrmfile);
		printf ("Reading: %s\n", nrmfile);
		i = 0; while (fgets (command, MAXL, fp)) {
			if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
			if (atoi (srgv[0]) != i) errq (vtxfile);
			for (k = 0; k < 3; k++) vtx[i].n[k] = atof (srgv[k + 1]);
			i++;
		}
		fclose (fp);
		if (0) for (i = 0; i < 5; i++) {
			printf ("%10d%10.6f%10.6f%10.6f\n", i, vtx[i].n[0], vtx[i].n[1], vtx[i].n[2]);
		}
		if (i != nvtx) {
			printf ("%s %s vertex count mismatch (%d %d)\n", vtxfile, nrmfile, nvtx, i);
			exit (-1);
		}
	}

/**************/
/* read image */
/**************/
	sprintf (ifhfile, "%s.4dfp.ifh", imgroot);
	printf ("Reading: %s\n", ifhfile);
	if (Getifh (ifhfile, &imgifh)) errr (program, ifhfile);
	isbig = strcmp (imgifh.imagedata_byte_order, "littleendian");
	printf ("image dimensions \t%10d%10d%10d\n",
		imgifh.matrix_size[0], imgifh.matrix_size[1], imgifh.matrix_size[2]);
	printf ("image mmppix     \t%10.6f%10.6f%10.6f\n",
		imgifh.mmppix[0], imgifh.mmppix[1], imgifh.mmppix[2]);
	printf ("image center     \t%10.4f%10.4f%10.4f\n",
		imgifh.center[0], imgifh.center[1], imgifh.center[2]);
	printf ("image orientation\t%10d\n", imgifh.orientation);

	nx = imgifh.matrix_size[0];
	ny = imgifh.matrix_size[1];
	nz = imgifh.matrix_size[2];
	if (imgifh.orientation != 3 || nx != 256 || ny != 256 || nz !=256) {
		fprintf (stderr, "%s: %s not in standard COR orig format\n", program, imgroot);
		exit (-1);
	}
	vdim = nx*ny*nz;
	if (!(imgv = (float *) malloc (vdim * sizeof (float)))) errm (program);
	sprintf (imgfile, "%s.4dfp.img", imgroot);
	printf ("Reading: %s\n", imgfile);
	if (!(imgfp = fopen (imgfile, "rb")) || eread (imgv, vdim, isbig, imgfp)
	|| fclose (imgfp)) errr (program, imgfile);

/***********************/
/* optionally pre-blur */
/***********************/
	if (fwhm > 0.0) {
		if (!(imgt = (float *) malloc (vdim * sizeof (float)))) errm (program);
		imgblur3d_ (&fwhm, &alpha, imgifh.scaling_factor, imgv, imgifh.matrix_size, imgt);
		for (i = 0; i < vdim; i++) imgv[i] = imgt[i];
		free (imgt);
	}

/*****************************/
/* project volume -> surface */
/*****************************/
	if (!(vals = (float *) calloc (nvtx, sizeof (float)))) errm (program);
	for (k = 0; k < nvtx; k++) {
		for (t = m = i = 0; i <= (int) 2.0*thickness; i++) {
			for (j = 0; j < 3; j++) x[j] = vtx[k].x[j] + 0.5*i*vtx[k].n[j];
			t += read_orig (x); m++;
		}
		vtx[k].val = vals[k] = t/m;
	}

/****************/
/* write output */
/****************/
	k = strlen (wout) - 2; if (!strcmp (wout + k, ".w")) wout[k] = '\0';
	sprintf (wfile, "%s.w", wout);
	status = write_wfile (wfile, vals, nvtx);

	free (vals);
	free (imgv);
	free (vtx);
	exit (status);
}
