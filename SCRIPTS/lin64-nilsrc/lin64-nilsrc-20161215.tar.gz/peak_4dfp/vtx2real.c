/*$Header: /data/petsun4/data1/src_solaris/peak_4dfp/RCS/vtx2real.c,v 1.1 2011/05/09 02:58:33 avi Exp $*/
/*$Log: vtx2real.c,v $
 * Revision 1.1  2011/05/09  02:58:33  avi
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <endianio.h>
#include <Getifh.h>

#define MAXL		256

/*************/
/* externals */
/*************/
extern void	vrtflip_  (int *orientation, int *imgdim, float *center, float *mmppix, float *centerr, float *mmppixr);

/********************/
/* global variables */
/********************/
static char	rcsid[] = "$Id: vtx2real.c,v 1.1 2011/05/09 02:58:33 avi Exp $";

int main (int argc, char *argv[]) {
	FILE		*lstfp, *outfp;	
	char		*ptr, *str, command[MAXL];
	char		program[MAXL];
	char		ifhroot[MAXL], ifhfile[MAXL], lstfile[MAXL], outfile[MAXL]; 

/***************/
/* computation */
/***************/
	IFH		ifh;
	float		mmppixr[3], centerr[3];
	float		x_4dfp[3], x_vtx[3], sign[3] = {-1., 1., 1.};	/* orig x index increments R->L */
	int		c, i, k;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		debug = 0;
	
	printf ("#%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

/******************************/
/* get command line arguments */
/******************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while ((c = *ptr++)) switch (c) {
				case 'd': debug++;	break;
			}
		} else switch (k) {
		 	case 0: getroot (argv[i], ifhroot);	k++; break;
		 	case 1: strcpy  (lstfile, argv[i]);	k++; break;
		}	
	}
	if (k < 2) {
		printf ("Usage: %s <(4dfp) orig> <freesurfer vtx file>\n", program);
		printf (" e.g.: %s 88_orig[.4dfp.img] rh.orig2.vtx\n", program);
		printf ("\toption\n");
		printf ("\t-d	debug mode\n");
		printf ("N.B.:\t%s converts FreeSurfer orig coordinates into 4dfp orig coordinates\n", program);
		exit (1);
	}

/************/
/* read ifh */
/************/
	sprintf (ifhfile, "%s.4dfp.img", ifhroot);
	printf ("Reading: %s\n", ifhfile);
	if (Getifh (ifhfile, &ifh)) errr (program, ifhfile);
	printf ("dimensions \t%10d%10d%10d%10d\n",
		ifh.matrix_size[0], ifh.matrix_size[1], ifh.matrix_size[2], ifh.matrix_size[3]);
	printf ("mmppix     \t%10.6f%10.6f%10.6f\n", ifh.mmppix[0], ifh.mmppix[1], ifh.mmppix[2]);
	printf ("center     \t%10.4f%10.4f%10.4f\n", ifh.center[0], ifh.center[1], ifh.center[2]);
	printf ("orientation\t%10d\n", ifh.orientation);

	if (debug) {
		printf ("orig mmppix     \t%10.6f%10.6f%10.6f\n", ifh.mmppix[0], ifh.mmppix[1], ifh.mmppix[2]); 
		printf ("orig center     \t%10.4f%10.4f%10.4f\n", ifh.center[0], ifh.center[1], ifh.center[2]);
	}

/************************/
/* list file name logic */
/************************/
	if (!(lstfp = fopen (lstfile, "r"))) errr (program, lstfile);\
	printf ("Reading: %s\n", lstfile);
	strcpy (command, lstfile);
	if (!(ptr = strrchr (command, '/'))) ptr = command; else ptr++;
	if   (str = strrchr (ptr, '.')) *str = 0;
	sprintf (outfile, "%s_4dfp.lst", ptr);
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	printf ("Writing: %s\n", outfile);

/***********/
/* process */
/***********/
	while (fgets (command, MAXL, lstfp)) {
		if (debug) printf ("%s", command);
		if ((ptr = strchr (command, '#'))) *ptr = '\0';
		if (sscanf (command, "%*d %f %f %f", x_vtx + 0, x_vtx + 1, x_vtx + 2) != 3) continue;
		if (0) printf ("%10.4f%10.4f%10.4f\n", x_vtx[0], x_vtx[1], x_vtx[2]);
		for (k = 0; k < 3; k++) x_4dfp[k] = sign[k]*(ifh.center[k]/ifh.mmppix[k] - 128.5) + x_vtx[k];
		fprintf (outfp, "%10.4f%10.4f%10.4f\n", x_4dfp[0], x_4dfp[1], x_4dfp[2]);
	}
	if (fclose (lstfp)) errr (program, lstfile);
	if (fclose (outfp)) errw (program, outfile);
	exit (status);
}
