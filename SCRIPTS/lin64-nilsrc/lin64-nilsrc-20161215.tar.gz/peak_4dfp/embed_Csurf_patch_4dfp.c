/*$Header: /data/petsun4/data1/src_solaris/peak_4dfp/RCS/embed_Csurf_patch_4dfp.c,v 1.9 2013/10/04 22:59:53 avi Exp $*/
/*$Log: embed_Csurf_patch_4dfp.c,v $
 * Revision 1.9  2013/10/04  22:59:53  avi
 * 128 -> 127 in burn() improves match of patch with anatomy
 *
 * Revision 1.8  2011/05/03  03:41:11  avi
 * allow for not reading normals when not needed
 *
 * Revision 1.7  2011/03/30  22:12:52  avi
 * correct but that manifests if option -l is not used
 *
 * Revision 1.6  2011/02/28  00:50:26  avi
 * minor correction
 *
 * Revision 1.5  2011/02/27  08:29:37  avi
 * option -b
 *
 * Revision 1.4  2011/02/26  03:17:30  avi
 * option -a
 * ifh fidl region compliant
 *
 * Revision 1.3  2011/02/25  06:47:04  avi
 * add options -V, -N
 * remove options -a, -v
 *
 * Revision 1.2  2011/02/25  04:10:31  avi
 * multi-ROI output
 *
 * Revision 1.1  2011/02/23  06:52:27  avi
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <unistd.h>	/* R_OK */
#include <Getifh.h>
#include <endianio.h>
#include <rec.h>

#define MAXN		20		/* number of neighbor nodes in neifile */
#define MAXL		256

/*************/
/* externals */
/*************/
void	imgblur3d_ (float* fwhm, float* alpha, float* voxsiz, float* img0, int* imgdim, float* img1);	/* fimgblur.f */

/********************/
/* global variables */
/********************/
static	char		program[MAXL];
static	char		rcsid[] = "$Id: embed_Csurf_patch_4dfp.c,v 1.9 2013/10/04 22:59:53 avi Exp $";
static	IFH		imgifh;
static	float		*imgv;
static	int		nx, ny, nz;

typedef struct {
	float	x[3];			/* vertex coord */
	float	n[3];			/* surface norm */
	int	nnei, nei[MAXN];	/* neigbor vertices */
	float	label;			/* patch serial number */
} VTX;

void burn (float *x, float bval) {
	int	ix, iy, iz;

	ix = 127. - x[0];	/* negative sign because surf coords run positive -> right */
	iy = 127. - x[1];	/* negative sign compensates for COR analyze<->4dfp flips */
	iz = 127. - x[2];	/* negative sign compensates for COR analyze<->4dfp flips */
	if (ix < 0 || ix >= nx
	||  iy < 0 || iy >= ny
	||  iz < 0 || iz >= nz) {
		fprintf (stderr, "%s: voxel index out of range %d %d %d\n", program, ix, iy, iz);
		exit (-1);
	}
	imgv[ix + nx*(iz + nz*iy)] = bval;	/* iy and iz swap because orig is coronal */
}

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

char **calloc_char2 (int n1, int n2) {
	int	i;
	char	**a;

	if (!(a = (char **) malloc (n1 * sizeof (char *)))) errm (program);
	if (!(a[0] = (char *) calloc (n1 * n2, sizeof (char)))) errm (program);
	for (i = 0; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_char2 (char **a) {
	free (a[0]);
	free (a);
}

void errx (char *filspc) {
	fprintf (stderr, "%s: %s file name or format error\n", program, filspc);
	exit (-1);
}

void trim0 () {
	float	*imgt;
	int	ix, iy, iz, vdim, i, j, k, iskip;
	struct {
		float	l;
		int	n;
	} ln[6];

	vdim = nx*ny*nz;
	if (!(imgt = (float *) calloc (vdim, sizeof (float)))) errm (program);
	for (i = 0; i < vdim; i++) imgt[i] = imgv[i];

	for (i = 0; i < vdim; i++) {
		j = i;
		iz = j/(nx*ny);	j = j % (nx*ny);
		iy = j/nx;	j = j % nx;
		ix = j;
		for (iskip = j = 0; j < 6; j++) {
			switch (j) {
				case 0:	k =  -1;	if (ix < 0)		iskip++; break;
				case 1:	k *= -1;	if (ix == nx - 1)	iskip++; break;
				case 2:	k *= -nx;	if (iy < 0)		iskip++; break;
				case 3:	k *= -1;	if (iy == ny - 1)	iskip++; break;
				case 4:	k *= -ny;	if (iz < 0)		iskip++; break;
				case 5:	k *= -1;	if (iz == nz - 1)	iskip++; break;
			}
			ln[j].l = imgv[i + k];
		}
		if (iskip) continue;
		for (ln[j].n = j = 0; j < 6; j++) for (k = 0; k < 6; k++) if (ln[k].l == ln[j].l) ln[j].n++;
		for (j = 0; j < 6; j++) if (ln[j].n > 4) imgt[i] = ln[j].l;
	}

	for (i = 0; i < vdim; i++) imgv[i] = imgt[i];
	free (imgt);
}

void trim (int lmax, float fwhm) {
	float	alpha = 0.02;
	float	**imgt;
	int	vdim, i, l;

	vdim = nx*ny*nz;
	imgt = calloc_float2 (lmax + 1, vdim);

	for (l = 1; l <= lmax; l++) {
		printf ("l = %d\n", l);
		for (i = 0; i < vdim; i++) imgt[0][i] = (fabs (imgv[i] - l) < .1) ? imgv[i] : 0.0;
		imgblur3d_ (&fwhm, &alpha, imgifh.scaling_factor, imgt[0], imgifh.matrix_size, imgt[l]);
		for (i = 0; i < vdim; i++) imgt[l][i] = (imgt[l][i] > 0.5*l) ? (float) l : 0.0;
	}
	for (i = 1; i < vdim; i++) {
		imgv[i] = 0.0;
		for (l = 0; l <= lmax; l++) if (imgt[l][i]) imgv[i] = l;
	}

	free_float2 (imgt);
}

int split (char *string, char *srgv[], int maxp) {
	int	i, m;
	char	*ptr;

	if (ptr = strchr (string, '#')) *ptr = '\0';
	i = m = 0;
	while (m < maxp) {
		while (!isgraph ((int) string[i]) && string[i]) i++;
		if (!string[i]) break;
		srgv[m++] = string + i;
		while (isgraph ((int) string[i])) i++;
		if (!string[i]) break;
		string[i++] = '\0';
	}
	return m;
}

void cross (float *a, float *b, float *c) {
	c[0] =  a[1]*b[2] - a[2]*b[1];
	c[1] = -a[0]*b[2] + a[2]*b[0];
	c[2] =  a[0]*b[1] - a[1]*b[0];
}

float norm (float *a) {
	double	q;
	int	k;

	q = sqrt (a[0]*a[0] + a[1]*a[1] + a[2]*a[2]);
	for (k = 0; k < 3; k++) a[k] /= q;
	return q;
}

static void usage () {
	printf ("Usage:	%s <(4dfp) imgroot> <(Csurf vertex file> [<Csurf label file>]\n", program);
	printf ("   or:	%s <(4dfp) imgroot> <(Csurf vertex file> -l<lst of Csurf label files>\n", program);
	printf (" e.g.:	%s 88_orig rh.orig2.vtx rh-VP-88.label\n", program);
	printf ("   or:	%s 88_orig rh.orig2.vtx -l88.rh-all.lst\n", program);
	printf ("\toption\n");
	printf ("\t-V\tembed complete hemisphere (all otherwise unlabled vertices assigned value 1)\n");
	printf ("\t-N\tembed nearest vertex (default loci in <Csurf label file>\n");
	printf ("\t-a\tsuperimpose embedded ROIs on input image (default duplicate format with zero background)\n");
	printf ("\t-l<fil>\tcreate fidl-compatile ROI file from patches listed in named file\n");
	printf ("\t-t<flt>\tthicken surface outward from gray-white boundary by specified mm\n");
	printf ("\t-b<flt>\tsmooth output using blur of specified FWHM in mm\n");
	printf ("\t-@<b|l>\toutput big or little endian (default input endian)\n");
	printf ("N.B.:	to superimpose lh output on previously obtained rh results use\n");
	printf ("	%s 88_orig_88.rh.label lh.orig2.vtx -l88.lh-all.lst -a\n", program);
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*fp;			/* utility */
	FILE		*imgfp;			/* input image */
	FILE		*outfp;			/* output image */

/*************/
/* image i/o */
/*************/
	char		*ptr, *str, *srgv[MAXL], command[MAXL];
	char		imgroot[MAXL], imgfile[MAXL], ifhfile[MAXL];
	char		**roifile = 0, pntfile[MAXL] = "", lstfile[MAXL] = "";
	char		vtxfile[MAXL], neifile[MAXL], nrmfile[MAXL];
	char		outroot[MAXL], outfile[MAXL];
	char		control = '\0';

/***************/
/* computation */
/***************/
	VTX		*vtx;
	float		**x0, x[3], u[3], v[MAXN][3];
	int		ix, iy, iz, dim, nvox, isbig, npnt, nvtx;
	int		c, i, j, k, l, m;
	int		iROI, nROI, label0;
	float		bmax, fwhm = 0.0;
	double		q, thickness = 0.0, d2, d2min;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		debug = 0;
	int		super = 0;
	int		ROIout = 0;
	int		vtx_flag = 0;
	int		nearest_flag = 0;

	printf ("%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

/******************************/
/* get command line arguments */
/******************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'a': super++;			break;
				case 'V': vtx_flag++;			break;
				case 'N': nearest_flag++;		break;
				case 'd': debug++;			break;
				case 'l': strcpy (lstfile, ptr);	*ptr = '\0'; break;
				case 't': thickness = atof (ptr);	*ptr = '\0'; break;
				case 'b': fwhm = atof (ptr);		*ptr = '\0'; break;
				case '@': control = *ptr++;		*ptr = '\0'; break;
			}
		} else switch (k) {
		 	case 0: getroot (argv[i], imgroot);		k++; break;
		 	case 1: strcpy  (vtxfile, argv[i]);		k++; break;
		 	case 2: strcpy  (pntfile, argv[i]);		k++; break;
		}
	}
	ROIout = strlen (lstfile) > 0;
	if (k < 2) usage ();

/*****************/
/* read vtx file */
/*****************/
	if (!(fp = fopen (vtxfile, "r"))) errr (program, vtxfile);
	printf ("Reading: %s\n", vtxfile);
	nvtx = 0; while (fgets (command, MAXL, fp)) {
		if (debug) printf ("%s", command);
		if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
		if (m != 4) errx (vtxfile);
		nvtx++;
	}
	if (!(vtx = (VTX *) calloc (nvtx, sizeof (VTX)))) errm (program);
	rewind (fp);
	nvtx = 0; while (fgets (command, MAXL, fp)) {
		if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
		if ((i = atoi (srgv[0])) != nvtx) errx (vtxfile);
		for (k = 0; k < 3; k++) vtx[nvtx].x[k] = atof (srgv[k + 1]);
		if (vtx_flag) vtx[nvtx].label = 1;
		nvtx++;
	}
	fclose (fp);
	printf ("nvtx = %d\n", nvtx);
	if (0) for (i = 0; i < 5; i++) {
		printf ("%10d%10.4f%10.4f%10.4f\n", i, vtx[i].x[0], vtx[i].x[1], vtx[i].x[2]);
	}

/******************/
/* read norm file */
/******************/
	k = strlen (pntfile) + strlen (lstfile) + (thickness > 0.);
if (k) {	/* don't need normals if only vertices are to be embedded at zero thickness */
	strcpy (nrmfile, vtxfile);
	if (!(ptr = strrchr (nrmfile, '.'))) errx (nrmfile);
	strcpy (ptr, ".norm");
	if (!(fp = fopen (nrmfile, "r"))) errr (program, nrmfile);
	printf ("Reading: %s\n", nrmfile);
	i = 0; while (fgets (command, MAXL, fp)) {
		if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
		if (atoi (srgv[0]) != i) errx (vtxfile);
		for (k = 0; k < 3; k++) vtx[i].n[k] = atof (srgv[k + 1]);
		i++;
	}
	fclose (fp);
	if (0) for (i = 0; i < 5; i++) {
		printf ("%10d%10.6f%10.6f%10.6f\n", i, vtx[i].n[0], vtx[i].n[1], vtx[i].n[2]);
	}
}

if (0) {	/* compare nrmfile norms to computed norms */
/*****************/
/* read nei file */
/*****************/
	strcpy (neifile, vtxfile);
	if (!(ptr = strrchr (neifile, '.'))) errx (neifile);
	strcpy (ptr, ".neigh");
	if (!(fp = fopen (neifile, "r"))) errr (program, neifile);
	printf ("Reading: %s\n", neifile);
	i = 0; while (fgets (command, MAXL, fp)) {
		if (debug) printf ("%s", command);
		if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
		if (atoi (srgv[0]) != i) errx (vtxfile);
		if (m > MAXN + 1) errx (neifile);
		vtx[i].nnei = m - 1;
		for (k = 1; k < m; k++) vtx[i].nei[k - 1] = atoi (srgv[k]);
		i++;
	}
	fclose (fp);
	if (0) for (i = 0; i < 5; i++) {
		printf ("%10d", i);
		for (k = 0; k < vtx[i].nnei; k++) printf ("%10d", vtx[i].nei[k]);
		printf ("\n");
	}

	i = 627;
	i = 628;
	printf ("vertex %d coords\n", i);
	printf ("%10.4f%10.4f%10.4f\n", vtx[i].x[0], vtx[i].x[1], vtx[i].x[2]);
	printf ("neighboring coords\n");
	for (k = 0; k < vtx[i].nnei; k++) {
		j = vtx[i].nei[k];
		printf ("%10.4f%10.4f%10.4f\n", vtx[j].x[0], vtx[j].x[1], vtx[j].x[2]);
	}
	printf ("connectors\n");
	for (k = 0; k < vtx[i].nnei; k++) {
		j = vtx[i].nei[k];
		for (l = 0; l < 3; l++) v[k][l] = vtx[j].x[l] - vtx[i].x[l];
		printf ("%10.6f%10.6f%10.6f\n", v[k][0], v[k][1], v[k][2]);
	}
	printf ("normed connector cross products\n");
	for (k = 0; k < vtx[i].nnei; k++) for (j = k + 1; j < vtx[i].nnei; j++) {
		cross (v[k], v[j], u);
		q = norm (u);
		printf ("%10.6f%10.6f%10.6f (norm=%10.6f)\n", u[0], u[1], u[2], q);
	}
	printf ("norm\n");
	printf ("%10.6f%10.6f%10.6f\n", vtx[i].n[0], vtx[i].n[1], vtx[i].n[2]);
}

/************/
/* read ifh */
/************/
	sprintf (ifhfile, "%s.4dfp.ifh", imgroot);
	printf ("Reading: %s\n", ifhfile);
	if (Getifh (ifhfile, &imgifh)) errr (program, ifhfile);
	isbig = strcmp (imgifh.imagedata_byte_order, "littleendian");
	printf ("image dimensions \t%10d%10d%10d\n",
		imgifh.matrix_size[0], imgifh.matrix_size[1], imgifh.matrix_size[2]);
	printf ("image mmppix     \t%10.6f%10.6f%10.6f\n",
		imgifh.mmppix[0], imgifh.mmppix[1], imgifh.mmppix[2]);
	printf ("image center     \t%10.4f%10.4f%10.4f\n",
		imgifh.center[0], imgifh.center[1], imgifh.center[2]);
	printf ("image orientation\t%10d\n", imgifh.orientation);
	if (!control) control = (isbig) ? 'b' : 'l';

	nx = imgifh.matrix_size[0];
	ny = imgifh.matrix_size[1];
	nz = imgifh.matrix_size[2];
	if (imgifh.orientation != 3 || nx != 256 || ny != 256 || nz !=256) {
		fprintf (stderr, "%s: %s not in standard COR orig format\n", program, imgroot);
		exit (-1);
	}

/**********************************/
/* read or initialize image array */
/**********************************/
	dim = 1; for (k = 0; k < 3; k++) dim *= imgifh.matrix_size[k];
	if (!(imgv = (float *) calloc (dim, sizeof (float)))) errm (program);
	sprintf (imgfile, "%s.4dfp.img", imgroot);
	if (super) {
		printf ("Reading: %s\n", imgfile);
		if (!(imgfp = fopen (imgfile, "rb")) || eread (imgv, dim, isbig, imgfp)
		|| fclose (imgfp)) errr (program, imgfile);
		for (label0 = i = 0; i < dim; i++) if (imgv[i] > label0) label0 = imgv[i];
		label0++;
	} else {
		label0 = 2;
	}

/*******************/
/* scan input list */
/*******************/
	nROI = 0; 
	if (ROIout) {
		if (!(fp = fopen (lstfile, "r"))) errr (program, lstfile);
		printf ("Reading: %s\n", lstfile);
		while (fgets (command, MAXL, fp)) {
			if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
			nROI++;
		}
		rewind (fp);
		roifile = calloc_char2 (nROI, MAXL);
		iROI = 0; while (fgets (command, MAXL, fp)) {
			if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
			strncpy (roifile[iROI++], srgv[0], MAXL - 1);
		}
		fclose (fp);
	} else if (strlen (pntfile)) {
		roifile = calloc_char2 (1, MAXL);
		strncpy (roifile[nROI++], pntfile, MAXL - 1);
	}

/***********************/
/* parse point file[s] */
/***********************/
	for (iROI = 0; iROI < nROI; iROI++) {
		if (!(fp = fopen (roifile[iROI], "r"))) errr (program, roifile[iROI]);
		printf ("Reading: %s\n", roifile[iROI]);
		k = 0; while (fgets (command, MAXL, fp)) {
			if (debug) printf ("%s", command);
			if (!(m = split (command, srgv, MAXL))) continue;	/* skip blank lines */
			switch (m) {
			case 1:	npnt = atoi (srgv[0]);
				x0 = calloc_float2 (npnt, 3);
				break;
			case 4: case 5:	for (j = 0; j < 3; j++) x0[k][j] = atof (srgv[j + 1]);
				i = atoi (srgv[0]);
				if (i >= nvtx) {
					printf ("%s error: vertex in %s not in %s\n", program, roifile[iROI], vtxfile);
					exit (-1);
				}
				if (!nearest_flag) vtx[i].label = label0 + iROI;
				k++;
				break;
			default: errx (roifile[iROI]);
				break;
			}
		}
		fclose (fp);
		assert (k = npnt);
		printf ("npnt = %d\n", npnt);
		if (debug) {
			for (k = 0; k < npnt; k++) {
				for (j = 0; j < 3; j++) printf ("%10.4f", x0[k][j]);
				printf ("\n");
			}
		}

/**************************************/
/* for each point find nearest vertex */
/**************************************/
		if (nearest_flag) for (m = k = 0; k < npnt; k++) {
			d2min = 1.e6; for (i = 0; i < nvtx; i++) {
				for (d2 = j = 0; j < 3; j++) {
					q = x0[k][j] - vtx[i].x[j];
					d2 += q*q;
				}
				if (d2 < d2min) {
					d2min = d2;
					m = i;
				}
			}
			vtx[m].label = label0 + iROI;
			if (0) printf ("k=%d	m=%d	d=%f\n", k, m, sqrt(d2min));
			if (sqrt(d2min) > 2.) printf ("%s: %s %s coordinate mismatch\n", program, vtxfile, roifile[iROI]);
		}
		free_float2 (x0);
	}

/*********************/
/* burn in patch[es] */
/*********************/
	for (k = 0; k < nvtx; k++) if (vtx[k].label) {
		for (i = 0; i <= (int) 2.0*thickness; i++) {
			for (j = 0; j < 3; j++) x[j] = vtx[k].x[j] + 0.5*i*vtx[k].n[j];
			burn (x, vtx[k].label);
		}
	}

	for (bmax = i = 0; i < dim; i++) if (imgv[i] > bmax) bmax = imgv[i];

/**********************************/
/* optionally smooth rough voxels */
/**********************************/
	if (fwhm) {
		printf ("smoothing using %.2f mm blur\n", fwhm);
		trim ((int) bmax, fwhm);
	}

/****************/
/* write output */
/****************/
	strcpy (outroot, imgroot);
	if (!(ptr = strrchr (outroot, '/'))) ptr = outroot; else ptr++;
	strcpy (outroot, ptr);
	strcat (outroot, "_");
	if (ROIout) {
		strcpy (command, lstfile);
	} else if (strlen (pntfile)) {
		strcpy (command, pntfile);
	} else {
		strcpy (command, vtxfile);
	}
	if (!(ptr = strrchr (command, '/'))) ptr = command; else ptr++;
	if   (str = strrchr (ptr, '.')) *str = 0;
	strcat (outroot, ptr);
	sprintf (outfile, "%s.4dfp.img", outroot);
	printf ("Writing: %s\n", outfile);
	if (!(outfp = fopen (outfile, "wb")) || ewrite (imgv, dim, control, outfp)
	|| fclose (outfp)) errw (program, outfile);

/*******/
/* ifh */
/*******/
	imgifh.matrix_size[3] = 1;
	writeifhe (program, outfile, imgifh.matrix_size, imgifh.scaling_factor, imgifh.orientation, control);
/***********************************/
/* fidl-oriented region label code */
/***********************************/
	sprintf (outfile, "%s.4dfp.ifh", outroot);
	if (super) {
		sprintf (command, "grep \"region names\" %s >> %s", ifhfile, outfile);
		printf ("%s\n", command);
		status |= system (command);
	}
	if (!(outfp = fopen (outfile, "a"))) errw (program, outfile);
	for (iROI = 0; iROI < nROI; iROI++) {
		if (!(ptr = strrchr (roifile[iROI], '/'))) ptr = roifile[iROI]; else ptr++;
		if   (str = strrchr (ptr, '.')) *str = 0;
		for (nvox = i = 0; i < dim; i++) if (imgv[i] == (float) (label0 + iROI)) nvox++;
		fprintf (outfp, "region names\t:= %-5d%     -20s\n", label0 + iROI - 2, ptr);
	}
	fclose (outfp);

/***************/
/* analyze hdr */
/***************/
	sprintf (command, "ifh2hdr %s -r%d", outroot, (int) bmax);
	printf ("%s\n", command); status |= system (command);

/*******/
/* rec */
/*******/
	sprintf    (outfile, "%s.4dfp.img", outroot);
	startrecle (outfile, argc, argv, rcsid, control);
	catrec (imgfile);
	if (ROIout) {
		printrec ("ROIlist\n");
		catrec (lstfile);
		printrec ("endROIlist\n");
	}
	if (fwhm) {
		sprintf (command, "Output smoothed using %.2f FWHM blur\n", fwhm);
		printrec (command);
	}
	endrec ();

	free (imgv);
	if (roifile) free_char2 (roifile);
	free (vtx);
	exit (status);
}
