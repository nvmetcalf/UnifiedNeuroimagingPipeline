/*$Header$*/
/*$Log$*/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <Getifh.h>
#include <endianio.h>
#include <flip_4dfp.h>	/* used by x4dfp2analyze() */
#include <rec.h>

#define MAXL		256

/***********/
/* globals */
/***********/
static	char		program[MAXL];
static	char		rcsid[] = "$Id$";
int	x4dfp2analyze (float *imag, int *dim, int orientation);		/* below; also in crop_4dfp.c */

int main (int argc, char *argv[]) {
	FILE		*imgfp;			/* image i/o */
	IFH		ifh;

/*************/
/* image i/o */
/*************/
	char		*ptr, command[MAXL], *srgv[MAXL];
	char		imgroot[MAXL], imgfile[MAXL];
	char		outroot[MAXL] = "", outfile[MAXL];
	char		control = '\0';
	int		imgdim[4], isbig;

/***************/
/* computation */
/***************/
	float		*imgi, *imgo, vmax = 0.0;
	int		ix, iy, iz, vdim;
	int		jx, jy, jz;
	int		lndex, kndex, jndex;
	int		c, i, j, k;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		debug = 0;

	printf ("%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

/******************************/
/* get command line arguments */
/******************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-' && k > 2) {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case '@': control = *ptr++;		*ptr = '\0'; break;
			}
		} else switch (k) {
		 	case 0: getroot (argv[i], imgroot);		k++; break;
			case 1: getroot (argv[i], outroot);		k++; break;
		}
	}
	if (k < 1) {
		printf ("Usage:	%s <4dfp imgroot> [4dfp outroot]\n", program);
		printf ("\toption\n");
		printf ("\t-@<b|l>\toutput big or little endian (default input endian)\n");
		printf ("N.B.:\toutput root default is \"<imgroot>_3Dconv\"\n");
		printf ("N.B.:\t%s reads only the first frame of <imgroot>\n", program);
		exit (1);
	}

	sprintf (imgfile, "%s.4dfp.img", imgroot);
	if (Getifh (imgfile, &ifh)) errr (program, imgfile);
	for (k = 0; k < 4; k++) imgdim[k] = ifh.matrix_size[k];
	isbig = strcmp (ifh.imagedata_byte_order, "littleendian");
	isbig = (isbig) ? 1 : 0;
	if (!control) control = (isbig) ? 'b' : 'l';
	vdim = imgdim[0]*imgdim[1]*imgdim[2];

	if (!(imgi = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgo = (float *) calloc (vdim, sizeof (float)))) errm (program);

	printf ("Reading: %s\n", imgfile);
	if (!(imgfp = fopen (imgfile, "rb")) || eread (imgi, vdim, isbig, imgfp)
	|| fclose (imgfp)) errr (program, imgfile);
	x4dfp2analyze (imgi, imgdim, ifh.orientation);

	for (iz = 0; iz < imgdim[2]; iz++) {
	for (iy = 0; iy < imgdim[1]; iy++) {
	for (ix = 0; ix < imgdim[0]; ix++) {
		kndex = ix + imgdim[0]*(iy + iz*imgdim[1]);
		for (jz = 0; jz < imgdim[2] - iz; jz++) {
		for (jy = 0; jy < imgdim[1] - iy; jy++) {
		for (jx = 0; jx < imgdim[0] - ix; jx++) {
			jndex = (jx +  0) + imgdim[0]*((jy +  0) + (jz +  0)*imgdim[1]);
			lndex = (jx + ix) + imgdim[0]*((jy + iy) + (jz + iz)*imgdim[1]);
			imgo[kndex] += imgi[jndex]*imgi[lndex];
		}}}
		imgo[kndex] /= vdim;
		if (imgo[kndex] > vmax) vmax = imgo[kndex];
	}}}

	if (!strlen (outroot)) sprintf (outroot, "%s_3Dconv", imgroot);
	sprintf (outfile, "%s.4dfp.img", outroot);
	x4dfp2analyze (imgo, imgdim, ifh.orientation);
	printf ("Writing: %s\n", outfile);
	if (!(imgfp = fopen (outfile, "wb")) || ewrite (imgo, vdim, control, imgfp)
	|| fclose (imgfp)) errw (program, outfile);

/*******/
/* ifh */
/*******/
	ifh.matrix_size[3] = 1;
	writeifhmce (program, outfile, ifh.matrix_size, ifh.scaling_factor, ifh.orientation,
		ifh.mmppix, ifh.center, control);

/***************/
/* analyze hdr */
/***************/
	sprintf (command, "ifh2hdr %s -r%d", outroot, (int) (vmax + 1.0));
	printf ("%s\n", command); status |= system (command);

/*******/
/* rec */
/*******/
	startrece (outfile, argc, argv, rcsid, control);
	sprintf (command, "Maximum %s.4dfp.img value %.4f\n", outroot, vmax); 
	printf ("%s", command); printrec (command);
	catrec (imgfile);
	endrec ();

	free (imgi); free (imgo);
	exit (status);
}

int x4dfp2analyze (float *imag, int *dim, int orientation) {
	switch (orientation) {
		case 4: flipx (imag, dim+0, dim+1, dim+2);	/* sagittal */
		case 3:	flipz (imag, dim+0, dim+1, dim+2);	/* coronal */
		case 2:	flipy (imag, dim+0, dim+1, dim+2);	/* transverse */
			return 0;
		default: return -1;				/* none of the above */
	}
}

