/*$Header$*/
/*$Log$*/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <Getifh.h>
#include <endianio.h>

#define MAXL		256

/***********/
/* globals */
/***********/
int read_wfile  (char *fname, float *vals, int vertexcnt);		/* wfile_io.c */
int write_wfile (char *fname, float *vals, int vertexcnt);		/* wfile_io.c */

static char rcsid[] = "$Id$";
int main (int argc, char *argv[]) {
	char		*ptr, program[MAXL];
	char		fname[] = "/data/goya/scratch/FreeSurfer0.8/sessions/GRE_02_B/image/phavg_polar/ccw_1-vreg+orig_i-lh.w";
	int		vertexcnt;
	float		*vals;
	FILE		*fp;

	printf ("%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

	if (!(fp = fopen (fname, "rb"))) errr (program, fname);
	printf ("Reading: %s\n", fname);
	fseek (fp, (long) 0, SEEK_END);
	if ((ftell(fp) - 5) % 7) errr (program, fname);
	vertexcnt = (ftell(fp) - 5)/7;
	fclose (fp);

	if (!(vals = (float *) calloc (vertexcnt, sizeof (float)))) errm (program);
	read_wfile  (fname,    vals, vertexcnt);
	write_wfile ("test.w", vals, vertexcnt);

	free (vals);
	return 0;
}
