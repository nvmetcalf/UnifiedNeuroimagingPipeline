/*$Id: 4dfptoascii.c,v 1.1 2014/12/30 05:02:40 avi Exp $*/
/*$Log: 4dfptoascii.c,v $
 * Revision 1.1  2014/12/30  05:02:40  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <rec.h>
#include <Getifh.h>
#include <endianio.h>
#include <conc.h>

#define MAXL 	256

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

static char rcsid[] = "$Id: 4dfptoascii.c,v 1.1 2014/12/30 05:02:40 avi Exp $";
int main (int argc, char *argv[]) {
	CONC_BLOCK	conc_block;			/* conc i/o control block */
	FILE 		*imgfp = NULL, *outfp = NULL;
	IFH		ifh;
	char 		imgroot[MAXL], imgfile[MAXL], outfile[MAXL];

/***************/
/* 4dfp arrays */
/***************/
	float		*imgt;				/* frame buffer */
	int		imgdim[4], vdim, isbig;

/***********/
/* utility */
/***********/
	int		c, i, j, k;
	char		*ptr, command[MAXL], program[MAXL];

/*********/
/* flags */
/*********/
	int		conc_flag = 0;
	int		status = 0;

	fprintf (stdout, "%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
			}
		}
		else switch (k) {
			case 0:	getroot (argv[i], imgroot);
				conc_flag = (strstr (argv[i], ".conc") == argv[i] + strlen (imgroot));
								k++; break;
			case 1:	strcpy (outfile, argv[i]);	k++; break;
		}	
	}
	if (k < 2) {
		printf ("Usage:	%s <(4dfp) in> <text file out>\n", program);
		printf ("\toption\n");
		exit (1);
	}

/*******************************************/
/* get 4dfp dimensions and open read/write */
/*******************************************/
	if (conc_flag) {
		conc_init (&conc_block, program);
		conc_open (&conc_block, imgroot);
		strcpy (imgfile, conc_block.lstfile);
		for (k = 0; k < 4; k++) imgdim[k] = conc_block.imgdim[k];
		isbig = conc_block.isbig;
	} else {
		sprintf (imgfile, "%s.4dfp.img", imgroot);
		if (Getifh (imgfile, &ifh)) errr (program, imgfile);
		for (k = 0; k < 4; k++) imgdim[k] = ifh.matrix_size[k];
		isbig = strcmp (ifh.imagedata_byte_order, "littleendian");
		if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);
	}
	printf ("Reading: %s\n", imgfile);
	vdim = imgdim[0]*imgdim[1]*imgdim[2];
	if (!(imgt = (float *) malloc (vdim*sizeof (float)))) errm (program);

	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	printf ("Writing: %s\n", outfile);

/***********/
/* process */
/***********/
	printf ("processing volume");
	for (k = 0; k < imgdim[3]; k++) {printf(" %d", k + 1); fflush (stdout);
		if (conc_flag) {
			conc_read_vol (&conc_block, imgt);
		} else {
			if (eread (imgt, vdim, isbig, imgfp)) errr (program, imgfile);
		}
		for (i = 0; i < vdim; i++) fprintf (outfp, " %.4f", imgt[i]);
		fprintf (outfp, "\n");
	}
	printf("\n");

/*********/
/* close */
/*********/
	if (conc_flag) {
		conc_free (&conc_block);
	} else {
		if (fclose (imgfp)) errr (program, imgfile);
	}
	if (fclose (outfp)) errr (program, outfile);

	free (imgt);
	exit (status);
}

