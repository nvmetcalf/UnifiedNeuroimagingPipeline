/*$Header: /home/usr/shimonyj/perfusion_4dfp/RCS/perfusion_4dfp.c,v 1.8 2010/09/13 03:13:27 avi Exp shimonyj $*/
/*$Log: perfusion_4dfp.c,v $
 * Revision 1.8  2010/09/13  03:13:27  avi
 * rationalized usage
 *
 * Revision 1.7  2010/09/13  01:51:34  avi
 * multiple revisions by JSS
 *
 * Revision 1.6  2009/02/25  00:42:29  avi
 * rationalize lmin-related initial params
 *
 * Revision 1.5  2009/02/25  00:10:31  shimonyj
 * assorted minor fixes
 *
 * Revision 1.4  2008/12/30  23:25:49  shimonyj
 * #include <JSSstatistics.h>
 * Now runs
 *
 * Revision 1.3  2008/12/29  05:31:10  avi
 * init params changes but still crashes
 **/
/*
** Perfusion version 1.0 (finalized in May 2008)
** Uses Non linear fitting to estimate perfusion parameters
** for either gamma variate or full perfusion model (no recirculation)
** This version only works on a single pixel that can be 
** generated or read from file 
**
** Perfusion version 2.0 
** expanded to read in full 4d data set
** 
** Perfusion version 3.0
** Linux version to interface with matlab
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <JSSutil.h>
#include <JSSstatistics.h>
#include <Getifh.h>
#include <endianio.h>
#include <rec.h>

#define MAXL		256

/*****************/
/* LM parameters */
/*****************/
#define SMAX		200	/* max number of time points */
#define SKIP		3	/* number of initial time points to skip */
#define TR_VOL		1.	/* default frame duration */
#define NPOP		50	/* number of population members */
#define MAXP		10	/* maximum number of params to estimate */
#define NVOLOUT		20	/* number of output volumes */
#define DELCHI		0.1	/* min change in chisq; original 0.1 */ 
#define NITER		3	/* number of iterations; original 2 */
#define THRESH		0.90	/* threshold for arrival of bolus */
#define PRT_FLG 	0	/* extra print flag */
#define NHIST		100	/* number of bins in histogram */

void mrqprior1(float x[], float y[],int ndata,float a[],int ia[],
	float aavg[],int ma,float **covar,float **alpha,float *logprob, float *alamda);
void mrqpcof(float x[],float y[],int ndata,float a[],int ia[],
	float aavg[],int ma, float **alpha, float beta[],float *logprob);
void perffunc1(float x, float a[], float *y, float dyda[], int na);
void perffunc0(float x, float a[], float *y, float dyda[], int na);
void gammavar(float x, float a[], float *y, float dyda[], int na);

int	debug_flag = 0;

/* returns log of the gamma function NR p. 214 */
float lngamm(float xx)
{
	double x,y,tmp,ser;
	static double cof[6]={76.18009172947146,-86.50532032941677,
		24.01409824083091,-1.231739572450155,
		0.1208650973866179e-2,-0.5395239384953e-5};
	int j;
	
	y=x=xx;
	tmp=x+5.5;
	tmp -= (x+0.5)*log(tmp);
	ser=1.000000000190015;
	for (j=0;j<=5;j++) ser += cof[j]/++y;
	return -tmp+log(2.5066282746310005*ser/x);
}

/*
** Generate fake perfusion curves with recirculation
** coefficients are:
**	a[1] = S0
**	a[2] = cbf
**	a[3] = t0
**	a[4] = alpha
**	a[5] = beta
**	a[6] = delta = 1/MTT, <0.5 since MTT > 2 sec
**	a[7] = gamma = 1/time const for steady state term
**	a[8] = eps = relative size of gamma variate (gv) term, <1.0 
**	a[9] = t1 = time of recirculation arrival
**	a[10] = nu = relative size of recirc
** 	requires:  beta > delta; beta > gamma; alpha+1 > 0;
**	requires: eps > nu;  t1 > t0;
*/
float perf_make1(float t, float a[])
{
	double gv0, gv1, con0, con1, t0, t1;
	double dexp0,dexp1,gexp0,gexp1,pgam0,pgam1,bapo0,dapo0;
	int i;
	
	/* check for bad values */
	if (a[5] <= a[6] || a[5] <= a[7]) {
		printf("Error(perf_make1): bad values %f %f %f\n", a[5],a[6],a[7]);
		return(a[1]);
	}

	t0 = t - a[3];
	t1 = t - a[9];

	/* check which segment of function relative to t0,t1 */
	/* for t < t0 */
	if (t <= a[3])  return (a[1]);

	/* for t0 < t < t1 */
	else if (t > a[3] && t < a[9]) {
		gv0 = gammp(a[4]+1.0, t0*(a[5]-a[6]))*pow(a[5],a[4]+1.0)*exp(-a[6]*t0)/pow(a[5]-a[6],a[4]+1.0);
		/*
		con0 = (1.0 - exp(-a[6]*t0))/a[6] + (exp(-a[7]*t0) - exp(-a[6]*t0))/(a[7] - a[6]);
		return a[1]*exp(-a[2]*(a[8]*gv0 + (1.0-a[8])*con0));
		*/
		return a[1]*exp(-a[2]*(a[8]*gv0));
	}

	/* for t > t1 */
	else {
		dexp0 = exp(-a[6]*t0);
		dexp1 = exp(-a[6]*t1);
		gexp0 = exp(-a[7]*t0);
		gexp1 = exp(-a[7]*t1);
		pgam0 = gammp(a[4]+1.0, t0*(a[5]-a[6]));
		pgam1 = gammp(a[4]+1.0, t1*(a[5]-a[6]));
		bapo0 = pow(a[5], a[4]+1.0);
		dapo0 = pow(a[5]-a[6], -a[4]-1.0);

		gv0 = pgam0*dexp0*bapo0*dapo0;
		gv1 = pgam1*dexp1*bapo0*dapo0;
		con0 = (1.0 - dexp0)/a[6] + (gexp0 - dexp0)/(a[7] - a[6]);
		con1 = (1.0 - dexp1)/a[6] + (gexp1 - dexp1)/(a[7] - a[6]);
		return a[1]*exp(-a[2]*(a[8]*gv0 + a[10]*gv1 + (1.0-a[8])*con1));
	}
}

/*
** Complete perfusion model, with NO recirculation
** coefficients are:
**	a[1] = S0
**	a[2] = cbf
**	a[3] = t0
**	a[4] = alpha
**	a[5] = beta
**	a[6] = delta = 1/MTT, <0.5 since MTT > 2 sec
**	a[7] = gamma = 1/time const for steady state term
**	a[8] = eps = relative size of SS const term
** requires:  beta > delta; beta > ssinvt;
** size constants:  eps*gv0 + (1-eps)*(SS const term)
*/
void perffunc0(float x, float a[], float *y, float dyda[], int na)
{
	double gv,con,t0,dexp,gexp,gapo,pgam,bapo,dapo,gdrv,pdrv;
	double tiny = 1.0e-3;
	int i;
	
	for (i=1; i<=8; i++) dyda[i] = 0.0;
	/* check for early time */
	/* for t < t0 */
	if (x <= a[3]) {
		*y = a[1];
		dyda[1] = 1.0;
		return;
	}

	/* check for bad values */
	if (a[4]+1.0-tiny <= 0.0 || a[4] > 20.0 || a[5] <= a[6] || a[5] <= a[7] || a[6]==a[7] || a[6]<=0.0) {
		*y = 100.0*a[1];  /* to discourage these */
		dyda[1] = 1.0;
		return;
	}

	/* for t > t0 */
	/* convenient substitutions */
	t0 = x - a[3];
	dexp = exp(-a[6]*t0);
	gexp = exp(-a[7]*t0);
	gapo = exp(lngamm(a[4]+1.0)); /* gamma of alpha plus one */
	pgam = gammp(a[4]+1.0, t0*(a[5]-a[6]));
	/* approximate derivative of incomplete gamma with respect to 1st index */
	pdrv = (gammp(a[4]+1.0+tiny, t0*(a[5]-a[6])) - gammp(a[4]+1.0-tiny, t0*(a[5]-a[6])))/(2.0*tiny);
	bapo = pow(a[5], a[4]+1.0);
	dapo = pow(a[5]-a[6], -a[4]-1.0);
	/* derivative of incomplete gamma with respect to 2nd index */
	gdrv = exp(-t0*(a[5]-a[6]))*pow(t0*(a[5]-a[6]),a[4])/gapo; 

	gv = pgam*dexp*bapo*dapo;
	con = (1.0 - dexp)/a[6] + (gexp - dexp)/(a[7] - a[6]);
	*y = a[1]*exp(-a[2]*(a[8]*gv + (1.0-a[8])*con));

	dyda[1] = *y/a[1];
	dyda[2] = *y*(-a[8]*gv - (1.0-a[8])*con);

	dyda[3] = *y*(-a[2]*a[8])*bapo*dapo*
		( (a[5]-a[6])*gdrv*dexp + pgam*(-a[6])*dexp );
	dyda[3] += *y*(-a[2])*(1.0-a[8])*((a[6]*dexp - a[7]*gexp)/(a[7]-a[6]) + dexp);
	dyda[3] *= (-1.0);   /* convert */

	
	dyda[4] = *y*(-a[2]*a[8])*dexp*
		( pdrv*bapo*dapo + 
		pgam*bapo*dapo*log(a[5]/(a[5]-a[6])) );
	
	dyda[5] = *y*(-a[2]*a[8])*dexp*
		( t0*gdrv*bapo*dapo + 
		pgam*(a[4]+1.0)*pow(a[5],a[4])*dapo + 
		pgam*bapo*(-a[4]-1.0)*pow(a[5]-a[6],-a[4]-2.0) );

	dyda[6] = *y*(-a[2]*a[8])*bapo*
		( -t0*gdrv*dexp*dapo + 
		pgam*(-t0*dexp)*dapo + 
		pgam*dexp*(a[4]+1.0)*pow(a[5]-a[6],-a[4]-2.0) );
	dyda[6] += *y*(-a[2])*(1.0-a[8])*dexp*(t0 - 1.0/(a[7]-a[6]))/(a[7]-a[6]);
	dyda[6] += *y*(-a[2])*(1.0-a[8])*((dexp-1.0)/(a[6]*a[6]) + t0*dexp/a[6]);
	dyda[6] += *y*(-a[2])*(1.0-a[8])*gexp/((a[7]-a[6])*(a[7]-a[6]));

	dyda[7] = *y*(-a[2])*(1.0-a[8])*gexp*(-1.0/(a[7]-a[6])-t0)/(a[7]-a[6]);
	dyda[7] += *y*(-a[2])*(1.0-a[8])*dexp/((a[7]-a[6])*(a[7]-a[6]));

	dyda[8] = *y*(-a[2]*gv + a[2]*con);

	return;
}

/*
** Complete perfusion model, WITH recirculation
** coefficients are:
**	a[1] = S0
**	a[2] = cbf
**	a[3] = t0
**	a[4] = alpha
**	a[5] = beta
**	a[6] = delta = 1/MTT, <0.5 since MTT > 2 sec
**	a[7] = gamma = 1/time const for steady state term
**	a[8] = eps = relative size of main bolus
**	a[9] = t1 = time of recirculation peak
**	a[10] = nu = relative size of recirculation
** 	requires:  beta > delta; beta > gamma; alpha+1 > 0;
**	requires: eps > nu;  t1 > t0;
** size constants:  eps*gv0 + nu*gv1 + (1-eps)*(SS const term)
*/
void perffunc1(float x, float a[], float *y, float dyda[], int na)
{
	double gv0,con0,t0,dexp0,gexp0,gapo0,pgam0,bapo0,dapo0,gdrv0,pdrv0;
	double gv1,con1,t1,dexp1,gexp1,gapo1,pgam1,bapo1,dapo1,gdrv1,pdrv1;
	double tiny = 1.0e-3;
	int i;
	
	/* check for bad values */
	if (a[4]+1.0-tiny<=0.0 || a[4] > 20.0 || a[5]<=a[6] || a[5]<=a[7] || 
	a[6]==a[7] || a[6]<=0.0 || a[9]<a[3] || a[10]>a[8] ) {
		*y = 100.0*a[1];  /* to discourage these */
		dyda[1] = 1.0;
		for (i=2; i<=10; i++) dyda[i] = 0.0;
		return;
	}

	/* time < t0 ********************************/
	if (x <= a[3]) {

		*y = a[1];
		dyda[1] = 1.0;
		for (i=2; i<=10; i++) dyda[i] = 0.0;
		return;

	}
	/* t0 < time < t1 ********************************/
	else if (x > a[3] && x <= a[9]) {

		t0 = x - a[3];  /* NOTE: t0 here is actually t-t0 from notes */
		dexp0 = exp(-a[6]*t0);
		gexp0 = exp(-a[7]*t0);
		gapo0 = exp(lngamm(a[4]+1.0)); /* gamma of alpha plus one */
		pgam0 = gammp(a[4]+1.0, t0*(a[5]-a[6]));
		/* approximate derivative of incomplete gamma with respect to 1st index */
		pdrv0 = (gammp(a[4]+1.0+tiny, t0*(a[5]-a[6])) - gammp(a[4]+1.0-tiny, t0*(a[5]-a[6])))/(2.0*tiny);
		bapo0 = pow(a[5], a[4]+1.0);
		dapo0 = pow(a[5]-a[6], -a[4]-1.0);
		/* derivative of incomplete gamma with respect to 2nd index */
		gdrv0 = exp(-t0*(a[5]-a[6]))*pow(t0*(a[5]-a[6]),a[4])/gapo0; 

		gv0 = pgam0*dexp0*bapo0*dapo0;
		/* prior attempt 
		con0 = (1.0 - dexp0)/a[6] + (gexp0 - dexp0)/(a[7] - a[6]);
		*y = a[1]*exp(-a[2]*(a[8]*gv0 + (1.0-a[8])*con0));
		*/
		*y = a[1]*exp(-a[2]*(a[8]*gv0));

		dyda[1] = *y/a[1];
		dyda[2] = *y*(-a[8]*gv0);

		dyda[3] = *y*(-a[2]*a[8])*bapo0*dapo0*
			( (a[5]-a[6])*gdrv0*dexp0 + pgam0*(-a[6])*dexp0 );
		dyda[3] *= (-1.0);   /* final sign conversion */

		
		dyda[4] = *y*(-a[2]*a[8])*dexp0*
			( pdrv0*bapo0*dapo0 + 
			pgam0*bapo0*dapo0*log(a[5]/(a[5]-a[6])) );
		
		dyda[5] = *y*(-a[2]*a[8])*dexp0*
			( t0*gdrv0*bapo0*dapo0 + 
			pgam0*(a[4]+1.0)*pow(a[5],a[4])*dapo0 + 
			pgam0*bapo0*(-a[4]-1.0)*pow(a[5]-a[6],-a[4]-2.0) );

		dyda[6] = *y*(-a[2]*a[8])*bapo0*
			( -t0*gdrv0*dexp0*dapo0 + 
			pgam0*(-t0*dexp0)*dapo0 + 
			pgam0*dexp0*(a[4]+1.0)*pow(a[5]-a[6],-a[4]-2.0) );

		dyda[7] = 0.0;

		dyda[8] = *y*(-a[2]*gv0);

		dyda[9] = 0.0;
		dyda[10] = 0.0;
	}
	/* t1 < time  ********************************/
	else {

		t0 = x - a[3];  /* NOTE: t0 here is actually t-t0 from notes */
		t1 = x - a[9];  /* NOTE: t1 here is actually t-t1 from notes */
		dexp0 = exp(-a[6]*t0);
		dexp1 = exp(-a[6]*t1);
		gexp0 = exp(-a[7]*t0);
		gexp1 = exp(-a[7]*t1);
		gapo0 = exp(lngamm(a[4]+1.0)); /* gamma of alpha plus one */
		pgam0 = gammp(a[4]+1.0, t0*(a[5]-a[6]));
		pgam1 = gammp(a[4]+1.0, t1*(a[5]-a[6]));
		/* approximate derivative of incomplete gamma with respect to 1st index */
		pdrv0 = (gammp(a[4]+1.0+tiny, t0*(a[5]-a[6])) - gammp(a[4]+1.0-tiny, t0*(a[5]-a[6])))/(2.0*tiny);
		pdrv1 = (gammp(a[4]+1.0+tiny, t1*(a[5]-a[6])) - gammp(a[4]+1.0-tiny, t1*(a[5]-a[6])))/(2.0*tiny);
		bapo0 = pow(a[5], a[4]+1.0);
		dapo0 = pow(a[5]-a[6], -a[4]-1.0);
		/* derivative of incomplete gamma with respect to 2nd index */
		gdrv0 = exp(-t0*(a[5]-a[6]))*pow(t0*(a[5]-a[6]),a[4])/gapo0; 
		gdrv1 = exp(-t1*(a[5]-a[6]))*pow(t1*(a[5]-a[6]),a[4])/gapo0; 

		gv0 = pgam0*dexp0*bapo0*dapo0;
		gv1 = pgam1*dexp1*bapo0*dapo0;
		con0 = (1.0 - dexp0)/a[6] + (gexp0 - dexp0)/(a[7] - a[6]);
		con1 = (1.0 - dexp1)/a[6] + (gexp1 - dexp1)/(a[7] - a[6]);
		*y = a[1]*exp(-a[2]*(a[8]*gv0 + a[10]*gv1 + (1.0-a[8])*con1));

		dyda[1] = *y/a[1];
		dyda[2] = *y*(-a[8]*gv0 - a[10]*gv1 - (1.0-a[8])*con0);

		dyda[3] = *y*(-a[2]*a[8])*bapo0*dapo0*
			( (a[5]-a[6])*gdrv0*dexp0 + pgam0*(-a[6])*dexp0 );
		dyda[3] *= (-1.0);   /* final sign conversion */

		
		dyda[4] = *y*(-a[2]*a[8])*dexp0*
			( pdrv0*bapo0*dapo0 + pgam0*bapo0*dapo0*log(a[5]/(a[5]-a[6])) );
		dyda[4] += *y*(-a[2]*a[10])*dexp1*
			( pdrv1*bapo0*dapo0 + pgam1*bapo0*dapo0*log(a[5]/(a[5]-a[6])) );
		
		dyda[5] = *y*(-a[2]*a[8])*dexp0*
			( t0*gdrv0*bapo0*dapo0 + pgam0*(a[4]+1.0)*pow(a[5],a[4])*dapo0 + 
			pgam0*bapo0*(-a[4]-1.0)*pow(a[5]-a[6],-a[4]-2.0) );
		dyda[5] += *y*(-a[2]*a[10])*dexp1*
			( t1*gdrv1*bapo0*dapo0 + pgam1*(a[4]+1.0)*pow(a[5],a[4])*dapo0 + 
			pgam1*bapo0*(-a[4]-1.0)*pow(a[5]-a[6],-a[4]-2.0) );

		dyda[6] = *y*(-a[2]*a[8])*bapo0*
			( -t0*gdrv0*dexp0*dapo0 + pgam0*(-t0*dexp0)*dapo0 + 
			pgam0*dexp0*(a[4]+1.0)*pow(a[5]-a[6],-a[4]-2.0) );
		dyda[6] += *y*(-a[2]*a[10])*bapo0*
			( -t1*gdrv1*dexp1*dapo0 + pgam1*(-t1*dexp1)*dapo0 + 
			pgam1*dexp1*(a[4]+1.0)*pow(a[5]-a[6],-a[4]-2.0) );
		dyda[6] += *y*(-a[2])*(1.0-a[8])*dexp1*(t0 - 1.0/(a[7]-a[6]))/(a[7]-a[6]);
		dyda[6] += *y*(-a[2])*(1.0-a[8])*((dexp1-1.0)/(a[6]*a[6]) + t0*dexp1/a[6]);
		dyda[6] += *y*(-a[2])*(1.0-a[8])*gexp1/((a[7]-a[6])*(a[7]-a[6]));

		dyda[7] = *y*(-a[2])*(1.0-a[8])*gexp1*(-1.0/(a[7]-a[6])-t0)/(a[7]-a[6]);
		dyda[7] += *y*(-a[2])*(1.0-a[8])*dexp1/((a[7]-a[6])*(a[7]-a[6]));

		dyda[8] = *y*(-a[2]*gv0 + a[2]*con1);

		dyda[9] = *y*(-a[2]*a[10])*bapo0*dapo0*
			( (a[5]-a[6])*gdrv1*dexp1 + pgam1*(-a[6])*dexp1 );
		dyda[9] += *y*(-a[2])*(1.0-a[8])*((a[6]*dexp1 - a[7]*gexp1)/(a[7]-a[6]) + dexp1);
		dyda[9] *= (-1.0);   /* final sign conversion */

		dyda[10] = *y*(-a[2]*gv1);

	}
	return;
}

/*
** Gamma Variate Model and derivatives for LM algorithm 
** coefficients are:
**	a[1] = S0
**	a[2] = k
**	a[3] = t0
**	a[4] = alpha
**	a[5] = beta
**	a[6] = eps = Steady state value
**	a[7] = gamma = Steady state time constant
*/
void gammavar(float x, float a[], float *y, float dyda[], int na)
{
	double gv, nrm;
	
	/* check which segment of function relative to t0 */
	/* constant segment */
	if (x <= a[3]) {
		*y = a[1];
		dyda[1] = 1.0;
		dyda[2] = 0.0;
		dyda[3] = 0.0;
		dyda[4] = 0.0;
		dyda[5] = 0.0;
		dyda[6] = 0.0;
		dyda[7] = 0.0;
		return;
	}
	/* gamma variate segment */
	/* with normalization - could not get to work
	nrm = pow(a[5],a[4]+1.0)/exp(lngamm(a[4]+1.0)); 
	gv = nrm*pow((x-a[3]),a[4])*exp(-a[5]*(x-a[3]));
	*y = a[1]*exp(-a[2]*gv) - a[6]*(1.0 - exp(-a[7]*(x-a[3])));
	dyda[1] = exp(-a[2]*gv);
	dyda[2] = a[1]*exp(-a[2]*gv)*(-gv);
	dyda[3] = a[1]*exp(-a[2]*gv)*(-a[2]*gv*a[5] + a[2]*a[4]*nrm*pow((x-a[3]),a[4]-1.0)*exp(-a[5]*(x-a[3])))
			+a[6]*exp(-a[7]*(x-a[3]))*(a[7]);
	dyda[4] = a[1]*exp(-a[2]*gv)*(-a[2])*(gv*log(x-a[3]) + gv*log(a[5]) - gv*dlngamm(a[4]+1.0));
	dyda[5] = a[1]*exp(-a[2]*gv)*(-a[2])*(gv*(a[3]-x) + nrm*gv*(a[4]+1.0)/a[5]);
	dyda[6] = -(1.0 - exp(-a[7]*(x-a[3])));
	dyda[7] = a[6]*exp(-a[7]*(x-a[3]))*(a[3]-x);
	*/
	/* no normalization */
	gv = pow((x-a[3]),a[4])*exp(-a[5]*(x-a[3]));
	*y = a[1]*exp(-a[2]*gv) - a[6]*(1.0 - exp(-a[7]*(x-a[3])));
	dyda[1] = exp(-a[2]*gv);
	dyda[2] = a[1]*exp(-a[2]*gv)*(-gv);
	dyda[3] = a[1]*exp(-a[2]*gv)*(-a[2]*gv*a[5] + a[2]*a[4]*pow((x-a[3]),a[4]-1.0)*exp(-a[5]*(x-a[3])))
			+a[6]*exp(-a[7]*(x-a[3]))*(a[7]);
	dyda[4] = a[1]*exp(-a[2]*gv)*(-a[2]*gv*log(x-a[3]));
	dyda[5] = a[1]*exp(-a[2]*gv)*(-a[2]*gv*(a[3]-x));
	dyda[6] = -(1.0 - exp(-a[7]*(x-a[3])));
	dyda[7] = a[6]*exp(-a[7]*(x-a[3]))*(a[3]-x);
	
	return;
}

/***********/
/* globals */
/***********/
static char rcsid[] = "$Id: perfusion_4dfp.c,v 1.8 2010/09/13 03:13:27 avi Exp shimonyj $";

void write_command_line (char *program, FILE *outfp, int argc, char *argv[]) {
	int		i;
	fprintf (outfp, "#%s", program);
	for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
	fprintf (outfp, "\n");
	fprintf (outfp, "#%s\n", rcsid);
}

void usage (char *program) {
	printf ("Usage:\t%s <file_4dfp>\n", program);
	printf (" e.g.,\t%s /data/nil-bluearc/shimony/HBO/hbo07a_090208/hbo07a_090208_perf_faln_xr3d\n", program);
	printf ("	option\n");
	printf ("	-V<int>,<int>,<int> compute only voxel with specificed indices (counting from 1 with analyze<->4dfp flips)\n");
	printf ("	-s<int>\tcompute only selected slice (counting from 1)\n");
	printf ("	-n<int>\tuse only this number of data points \n");
	printf ("	-h\tlist output volume parameters\n");
	printf ("	-a<int>\tperform local averaging, 1 2d3x3, 2 2d5x5, 3 3d3x3, 4 3d5x5\n");
	printf ("	-m<int>\tmedian filtering,options 2D:3x3=9,25,49,81,121,3D:27,125, def=9\n");
	printf ("	-R<int>\tRegularize options, 1: (def=1)\n");
	printf ("	-S<int>\tSingle AIF options, 1:set alpha,beta (def=1)\n");
	printf ("	-b<flt>\tthrow out bad estimates, smaller numbers more restrictive, def=3.0\n");
	printf ("	-l<flt>\tthrow out low bolus voxels, larger numbers more restrictive, def=2.5\n");
	printf ("	-r\tselect the model with recirculation \n");
	printf ("	-c\tcorrect CBV for leakage using Donahue MRM 2000, 43:845\n");
	printf ("	-@<b|l>\toutput big or little endian (default input endian)\n");
	exit (1);
}

/***************/
/* start main  */
/***************/
int main (int argc, char **argv) {
	void	gammavar(float x, float a[], float *y, float dyda[], int na);	/* above */
	float	lngamm(float xx);						/* above */
	float	perf_make1(float t, float a[]);					/* above */
	float	pixperf (int nparam, int ndata, float *x, float *y, float *aopt, float *aostd,
		int *lista, float *aavg, float *asig, float *amin, float *amax, float **covar, float **alpha);

	float	h[SMAX], tsc[SMAX];
	float	tr_vol = TR_VOL;
	char	*filename, *tscroot, *parroot;

	int	*lista, npix, npix0, npix1, npix2, nparam; 
	float	*x, *y, **covar, **alpha, logp;
	float	aopt1[MAXP+1], amin[MAXP+1], amax[MAXP+1], aavg[MAXP+1], asig[MAXP+1];
	float	aopt[MAXP+1], aostd[MAXP+1], dyda[MAXP+1], aoptrr[MAXP+1];
	float	avggray, tscmin;

/* CBV correction */
	float	sumr2, sumk, r2max, relR, r2eff[SMAX], r2avg[SMAX], r2sum[SMAX];
	float	sxz, sxy, syz, sx2, sy2, K1, K2, det, cbv, ccbv;
	float	sumpar[NVOLOUT], sumpar2[NVOLOUT], lpmax, lpmin;
	int	lphist[NHIST+1];

/***************/
/* 4dfp images */
/***************/
	FILE	*fp;
	IFH	ifh;
	char	imgroot[MAXL], outroot[MAXL];
	char	outfile[MAXL], ifhfile[MAXL], imgfile[MAXL];
	float	*imgt, *imgp, *imga, *imgv;
	char	*mask, *cmask;

	float 	voxdim[3];
	int	imgdim[4], sdim, vdim, tdim, orient, isbig;
	char	control = '\0';

/***********/
/* utility */
/***********/
	char	*str,  program[MAXL], command[MAXL];
	int	c, i, j, k, l, jndex, jndex1, lmin, ndata, l0, lstart, i1,j1,k1,navg,i2,j2,k2;
	int	nbline, nbad;
	float	bline, bline2, blstd, ssval, temp;
	double	q;
	char	*parnames[MAXP] = {"S0","CBF","t0","alpha","beta","delta","gamma","eps","t1","nu"};
	char	*vollabels[NVOLOUT] = {"S0", "CBF", "t0 (bolus time)", "alpha (AIF param)", "beta (AIF param)",
		"delta (1/MTT)", "gamma (model offset time constant)", "eps (bolus size)", "t1 (recirculation time)",
		"nu (relative recirculation size)", "MTT", "CBV=MTT*CBF", "-log(prob)", "baseline difference",
		"CBV from R2* calc", "Corrected CBV", "K1", "K2", "vol 19", "vol 20"};

/*********/
/* flags */
/*********/
	int	status = 0;
	int	slc_flag = 0, slcsel;
	int	single_vox_flag = 0, kndex, xsel, ysel, zsel;
	int	ndat_flag = 0, ndat;
	int	avg_flag = 0;
	int	median_flag = 0, medsize = 9;
	int	regular_flag = 0, regcode = 1;
	int	singaif_flag = 0, saifcode = 1;
	int	bad_flag = 0;
	int	lowbolus_flag = 0;
	int	recirc_flag = 0;
	int	ccbv_flag = 0;
	int	navg_slice = 1;
	float	bad_nstd = 3.0;
	float 	lowb_nstd = 2.0;
	int	bflag;

	/* sorting array for median filtering */
	float	sort[125]; 	/* allow for 11x11 in 2D or 5x5x5 in 3D */

	printf ("%s\n", rcsid);
	if (!(str = strrchr (argv[0], '/'))) str = argv[0]; else str++;
	strcpy (program, str);

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') { 
			strcpy (command, argv[i]); str = command;
			while (c = *str++) switch (c) {
				case '@': control = *str++;			*str = '\0'; break;
				case 's': slc_flag++; slcsel = atoi(str) - 1;	*str = '\0'; break;
				case 'n': ndat_flag++; ndat = atoi(str);	*str = '\0'; break;
				case 'm': median_flag++; medsize = atoi(str);	*str = '\0'; break;
				case 'S': singaif_flag++; saifcode = atoi(str);	*str = '\0'; break;
				case 'R': regular_flag++; regcode = atoi(str);	*str = '\0'; break;
				case 'a': avg_flag++; navg_slice = atoi(str);	*str = '\0'; break;
				case 'b': bad_flag++; bad_nstd = atof(str);	*str = '\0'; break;
				case 'l': lowbolus_flag++; lowb_nstd = atof(str);	*str = '\0'; break;
				case 'r': recirc_flag++; 			*str = '\0'; break;
				case 'c': ccbv_flag++; 				*str = '\0'; break;
				case 'V': single_vox_flag++;
					j = sscanf (str, "%d,%d,%d", &xsel, &ysel, &zsel);
					if (j != 3) usage (program);		*str = '\0'; break;
				case 'h': for (j = 0; j < NVOLOUT; j++) {
						printf ("%-5d %s\n", j + 1, vollabels[j]); 
					} exit (-1);				break;
			}
		} else switch (k) {
			case 0: getroot (argv[i], imgroot);	k++; break;
		}
	}
	if (k < 1) usage (program);

/************************/
/* get stack dimensions */
/************************/
	if (Getifh (imgroot, &ifh)) errr (program, imgroot);
	isbig = strcmp (ifh.imagedata_byte_order, "littleendian");
	printf ("isbig=%d\n", isbig);
	if (!control) control = (isbig) ? 'b' : 'l';
	for (k = 0; k < 4; k++) imgdim[k] = ifh.matrix_size[k];
	if (imgdim[3] > SMAX) imgdim[3] = SMAX;
	printf("stack dimensions: %d %d %d %d\n",imgdim[0],imgdim[1],imgdim[2],imgdim[3]);

/***************************************/
/* allocate input memory and get stack */
/***************************************/
	sdim = imgdim[0]*imgdim[1];
	vdim = imgdim[0]*imgdim[1]*imgdim[2];
	tdim = vdim*imgdim[3];

	/* allocate input data array */
	if (!(imgt = (float *) calloc (tdim, sizeof (float)))) errm (program);

	/* allocate output data array */
	if (!(imgp = (float *) calloc (vdim*NVOLOUT, sizeof(float)))) errm (program);

	/* allocate output data array */
	if (!(imga = (float *) calloc (vdim*NVOLOUT, sizeof(float)))) errm (program);

	/* allocate output data array */
	if (!(imgv = (float *) calloc (vdim, sizeof(float)))) errm (program);

	/* allocate mask and cmask array */
	if (!(mask = (char *) calloc (vdim, sizeof (char)))) errm (program);
	if (!(cmask = (char *) calloc (vdim, sizeof (char)))) errm (program);

	sprintf (imgfile, "%s.4dfp.img", imgroot);
	printf ("Reading: %s\n", imgfile);
	if (!(fp = fopen (imgfile, "rb")) || eread (imgt, tdim, isbig, fp)
	|| fclose (fp)) errr (program, imgfile);

/**************************/
/* allocate for LM method */
/**************************/
	lista=ivector(1,MAXP);
	x=vector(1,imgdim[3]);
	y=vector(1,imgdim[3]);
	covar=matrix(1,MAXP,1,MAXP);
	alpha=matrix(1,MAXP,1,MAXP);

/***************************************/
/* compute first volume global average */
/***************************************/
	for (avggray = i = 0; i < vdim; i++) avggray += imgt[i];
	avggray /= vdim;
	printf ("avg first frame pixel value = %5.2f\n", avggray);

/***************************************************/
/* get mean timecourse counting only bright voxels */
/* create mask and contrast mask		   */
/***************************************************/
	for (l = 0; l < imgdim[3]; l++) {
		tsc[l] = 0.0;
		r2avg[l] = 0.0;
		r2sum[l] = 0.0;
	}
	npix = npix0 = npix1 = npix2 = 0;
	for (i = 0; i < vdim; i++) {

		/* background pixels */
		if (imgt[i] < avggray) {
			mask[i] = 0;
			cmask[i] = 0;
		}

		/* foreground pixels */
		else {  
			mask[i] = 1;
			npix++;

			tscmin = 1.0e9;
			for (l = 0; l < imgdim[3]; l++) {
				tsc[l] += (imgt + l*vdim)[i];
				if (tscmin > (imgt + l*vdim)[i]) tscmin = (imgt + l*vdim)[i];
			}

			/* find 1st approx for base line avg and std */
			bline = 0.0;
			bline2 = 0.0;
			nbline = 10;
			for (l = SKIP; l < SKIP+nbline; l++) {
				temp = (imgt + l*vdim)[i];
				bline += temp;
				bline2 += temp*temp;
			}
			bline /= nbline;
			blstd = (bline2 - nbline*bline*bline)/(nbline - 1.0);
			blstd = sqrt(blstd);

			/* find approx for steady state value */
			ssval = 0.0;
			for (l = imgdim[3]-nbline; l < imgdim[3]; l++) ssval += (imgt + l*vdim)[i];
			ssval /= nbline;

			/* remove voxels with no bolus */
			if (tscmin > bline - lowb_nstd*blstd) {
				cmask[i] = 0;
				npix0++;
			}
			/* contrast mask for leakage corrections, ADJUST LEVEL? */
			else if (ssval > bline + 1.0*blstd) {
				cmask[i] = 2;
				npix2++;
			}
			/* standard pixels */
			else {
				cmask[i] = 1;
				npix1++;

				for (l = 0; l < imgdim[3]; l++) {
					temp = (imgt + l*vdim)[i];
					if (temp > bline || temp <=0.0) temp = bline;
					r2avg[l] += log(bline/temp);
				}
			}
		}
	}

	if (npix == 0) { 
		fprintf (stderr, "%s: no foreground pixels\n", program);
		exit (-1);
	}

	for (l = 0; l < imgdim[3]; l++) { 
		tsc[l] /= npix;
		r2avg[l] /= npix1;
	}
	r2sum[0] = r2avg[0];
	for (l = 1; l < imgdim[3]; l++) { 
		r2sum[l] = r2sum[l-1] + r2avg[l];
	}

	printf("Num vol pix = %d; fg pixel = %d (%5.2f); bg pixel = %d (%5.2f); \n",
		vdim,npix,(float)npix/vdim,(vdim-npix),(float)(vdim-npix)/vdim);
	printf("Number of time points %d\n", imgdim[3]);
	printf("Number of no-bolus pix = %d; non-con pix = %d; contrast pix = %d; \n",npix0,npix1,npix2);

/***********************************/
/* find approximate initial values */
/***********************************/

	for (i = 1; i <= imgdim[3]-SKIP; i++) {
		x[i] = (float) i - 1;
		y[i] = tsc[i - 1 + SKIP];
		printf("%f %f\n", x[i],y[i]);
	}

	/* find time of bolus peak */
	tscmin = 1.0e9;
	for (lmin = 1, l = 1; l <= imgdim[3]-SKIP; l++) {
		if (y[l] < tscmin) {
			tscmin = y[l];
			lmin = l;
		}
	}

	/* find 1st approx for base line value */
	bline = 0.0;
	bline2 = 0.0;
	nbline = 10;
	for (l = 1; l <= nbline; l++) {
		bline += y[l];
		bline2 += y[l]*y[l];
	}
	bline /= nbline;
	blstd = (bline2 - nbline*bline*bline)/(nbline - 1.0);
	blstd = sqrt(blstd);

	/* find approx time for bolus arrival */
	for (l = 5; l < lmin; l++) {
		l0 = l;
		if (y[l] < THRESH*bline) break;
	}

	/* 75 is a poor approximation, needs FIX */
	if (ndat_flag) ndata = ndat;
	else ndata = lmin + 75.0;

	if (ndata > imgdim[3] - SKIP) {
		ndata = imgdim[3] - SKIP;
		fprintf (stderr, "%s Warning: timeseries shortened\n", program);
	}

	/* find approx for steady state value */
	ssval = 0.0;
	for (l = ndata-10; l < ndata; l++) ssval += y[l];
	ssval /= 10.0;

	printf("min point %5.2f at time %d ndata is %d bolus arrival %d base line %f ss value %f\n",
		tscmin,lmin,ndata,l0,bline,ssval);

/*****************************/
/* III nonlinear fitting section */
/*****************************/
	/* set up model, nparam=10 for RECIRC; nparam=8 for no RECIRC */
	/* 1: s0, 2: cbf, 3: t0, 4: alpha, 5: beta, 6:delta, 7:gamma, 8:eps 9:t1 10:nu */
	if (recirc_flag) nparam = 10;
	else nparam = 8;

	/* init s0, initial baseline */
	amin[1] = 0.8*bline;  	amax[1] = 1.2*bline;  	aavg[1] = bline; 

	/* init cbf */
	amin[2] = 0.0;		amax[2] =   2.0;	aavg[2] =   1.0;	

	/* init t0 */
	amin[3] = 0.6*l0;	amax[3] =  l0;		aavg[3] =  0.8*l0;

	/* init alpha, bolus rise param */
	amin[4] = 0.0;		amax[4] =  10.0;	aavg[4] =   5.0;

	/* init beta, bolus decay param */
	amin[5] = 0.5;		amax[5] =   3.0;	aavg[5] =   1.0;

	/* init delta, inverse of the MTT */
	amin[6] = 0.05;		amax[6] =   1.0;	aavg[6] =   0.25;

	/* init gamma, timing of steady state arrival */
	amin[7] = 0.0;		amax[7] =   1.0;	aavg[7] =   0.1;

	/* init eps, weight of the main bolus */
	amin[8] = 0.8;		amax[8] =   1.0;	aavg[8] =   0.9;

	/* init t1 */
	amin[9] = lmin;		amax[9] =  lmin+30.0;	aavg[9] =  lmin+20.0;	

	/* init nu, weight of the recirculation bolus */
	amin[10] = 0.0; 	amax[10] =  0.3;	aavg[10] = 0.15;

	/* init lista */
	for (i = 1; i <= MAXP; i++) lista[i] = 0;
	for (i = 1; i <= nparam; i++) {
		lista[i] = 2;
		asig[i] = (amax[i] - amin[i])/4.0;
	}

	/* do global analysis */
	logp = pixperf(nparam,ndata,x,y,aopt,aostd,lista,aavg,asig,amin,amax,covar,alpha);

	/* NEED TO ADJUST TIME PARAMETER FOR TR_VOL! */
	/* Adjust the asig limits if wrong */
	nbad = 0;
	for (i = 1; i <= nparam; i++) {

		aavg[i] = aopt1[i] = aopt[i];

		printf("par %3d = %12.3f (%6.2f) %s\t min %f max %f ", i, aopt[i], aostd[i], parnames[i-1], amin[i], amax[i]);

		if (aopt[i] >= amin[i] && aopt[i] <= amax[i]) {
			printf("OK\n");
		}
		else if (aopt[i] < amin[i]) {
			printf("TOO LOW\n");
			if ((amin[i]-aopt[i])/asig[i] > 2.0) asig[i] = 0.5*(amin[i]-aopt[i]);
		}
		else {
			printf("TOO HIGH\n");
			if ((aopt[i]-amax[i])/asig[i] > 2.0) asig[i] = 0.5*(aopt[i]-amax[i]);
		}

	}
	printf ("logprob = %f\n", logp);

/****************************/
/* output global time curve */
/****************************/

	sprintf (outfile, "%s_global.dat", imgroot);
	fprintf (stdout, "Writing: %s\n", outfile);
	if (!(fp = fopen (outfile, "w"))) errw (program, outfile);
	write_command_line (program, fp, argc, argv);
	fprintf (fp, "#%9s%10s%10s\n", "frame", "tsc", "fit");
	for (i = 1; i <= ndata; i++) {
		h[i] = perf_make1 ((float) i-1, aopt);
		fprintf (fp,"%10d%10.2f%10.2f\n", i, tsc[i-1+SKIP], h[i]);
	}
	fclose (fp);

/***********************************/
/* debug section for single voxels */
/***********************************/
	if (single_vox_flag) {
		ysel = imgdim[1] - ysel; xsel--; zsel--;
		kndex = xsel + imgdim[0]*(ysel + imgdim[1]*zsel);
		printf ("debug voxel x %d y %d z %d index %d\n",xsel,ysel,zsel,kndex);
		for (i = 1; i <= ndata; i++) {
			printf("%d: %f\n", i, (imgt + (i - 1 + SKIP)*vdim)[kndex]);
		}
	}

/***********************************/
/* loop over voxels to be analyzed */
/***********************************/
	/* set regularization for single AIF */
	if (singaif_flag && saifcode == 1) {
		/* set single AIF, fix alpha, beta */
		lista[4] = 0; aavg[4] = aopt[4];
		lista[5] = 0; aavg[5] = aopt[5];
	}

	/* assorted inits */
	printf ("processing slice");
	for (k = 0; k < NVOLOUT; k++) sumpar[k] = sumpar2[k] = 0.0;
	npix = 0;
	lpmax = 0.0; lpmin = 1.0e9;

	/* select averaging type, default navg_slice=1 */
	if (navg_slice == 1)      { i2 = 0; j2 = 1; k2 = 1; }
	else if (navg_slice == 2) { i2 = 0; j2 = 2; k2 = 2; }
	else if (navg_slice == 3) { i2 = 1; j2 = 1; k2 = 1; }
	else if (navg_slice == 4) { i2 = 1; j2 = 2; k2 = 2; }
	else 			  { i2 = 0; j2 = 1; k2 = 1; }

	/* force 2D if only single slice */
	if (slc_flag) i2 = 0;

	for (k = 0; k < imgdim[2]; k++) {   /* slice counter */
		printf (" %d", k + 1); fflush(stdout);

		/* for single slice case */
		if (slc_flag && (slcsel != k)) continue;

		for (j = 0; j < sdim; j++) {  /* loop in each slice */
			jndex = k*sdim + j;
/*
printf("slice %d voxel %d\n",k,j);
*/
			/* old: store the base line image as last volume 
			imgp[(MAXP + 3)*vdim + jndex] = (imgt + (SKIP - 1)*vdim)[jndex];
			*/

			/* for single voxel debug case */
			/* SINGLE VOXEL WILL NOT WORK WITH LOCAL AVG! */
			if (single_vox_flag && (jndex != kndex)) continue;

			/* this mask accepts low bolus voxels also */
			if (mask[jndex]) {
				npix++;

				/* regular voxels */
				for (l = 1; l <= ndata; l++) {
					x[l] = (float) l-1;
					y[l] = (imgt + (l-1+SKIP)*vdim)[jndex] ;
				}

				/* local time averaging if enabled or if low bolus voxel */
				if (!cmask[jndex] || avg_flag) {
					navg = 0;
					for (l = 1; l <= ndata; l++) y[l] = 0.0;

					for (i1= -i2; i1<= i2; i1++) 
					for (j1= -j2; j1<= j2; j1++) 
					for (k1= -k2; k1<= k2; k1++) {

						jndex1 = jndex + i1*sdim + j1*imgdim[0] + k1;
						if (jndex1 >= 0 && jndex1 < vdim && cmask[jndex1]) {
							navg++;
							for (l = 1; l <= ndata; l++) {
								y[l] += (imgt + (l-1+SKIP)*vdim)[jndex1] ;
							}
						}
					}

					/* failure of local averaging, quit this voxel */
					if (navg == 0) {
						continue;
					}
					for (l = 1; l <= ndata; l++) y[l] = y[l]/navg;
				}
/* testing 
if (k == 0 && j == 3796) {
	debug_flag = 1;
	printf("nparam %d ndata %d\n",nparam, ndata);
	for (l = 1; l <= ndata; l++) printf("%d %f %f\n",l, x[l],y[l]);
	for (l = 1; l <= nparam; l++) {
		printf("aopt %f aostd %f lista %d aavg %f asig %f amin %f amax %f\n",
			aopt[l],aostd[l],lista[l],aavg[l],asig[l],amin[l],amax[l]);
	}
	fflush(stdout);
}
*/

				/* CALL NON-LINEAR ESTIMATTION */
				logp = pixperf (nparam, ndata, x, y, aopt, aostd,
					lista, aavg, asig, amin, amax, covar, alpha);

				/* store active params */
				for (l = 0; l < nparam; l++) {
					imgp[l*vdim + jndex] = aopt[l+1];
					sumpar[l] += aopt[l+1];
					sumpar2[l] += aopt[l+1]*aopt[l+1];
					aoptrr[l+1] = aopt[l+1];
				}

				/* EXTRA VOLUMES: store calculated params */
				/* first MTT = 1/delta */
				if (aopt[6] != 0.0) imgp[MAXP*vdim + jndex] = 1.0/aopt[6]; 
				else imgp[MAXP*vdim + jndex] = 0.0;
				sumpar[MAXP] += imgp[MAXP*vdim + jndex];
				sumpar2[MAXP] += sumpar[MAXP]*sumpar[MAXP];

				/* next CBV = MTT*CBF */
				imgp[(MAXP+1)*vdim + jndex] = imgp[MAXP*vdim + jndex]*aopt[2];
				sumpar[MAXP+1] += imgp[MAXP*vdim + jndex]*aopt[2];
				sumpar2[MAXP+1] += sumpar[MAXP+1]*sumpar[MAXP+1];

				/* store abs value of log prob */
				if (fabs(logp) > lpmax) lpmax = fabs(logp);
				if (fabs(logp) < lpmin) lpmin = fabs(logp);
				imgp[(MAXP+2)*vdim + jndex] = fabs(logp);
				sumpar[MAXP+2] += fabs(logp);
				sumpar2[MAXP+2] += sumpar[MAXP+2]*sumpar[MAXP+2];

				/**************************/
				/* CBV correction section */
				/**************************/
				if (ccbv_flag) {

				/* find 1st approx for base line avg and std */
				bline = 0.0;
				bline2 = 0.0;
				nbline = 10;
				for (l = 1; l <= nbline; l++) {
					bline += y[l];
					bline2 += y[l]*y[l];
				}
				bline /= nbline;
				blstd = (bline2 - nbline*bline*bline)/(nbline - 1.0);
				blstd = sqrt(blstd);

				/* find approx for steady state value */
				ssval = 0.0;
				for (l = ndata-10; l < ndata; l++) ssval += y[l];
				ssval /= 10.0;

				/* Analyze volume 14, difference in base line */
				imgp[(MAXP+3)*vdim + jndex] = bline - ssval;

				/* calc CBV from r2eff */
				/* ?CORRECT FOR VALUES ABOVE BASELINE? */
				sumr2 = 0.0;
				r2max = 0.0; 
				for (l = 1; l <= ndata; l++) {
					if (y[l] <= 0.0) y[l] = bline;
					r2eff[l] = log(bline/y[l]);
					sumr2 += r2eff[l]; 
					if (r2eff[l] > r2max) {
						r2max = r2eff[l];
					}
				}
				cbv = sumr2;

/* test 
printf("test cbv %f par 5<=6,7 %f %f %f\n",cbv,aoptrr[5],aoptrr[6],aoptrr[7]);
*/
				/* calculate relative recirculation Kassner JMRI 11:103,2000 */
				aoptrr[8] = 0.0;	/* keep only primary bolus */
				aoptrr[10] = 0.0;	/* make sure no recirc */
				sumr2 = 0.0;
				for (l = lmin; l <= ndata; l++) {
					sumr2 += (y[l] - log(aoptrr[1]/perf_make1(l, aoptrr)));
				}
				relR = sumr2/r2max;

				/* calculate the correction factors */
				sxz = sxy = syz = sx2 = sy2 = 0.0;
				sumr2 = 0.0;
				for (l = 1; l <= ndata; l++) {
					sx2 += r2avg[l-1+SKIP]*r2avg[l-1+SKIP];
					sy2 += r2sum[l-1+SKIP]*r2sum[l-1+SKIP];
					sxy += r2avg[l-1+SKIP]*r2sum[l-1+SKIP];
					sxz += r2avg[l-1+SKIP]*r2eff[l];
					syz += r2sum[l-1+SKIP]*r2eff[l];
					sumr2 += r2sum[l-1+SKIP];
				}

				det = sx2*sy2 - sxy*sxy;
				if (det == 0.0) K1 = K2 = 0.0;
				else {
					K1 = (sxz*sy2 - sxy*syz)/det;
					K2 = -(sx2*syz - sxz*sxy)/det;
				}
				ccbv = cbv + K2*sumr2;

				/* output analyze volumes 15,16,17,18 */
				imgp[(MAXP+4)*vdim + jndex] = cbv;
				imgp[(MAXP+5)*vdim + jndex] = ccbv;
				imgp[(MAXP+6)*vdim + jndex] = K1;
				imgp[(MAXP+7)*vdim + jndex] = K2;
				imgp[(MAXP+8)*vdim + jndex] = relR;

				} /* end ccbv_flag */				
			} /* end if on mask */

		} /* end loop on voxels in each slice */
	}  /* end slice loop */
	printf ("\n");


/***********************************/
/* REGULARIZATION SECTION */
/***********************************/
	if (regular_flag) {
	/* can also check regcode for different options */


/************************************/
/* loop over voxels to be analyzed  */
/* similar to above but with init   */
/* values determined from prior run */
/************************************/

	/* assorted inits */
	printf ("processing slice");
	for (k = 0; k < NVOLOUT; k++) sumpar[k] = sumpar2[k] = 0.0;
	npix = 0;
	lpmax = 0.0; lpmin = 1.0e9;

	for (k = 0; k < imgdim[2]; k++) {   /* slice counter */
		printf (" %d", k + 1); fflush(stdout);

		/* for single slice case */
		if (slc_flag && (slcsel != k)) continue;

		for (j = 0; j < sdim; j++) {  /* loop in each slice */
			jndex = k*sdim + j;

			/* this mask accepts low bolus voxels also */
			if (mask[jndex]) {
				npix++;

				/* regular voxels */
				for (l = 1; l <= ndata; l++) {
					x[l] = (float) l-1;
					y[l] = (imgt + (l-1+SKIP)*vdim)[jndex] ;
				}

				/* local time averaging if enabled or if low bolus voxel */
				if (!cmask[jndex] || avg_flag) {
					navg = 0;
					for (l = 1; l <= ndata; l++) y[l] = 0.0;

					for (i1= -i2; i1<= i2; i1++) 
					for (j1= -j2; j1<= j2; j1++) 
					for (k1= -k2; k1<= k2; k1++) {

						jndex1 = jndex + i1*sdim + j1*imgdim[0] + k1;
						if (jndex1 >= 0 && jndex1 < vdim && cmask[jndex1]) {
							navg++;
							for (l = 1; l <= ndata; l++) {
								y[l] += (imgt + (l-1+SKIP)*vdim)[jndex1] ;
							}
						}
					}

					/* failure of local averaging, quit this voxel */
					if (navg == 0)  continue;
					for (l = 1; l <= ndata; l++) y[l] = y[l]/navg;
				}

				/*********************************************************/
				/* Regularization section to better initalize parameters */
				/* set init values in aavg from the filtered first pass  */
				/* imgp has original values, imga the regularized vals   */
				/*********************************************************/

				for (i = 0; i < nparam; i++) {
					navg = 0;
					sumk = 0.0;
					for (i1= -i2; i1<= i2; i1++) 
					for (j1= -j2; j1<= j2; j1++) 
					for (k1= -k2; k1<= k2; k1++) {

						/* index of neighboring voxels */
						jndex1 = jndex + i1*sdim + j1*imgdim[0] + k1;
						if (jndex1 >= 0 && jndex1 < vdim && cmask[jndex1]) {
							sumk += imgp[i*vdim + jndex1]; 
							navg++;
						}

					} /* end kernel loop */

					if (navg > 0) {
						/* imgv[i*vdim + jndex] = sumk/navg; */
						aavg[i+1] = sumk/navg;
						if (aavg[i+1] <= amin[i+1] || aavg[i+1] >= amax[i+1]) {
							aavg[i+1] = aopt1[i+1];
						}
					}
					else {  /* backup of first optimal values */
						aavg[i+1] = aopt1[i+1];
					}

				} /* end of i loop Regularization section */

				/* attempt to fix parameters */
				if (singaif_flag && saifcode == 2) {
					/* sets alpha and beta */
					lista[4] = 0; 
					lista[5] = 0; 
				}

				/* CALL NON-LINEAR ESTIMATTION */
				logp = pixperf (nparam, ndata, x, y, aopt, aostd,
					lista, aavg, asig, amin, amax, covar, alpha);


				/* store active params */
				for (l = 0; l < nparam; l++) {
					imga[l*vdim + jndex] = aopt[l+1];
					sumpar[l] += aopt[l+1];
					sumpar2[l] += aopt[l+1]*aopt[l+1];
					aoptrr[l+1] = aopt[l+1];
				}

				/* EXTRA VOLUMES: store calculated params */
				/* first MTT = 1/delta */
				if (aopt[6] != 0.0) imga[MAXP*vdim + jndex] = 1.0/aopt[6]; 
				else imga[MAXP*vdim + jndex] = 0.0;
				sumpar[MAXP] += imga[MAXP*vdim + jndex];
				sumpar2[MAXP] += sumpar[MAXP]*sumpar[MAXP];

				/* next CBV = MTT*CBF */
				imga[(MAXP+1)*vdim + jndex] = imga[MAXP*vdim + jndex]*aopt[2];
				sumpar[MAXP+1] += imga[MAXP*vdim + jndex]*aopt[2];
				sumpar2[MAXP+1] += sumpar[MAXP+1]*sumpar[MAXP+1];

				/* store abs value of log prob */
				if (fabs(logp) > lpmax) lpmax = fabs(logp);
				if (fabs(logp) < lpmin) lpmin = fabs(logp);
				imga[(MAXP+2)*vdim + jndex] = fabs(logp);
				sumpar[MAXP+2] += fabs(logp);
				sumpar2[MAXP+2] += sumpar[MAXP+2]*sumpar[MAXP+2];

				/**********************************/
				/* CBV correction section         */
				/* NOT TESTED WITH REGULARIZATION */
				/* need to replace imgp with imga */
				/**********************************/
				if (ccbv_flag) {

				/* find 1st approx for base line avg and std */
				bline = 0.0;
				bline2 = 0.0;
				nbline = 10;
				for (l = 1; l <= nbline; l++) {
					bline += y[l];
					bline2 += y[l]*y[l];
				}
				bline /= nbline;
				blstd = (bline2 - nbline*bline*bline)/(nbline - 1.0);
				blstd = sqrt(blstd);

				/* find approx for steady state value */
				ssval = 0.0;
				for (l = ndata-10; l < ndata; l++) ssval += y[l];
				ssval /= 10.0;

				/* Analyze volume 14, difference in base line */
				imgp[(MAXP+3)*vdim + jndex] = bline - ssval;

				/* calc CBV from r2eff */
				/* ?CORRECT FOR VALUES ABOVE BASELINE? */
				sumr2 = 0.0;
				r2max = 0.0; 
				for (l = 1; l <= ndata; l++) {
					if (y[l] <= 0.0) y[l] = bline;
					r2eff[l] = log(bline/y[l]);
					sumr2 += r2eff[l]; 
					if (r2eff[l] > r2max) {
						r2max = r2eff[l];
					}
				}
				cbv = sumr2;

				/* calculate relative recirculation Kassner JMRI 11:103,2000 */
				aoptrr[8] = 0.0;	/* keep only primary bolus */
				aoptrr[10] = 0.0;	/* make sure no recirc */
				sumr2 = 0.0;
				for (l = lmin; l <= ndata; l++) {
					sumr2 += (y[l] - log(aoptrr[1]/perf_make1(l, aoptrr)));
				}
				relR = sumr2/r2max;

				/* calculate the correction factors */
				sxz = sxy = syz = sx2 = sy2 = 0.0;
				sumr2 = 0.0;
				for (l = 1; l <= ndata; l++) {
					sx2 += r2avg[l-1+SKIP]*r2avg[l-1+SKIP];
					sy2 += r2sum[l-1+SKIP]*r2sum[l-1+SKIP];
					sxy += r2avg[l-1+SKIP]*r2sum[l-1+SKIP];
					sxz += r2avg[l-1+SKIP]*r2eff[l];
					syz += r2sum[l-1+SKIP]*r2eff[l];
					sumr2 += r2sum[l-1+SKIP];
				}

				det = sx2*sy2 - sxy*sxy;
				if (det == 0.0) K1 = K2 = 0.0;
				else {
					K1 = (sxz*sy2 - sxy*syz)/det;
					K2 = -(sx2*syz - sxz*sxy)/det;
				}
				ccbv = cbv + K2*sumr2;

				/* output analyze volumes 15,16,17,18 */
				imgp[(MAXP+4)*vdim + jndex] = cbv;
				imgp[(MAXP+5)*vdim + jndex] = ccbv;
				imgp[(MAXP+6)*vdim + jndex] = K1;
				imgp[(MAXP+7)*vdim + jndex] = K2;
				imgp[(MAXP+8)*vdim + jndex] = relR;

				} /* end ccbv_flag */				
			} /* end if on mask */

		} /* end loop on voxels in each slice */
	}  /* end slice loop */
	printf ("\n");


	} /* end of regularization section */

/***********************************/
/* SUMMARY PRINTOUT OF PARAMETER VALUES */
/***********************************/
	/* get avgs and stds of parameters including logp */
	for (l = 0; l <= MAXP+2; l++) {

		sumpar[l] /= npix;
		sumpar2[l] = (sumpar2[l] - npix*sumpar[l]*sumpar[l])/(npix - 1.0);
	        sumpar2[l] = sqrt(sumpar2[l]);
		printf ("par %d avg %f std %f \n", l, sumpar[l], sumpar2[l]);

	}

	/* for removing bad estimates only */
	/* NEEDS CHECKING WITH NEW REGULARIZATIONS */
	if (bad_flag) {
	npix = npix1 = 0;
	for (l = 0; l <= NHIST; l++) lphist[l] = 0;
	for (k = 0; k < imgdim[2]; k++) {   /* slice counter */
		if (slc_flag && (slcsel != k)) continue; /* single slice case */
		for (j = 0; j < sdim; j++) {  /* loop in each slice */
			jndex = k*sdim + j;
			if (cmask[jndex]) {
				npix++;
				logp = imgp[(MAXP+2)*vdim + jndex];
				/* histogram */
				lphist[(int)(NHIST*(logp - lpmin)/(lpmax - lpmin))]++;

				/* check if any of the paramters are outliers */
				bflag = 0;
				for (i=0; i<=MAXP+2; i++) {
					/* JSS check this sumpar2 v sumpar??? */
					if (imgp[i*vdim + jndex]  > sumpar[i] + bad_nstd*sumpar[i])
						bflag = 1;
				}

				/* mask out bad estimates */
				/* maybe severe criteria? */
				/* does not zero out S0 and logprob */
				if (bflag) {
					npix1++;
					for (i=1; i<=MAXP+1; i++) imgp[i*vdim + jndex] = 0.0; 
				}
			}
		}
	}

	printf("npix %d number bad estimates %d (%f) \n",npix,npix1, (float)npix1/npix);
	/* TOO BE USED FOR MEDIAN EXCLUSION
	for (l = 0; l <= NHIST; l++) {
		printf("hist %d: %d\n",l,lphist[l]);
	}
	*/

	} /* end if bad_flag */

	/* median filtering section */
	/* NEEDS CHECKING */
	if (median_flag) {

		if (medsize == 125) {
			i2=2; j2=2; k2=2; }
		else if (medsize == 27) {
			i2=1; j2=1; k2=1; }
		else if (medsize == 121) {
			i2=0; j2=5; k2=5; }
		else if (medsize == 81) {
			i2=0; j2=4; k2=4; }
		else if (medsize == 49) {
			i2=0; j2=3; k2=3; }
		else if (medsize == 25) {
			i2=0; j2=2; k2=2; }
		else {
			i2=0; j2=1; k2=1; }

	npix = npix1 = 0;
	for (k = 0; k < vdim; k++) imgv[k] = 0.0;
	for (k = 0; k < imgdim[2]; k++) {   /* slice counter */
		if (slc_flag && (slcsel != k)) continue; /* single slice case */
		for (j = 0; j < sdim; j++) {  /* loop in each slice */
			jndex = k*sdim + j;
			if (cmask[jndex]) {
				npix++;
				logp = imgp[(MAXP+2)*vdim + jndex];

				/* store elements to sort in sort array */
				/* NOTE: only for CBF */
				/* for (l = 1; l <= ndata; l++) y[l] = 0.0; */

				navg = 0;
				for (i1= -i2; i1<= i2; i1++) 
				for (j1= -j2; j1<= j2; j1++) 
				for (k1= -k2; k1<= k2; k1++) {

					jndex1 = jndex + i1*sdim + j1*imgdim[0] + k1;
					if (jndex1 >= 0 && jndex1 < vdim && cmask[jndex1]) {
						/* TEST ON CBF ONLY INDEX 1*vdim */
						sort[navg] = imgp[1*vdim + jndex1]; 
						navg++;
					}
				}

				if (navg == 0) printf("Error: navg = 0\n");

				/* bubble sort procedure, slow! */
				for (i1 = 0; i1 < navg-1; i1++) {
					for (j1 = navg-1; j1 > i1; j1--) {
						if (sort[j1-1] < sort[j1]) {
							temp = sort[j1-1];
							sort[j1-1] = sort[j1];
							sort[j1] = temp;
						}
					}
				}

				medsize = medsize/2;
				imgv[jndex] = sort[medsize];
			}
		}
	}
	for (k = 0; k < vdim; k++) imgp[1*vdim + k] = imgv[k];

	} /* end of median filtering section */

/*********************/
/* write 4dfp output */
/*********************/
	sprintf (outroot, "%s_params", imgroot);
	sprintf (outfile, "%s.4dfp.img", outroot);
	printf ("Writing: %s\n", outfile);

	if (!regular_flag) { /* for regular output */
		if (!(fp = fopen (outfile, "wb")) || ewrite (imgp, vdim*NVOLOUT, control, fp)
		|| fclose (fp)) errw (program, outfile);
	}
	else { /* for regularized case ouput imga instead */
		if (!(fp = fopen (outfile, "wb")) || ewrite (imga, vdim*NVOLOUT, control, fp)
		|| fclose (fp)) errw (program, outfile);
	}

/*******/
/* ifh */
/*******/
	ifh.matrix_size[3] = NVOLOUT;
	writeifhmce (program, outfile, ifh.matrix_size, ifh.scaling_factor, ifh.orientation,
		ifh.mmppix, ifh.center, control);

/***************/
/* analyze hdr */
/***************/
	sprintf (command, "ifh2hdr %s", outroot);
	printf ("%s\n", command); status |= system (command);

/*******/
/* rec */
/*******/
	startrece (outfile, argc, argv, rcsid, control);
	catrec (imgfile);
	endrec ();

/*********************/
/* deallocate memory */
/*********************/
	free(imgt);
	free(imgp);
	free(imgv);
	free(imga);
	free(mask);
	free(cmask);
	free_matrix(alpha,1,MAXP,1,MAXP);
	free_matrix(covar,1,MAXP,1,MAXP);
	free_vector(y,1,imgdim[3]);
	free_vector(x,1,imgdim[3]);
	free_ivector(lista,1,MAXP);

	return status;
}

/***********************************************/
/* pixperf - calculate perfusion for one pixel */
/***********************************************/
float pixperf(int nparam, int ndata, float *x, float *y, float *aopt, float *aostd,
	int *lista,float *aavg,float *asig,float *amin,float *amax,float **covar,float **alpha)
{
	static long seed = (-47); 
	int i,j,k,l,itst,iopt, goodpar,w1;
	float chisqopt, alamda, chisq, ochisq, a[MAXP+1];

	chisqopt = -9.0e9;
	for (l=0; l<NPOP; l++) {

		/* loop to create random set of new params */
		w1 = 0; 
		do {
			w1++; goodpar = 1;
			for(i=1;i<=nparam;i++) { 
				if (lista[i]==0) a[i] = aavg[i];
				if (lista[i]!=0) do {
					a[i] = aavg[i] + asig[i]*gasdev(&seed);
				} while (a[i] >= amax[i] || a[i] <=amin[i]);
			}
			if (nparam == 8) {
				if (a[4]+0.999<=0.0 || a[4]>20.0 || a[5]<=a[6] || a[5]<=a[7] || 
					a[6]==a[7] || a[6]<=0.0) goodpar=0;
			}
			else {
				if (a[4]+0.999<=0.0 || a[4]>20.0 || a[5]<=a[6] || a[5]<=a[7] || 
					a[6]==a[7] || a[6]<=0.0 || a[9]<a[3] || a[10]>a[8] ) goodpar=0;
			}
			if (w1 > 100) printf("Warning(pixperf): too many iteration to make valid param %d\n",w1);
		} while (goodpar == 0);

		alamda = -1.0;
		mrqprior1(x,y,ndata,a,lista,aavg,nparam,covar,alpha,&chisq,&alamda);

		j=1; itst=0;
		while(itst < NITER) {
		    if (PRT_FLG) {
			printf("\n%s %2d %17s %13.4e %10s %9.2e\n","Iteration #",j,
				"chi-squared:",chisq,"alamda:",alamda);
			printf("%10s %10s %10s %10s %10s %10s \n", "a[1]","a[2]","a[3]","a[4]","a[5]","a[6]");
			for (i=1;i<=nparam;i++) printf("%11.3e",a[i]);
			printf("\n");
		    }
		    j++;
		    ochisq=chisq;
		    mrqprior1(x,y,ndata,a,lista,aavg,nparam,covar,alpha,&chisq,&alamda);
		    if (chisq < ochisq) itst=0;
		    else if (fabs(ochisq-chisq) < DELCHI) itst++;
		}

		alamda=0.0;
		mrqprior1(x,y,ndata,a,lista,aavg,nparam,covar,alpha,&chisq,&alamda);

		if (PRT_FLG) {
			printf("\nUncertainties:\n");
			for(i=1;i<=nparam;i++) printf("%11.4f",sqrt(covar[i][i]));
			printf("\n");
		}

		/* store for later, best fit so far */
		if (chisq > chisqopt) { 
			/* printf("#%4d lprob %11.3f itr %3d ",l,chisq,j); */
			chisqopt = chisq; iopt = l; 
			for (i=1;i<=nparam;i++) {
				aopt[i] = a[i];
				if (covar[i][i] > 0.0) aostd[i] = sqrt(covar[i][i]);
				else aostd[i] = 0.0;
				/* printf("%10.2e\n ",a[i]); */
			}
		}
	} /* end population loop */

	return(chisqopt);
}


/*
*************************************************
** mrqprior1 - improved Levenberg/Marquardt from mrqmin in NR
** 	added relaxation parameter for slower convergence 
**		changes involve the relax parameter
**	added ability to use priors for the parameter estimation
*************************************************
*/
void mrqprior1(float x[], float y[],int ndata,float a[],int ia[],
	float aavg[],int ma,float **covar,float **alpha,float *logprob, float *alamda)
{
	int j,k,l,m;
	static int mfit;
	static float *da,*atry,**oneda,*beta,ologprob,relax;

	/* initialization */
	if (*alamda < 0.0) {
		atry = vector(1,ma);
		beta = vector(1,ma);
		da = vector(1,ma);
		for (mfit=0, j=1; j<=ma; j++) if (ia[j]) mfit++;
		oneda = matrix(1,mfit,1,1);
		*alamda = 0.001;
/*
if (debug_flag) {printf("pre mrqpcof %f %f %d %f %d %f %d\n",x[1],y[1],ndata,a[1],ia[1],aavg[1],ma);fflush(stdout);}
*/
		mrqpcof(x,y,ndata,a,ia,aavg,ma,alpha,beta,logprob);
/*
if (debug_flag) {printf("post mrqpcof %f %f \n",alpha[1][1], beta[1]); fflush(stdout);}
*/

		ologprob = (*logprob);
		for (j=1; j<=ma; j++) atry[j]=a[j];
		relax = 1.0e-1;  /* original value was 1e-6 */
	}

	/* Alter fitting matrix by augmenting diagonal elements */
	for (j=0,l=1; l<=ma; l++) {
	    if (ia[l]) {
		for (j++,k=0,m=1; m<=ma; m++) {
			if (ia[m]) {
				k++; covar[j][k] = alpha[j][k];
			}
		}
		covar[j][j] = alpha[j][j]*(1.0+(*alamda));
		oneda[j][1] = beta[j];
	    }
	}

	/* Solve the matrix, return if error  */
	if (gaussj_chk(covar,mfit,oneda,1)) {
		*logprob = -9.0e9;
		return;
	}

	for (j=1; j<=mfit; j++) da[j] = oneda[j][1];

	/* finished, evaluate the covariance matrix */
	if (*alamda == 0.0) {
		covsrt(covar, ma,ia,mfit);
		free_matrix(oneda,1,mfit,1,1);
		free_vector(da,1,ma);
		free_vector(beta,1,ma);
		free_vector(atry,1,ma);
		return;
	}

	/* Did the trial succed? */
	for (j=0, l=1; l<=ma; l++) {
		if (ia[l]) {
			atry[l] = a[l] + da[++j]*relax;
		}
	}
	mrqpcof(x,y,ndata,atry,ia,aavg,ma,covar,da,logprob);

	/* Accept new solution */
	if (*logprob > ologprob) {
		relax = sqrt(relax);
		*alamda *= 0.1;
		ologprob = (*logprob);
		for (j=0, l=1; l<=ma; l++) {
		    if (ia[l]) {
			for (j++,k=0,m=1; m<=ma; m++) {
				if (ia[m]) {
					k++; alpha[j][k] = covar[j][k];
				}
			}
			beta[j] = da[j];
			a[l] = atry[l];
		    }
		}
	}
	/* failure, increase lambda and return */
	else {
		*alamda *= 10.0;
		*logprob = ologprob;
	}
}

/* 
** mrqpcof - designed to go with mrqprior
**	does not use sig[] but estimates it from residuals
**	ia[j]==2 add prior based on the following possible functions:
**		log(w/(w0^2 + w^2)) min is 0, peak at w0
**		1.0/(1.0 + exp(-h*(w - w_min))) min is w_min, no peak
**	ia[j]==1 do not add prior
**	ia[j]==0 do not search on this parameter
**	alpha and beta are NOT angles (see NR derivation)
**	factor of -1 is included in the beta calculation
**	There is a factor of 2 cancellation in the alpha, beta calcs
*/
void mrqpcof(float x[],float y[],int ndata,float a[],int ia[],
	float aavg[],int ma, float **alpha, float beta[],float *logprob)
{
	int i,j,k,l,m,mfit=0;
	float ymod,sig2i,sig2,dy,dyda[MAXP+1];
	double den,anrm,anl,h=2.0;  /* h is transition const for prior function 2 */

	/* dyda = vector(1,ma); */
	/* initialization */
	for (j=1; j<=ma; j++) if (ia[j]) mfit++;
	for (j=1; j<=mfit; j++) {
		for (k=1; k<=j; k++) alpha[j][k] = 0.0;
		beta[j] = 0.0;
	}

	/* loop over data, calculate the likelihood function */
	sig2 = 0.0;

	if (ma == 8) {  /* no recirc */
	for (i=1; i<=ndata; i++) {
/*
if (debug_flag) { printf("mrqpcof1 %f %f %f %f %f %f %f %f %f\n",x[i],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8]); fflush(stdout);}
*/
		perffunc0(x[i],a,&ymod,dyda,ma);
		dy = y[i] - ymod;
		sig2 += dy*dy;

		for (j=0, l=1; l<=ma; l++) {
		    if (ia[l]) {
			for (j++, k=0,m=1;m<=l;m++)
				if (ia[m]) alpha[j][++k] += dyda[l]*dyda[m];
			beta[j] += dy*dyda[l];
/*
if (debug_flag) { printf("mrqpcof2 %d %d %d %d a %f b %f dyda %f %f\n",j,l,k,m,alpha[j][1],beta[j],dyda[l],dyda[m]); fflush(stdout);}
*/
		    }
		}
	}
	} /* end if */
	else if (ma == 10) { /* with recirc */
	for (i=1; i<=ndata; i++) {
		perffunc1(x[i],a,&ymod,dyda,ma);
		dy = y[i] - ymod;
		sig2 += dy*dy;

		for (j=0, l=1; l<=ma; l++) {
		    if (ia[l]) {
			for (j++, k=0,m=1;m<=l;m++)
				if (ia[m]) alpha[j][++k] += dyda[l]*dyda[m];
			beta[j] += dy*dyda[l];
		    }
		}
	}
	} /* end else */
	else {
		printf("Error(mrqpcof): Wrong number of parameters \n");
	}

	(*logprob) = -((float)ndata/2.0)*log(sig2/2.0);

	/* normalize with 1/sig2 and add prior */
	sig2i = (float)ndata/sig2;
	for (j=0, l=1; l<=ma; l++) {
	    if (ia[l]) {
		j++;
		den = aavg[j]*aavg[j] + a[j]*a[j];
		anrm = a[j]/aavg[j];
		anl = a[j]*(PI/4.0)/aavg[j];
		for (k=0,m=1;m<=l;m++) {
			if (ia[m]) {
				++k;
				alpha[j][k] *= sig2i;
				/* function 1 2nd derivative  */
				if (j==k && ia[j]==2) alpha[j][k] += (4.0*a[j]*a[j]/(den*den) - 2.0/den - 1.0/(a[j]*a[j]));
				
				/* function 2 2nd derivative 
				if (j==k && ia[j]==2) alpha[j][k] += -h*exp(-h*anrm)/((1.0+exp(-h*anrm))*(1.0+exp(-h*anrm)));
				*/
				/* function 3 2nd derivative 
				if (j==k && ia[j]==2) alpha[j][k] += -4.0*h*h*cosh(2.0*h*anrm)/(sinh(2.0*h*anrm)*sinh(2.0*h*anrm));
				*/
				/* function 4 2nd derivative 
				if (j==k && ia[j]==2) alpha[j][k] += -h*h/(sin(h*anl)*sin(h*anl));
				*/
			}
		}
		beta[j] *= sig2i;

		/* function 1 1st derivative */
		if (ia[j]==2) beta[j] += -(1.0/a[j] - 2.0*a[j]/den);
		
		/* function 2 1st derivative 
		if (ia[j]==2) beta[j] += -(h*exp(-h*anrm)/(1.0 + exp(-h*anrm)));
		*/
		/* function 3 1st derivative 
		if (ia[j]==2) beta[j] += -(2.0*h/sinh(2.0*h*anrm));
		*/
		/* function 4 1st derivative 
		if (ia[j]==2) beta[j] += -(h/tan(h*anl));
		*/

		/* function 1  */
		if (ia[j]==2) (*logprob) += log(a[j]/den);

		/* function 2 
		if (ia[j]==2) (*logprob) += log(1.0/(1.0 + exp(-h*anrm)));
		*/
		/* function 3 using hyperbolic tangent 
		if (ia[j]==2) (*logprob) += log(tanh(h*anrm));
		*/
		/* function 4 using sin 
		if (ia[j]==2) (*logprob) += log(sin(h*anl));
		*/
	    }
	}

	/* copy to symmetric matrix */
	for (j=2;j<=mfit; j++) 
		for (k=1; k<j; k++) alpha[k][j] = alpha[j][k];
}




/* invert a matrix using gauss jordan method NR p. 36 */
/* return flag=1 if singular matrix, otherwise return 0 */
int gaussj_chk(float **a, int n, float **b, int m)
{
	int *indxc,*indxr,*ipiv;
	int i, icol,irow,j,k,l,ll,status;
	float big,dum,pivinv,temp;
	float swap;
	
	status = 0;
	indxc=ivector(1,n);
	indxr=ivector(1,n);
	ipiv=ivector(1,n);

	for (j=1;j<=n;j++) ipiv[j]=0;
	for(i=1;i<=n;i++) {
		big=0.0;
		for(j=1;j<=n;j++) {
			if(ipiv[j] !=1) {
				for(k=1;k<=n;k++) {
					if(ipiv[k] == 0) {
						if(fabs(a[j][k]) >= big) {
							big=fabs(a[j][k]);
							irow=j;
							icol=k;
						}
					} 
					else if (ipiv[k] > 1) {status = 1; goto FREE;}
				}
			}
		}
		++(ipiv[icol]);
		if(irow != icol) {
			for(l=1;l<=n;l++) {swap=a[irow][l];a[irow][l]=a[icol][l];a[icol][l]=swap;}
			for(l=1;l<=m;l++) {swap=b[irow][l];b[irow][l]=b[icol][l];b[icol][l]=swap;}
		}
		indxr[i]=irow;
		indxc[i]=icol;
		if (a[icol][icol] == 0.0) {status = 1; goto FREE; }
		pivinv=1.0/a[icol][icol];
		a[icol][icol]=1.0;
		for (l=1;l<=n;l++) a[icol][l] *=pivinv;
		for (l=1;l<=m;l++) b[icol][l] *=pivinv;
		for(ll=1;ll<=n;ll++) {
			if(ll != icol) {
				dum=a[ll][icol];
				a[ll][icol]=0.0;
				for(l=1;l<=n;l++) a[ll][l] -= a[icol][l]*dum;
				for(l=1;l<=m;l++) b[ll][l] -= b[icol][l]*dum;
			}
		}
	}
	for (l=n;l>=1;l--) {
		if(indxr[l] != indxc[l]) {
			for(k=1;k<=n;k++) {
				swap=a[k][indxr[l]];a[k][indxr[l]]=a[k][indxc[l]];a[k][indxc[l]]=swap;
			}
		}
	}
FREE:	

	free_ivector(ipiv,1,n);
	free_ivector(indxr,1,n);
	free_ivector(indxc,1,n);
	return(status);
}
