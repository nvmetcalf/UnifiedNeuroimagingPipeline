/*$Header: /data/petsun4/data1/src_solaris/librms/RCS/dsvdcmp0.h,v 1.2 2012/11/26 07:16:23 avi Exp $*/
/*$Log: dsvdcmp0.h,v $
 * Revision 1.2  2012/11/26  07:16:23  avi
 * dsvdsqrtinv()
 *
 * Revision 1.1  2012/09/05  22:07:33  avi
 * Initial revision
 **/

extern void dsvdcmp0 (double **a, int m, int n, double *w, double **v);			/* A = Vt*W*U, where U is in returned A */
extern int ndsvdcmp0 (double **a, int m, int n, double *w, double **v, double tol);	/* dimensionality reduction */
extern void dsvdinv  (double **A, int n, double *det);					/* returns Ainv */
extern void dsvdsqrtinv  (double **A, int n, double *det);				/* returns sqrt(Ainv) */
