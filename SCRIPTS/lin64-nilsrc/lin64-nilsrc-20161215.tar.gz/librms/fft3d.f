c$Header: /data/petsun4/data1/src_solaris/librms/RCS/fft3d.f,v 1.2 2013/09/16 03:04:41 avi Exp $
c$Log: fft3d.f,v $
c Revision 1.2  2013/09/16  03:04:41  avi
c correct inverse transform operation
c
c Revision 1.1  2013/09/15  02:52:52  avi
c Initial revision
c
      subroutine fft3d(imgt,nx,ny,nz,a,b,idir)
      real*4 imgt(nx,ny,nz),a(nx*ny*nz),b(nx*ny*nz)

      if (idir**2.ne.1) then
        write(*,"('fft3 error: idir must be +1 or -1')")
        call exit (-1)
      endif

      n=nx*ny*nz
c     write(*,"('nx,ny,nz,n',4i5)")nx,ny,nz,n
c     write(*,"('idir=',i2)")idir
      if (idir.eq.-1) then
        i=1
        do 21 iz=1,nz
        do 21 iy=1,ny
        do 21 ix=1,nx
        a(i)=imgt(ix,iy,iz)
        b(i)=0.
   21   i=i+1
        call FFT(a,b,ny*nz,nx,1,    -1)
        call FFT(a,b,nz,   ny,nx,   -1)
        call FFT(a,b,1,    nz,nx*ny,-1)
	return
      else
        call FFT(a,b,1,    nz,nx*ny,+1)
        call FFT(a,b,nz,   ny,nx,   +1)
        call FFT(a,b,ny*nz,nx,1,    +1)
        i=1
        do 31 iz=1,nz
        do 31 iy=1,ny
        do 31 ix=1,nx
        imgt(ix,iy,iz)=a(i)
   31   i=i+1
	return
      endif
      end
