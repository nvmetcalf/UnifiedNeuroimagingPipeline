c$Header: /data/petsun4/data1/src_solaris/librms/RCS/npad.f,v 1.2 2016/03/16 01:50:14 avi Exp $
c$Log: npad.f,v $
c Revision 1.2  2016/03/16  01:50:14  avi
c work with much larger numbers
c
c Revision 1.1  2016/03/15  23:25:18  avi
c Initial revision
c
      function npad(n,margin)
      if(n.le.1)then
        npad=n
        return
      endif
      m=1
      do 2 j=1,24
      do 4 i=2,9
      npad=m*i
    4 if(i.ne.7.and.npad.ge.n+2*margin)return
    2 m=m*2
      npad=n
      return
      end
