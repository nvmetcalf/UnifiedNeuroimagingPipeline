#include "common-format.h"
#include "4dfp-format.h"
#include "transform.h"
#include "math.h"
#include "stdio.h"

typedef struct
{
	char pathdr[512];
	float rhdr[128];
	short ihdr[256];
	float thdr[128];
#ifndef NOT_GCC
} __attribute__ ((packed)) PAL_header;
#else
} PAL_header;
#endif

void byteswap(char* pointer, unsigned int width, unsigned int count)
{
	int i, j, end = count * width, stop = width >> 1;//cheap divide by 2
	char temp;
	int pos1, pos2;
	for (i = 0; i < end; i += width)
	{
		for (j = 0; j < stop; ++j)
		{
			pos1 = i + j;
			pos2 = i + width - j - 1;
			temp = pointer[pos1];
			pointer[pos1] = pointer[pos2];
			pointer[pos2] = temp;
		}
	}
}

int main(int argc, char** argv)
{
	if (argc < 5)
	{
		printf("usage: %s <4dfp root> <frame duration/scale list> <PAL output root> <z slice compression>\n", argv[0]);
		return 0;
	}//if a working dicom->nifti converter is located, this can be changed to parse_nifti, just remove the NULL arg and fix the include
	//or, you can use parse_common_format, which is biased towards reading as nifti
	common_format* input = parse_4dfp(argv[1], NULL);//in reality, this should already be transverse
	if (!input)
	{
		printf("error reading input: %s\n", argv[1]);
		return -1;
	}
	to_lpi(input);//orient whatever it currently is to LPI, as a reference point - this only modifies the header info order and orientation fields
	//reorientation flips/axis exchanges go here
	char revorder[4];
	int i, k, t, slicecount, compress = atoi(argv[4]);
	for (i = 0; i < 4; ++i)
	{//generate axis reverse lookup to find anatomical axes
		revorder[input->order[i]] = i;
	}//anatomical x and y are flipped (RAI), by examining output of old conversion program
	input->orientation ^= (1 << revorder[0]);//flip x
	input->orientation ^= (1 << revorder[1]);//flip y
	auto_orient_header(input);//move the sform values for spacing to their expected locations
	int xdim = input->length[input->order[0]], ydim = input->length[input->order[1]], zdim = input->length[input->order[2]], tdim = input->length[input->order[3]];
	long imagesize = (long)(input->length[0]) * input->length[1] * input->length[2] * input->length[3];
	if (compress < 1)
	{
		printf("slice compression not a positive integer, aborting\n");
		return -1;
	}
	PAL_header myhead;//generate the header
	for (i = 0; i < 2048; ++i)
	{//zero it
		((char*)&myhead)[i] = 0;
	}
	FILE* textfile = fopen(argv[2], "r");
	if (!textfile)
	{
		printf("error opening file '%s'\n", argv[2]);
		return -1;
	}
	float totaldur = 0.0f;
	/*float* scales = (float*)malloc(input->length[3] * sizeof(float));
	if (!scales)
	{
		printf("could not allocate required memory\n");
		return -1;
	}//*/
	//printf("duration\tscale\n");
	for (i = 0; i < input->length[3]; ++i)
	{
		//if (fscanf(textfile, "%f %f", myhead.thdr + i, scales + i) != 2)
		if (fscanf(textfile, "%f", myhead.thdr + i) != 1)
		{
			printf("error reading text file, number of timesteps does not match\n");
			return -1;
		}
		myhead.thdr[i] /= 1000.0f;
		totaldur += myhead.thdr[i];
		//printf("%f\t%f\n", myhead.thdr[i], scales[i]);
	}
	fclose(textfile);
	myhead.pathdr[0] = '\0';//use null terminator to make sure it doesn't read as binary garbage
	myhead.rhdr[0] = fabs(input->sform[0][0]);//spacing, no center
	myhead.rhdr[1] = fabs(input->sform[1][1]);//auto_orient_header already moved these into LPI positions with RAI values
	myhead.rhdr[2] = fabs(input->sform[2][2] * compress);//so dont use input->order to index
	myhead.ihdr[0] = 0;//scanner type: unknown
	myhead.ihdr[30] = (int)totaldur;//sum of frame durations?
	myhead.ihdr[33] = 32767;//we rescale to use the full positive range of short
	myhead.ihdr[35] = (short)(zdim / compress);//integer divide: we will discard extra slices
	myhead.ihdr[125] = (short)xdim;
	myhead.ihdr[126] = (short)ydim;
	char islittle = !local_endian();//need to write bigendian, so check local endian
	if (islittle)
	{
		byteswap((char*)myhead.rhdr, 4, 128);//float
		byteswap((char*)myhead.ihdr, 2, 256);//short
		byteswap((char*)myhead.thdr, 4, 128);//float
	}
	float* imagedata = (float*)malloc(imagesize * sizeof(float));
	if (!imagedata)
	{
		printf("could not allocate required memory\n");
		return -1;
	}
	auto_orient((void*)imagedata, input, 0);//flip the voxels into the correct configuration, at local endian-ness
	int outsize = (zdim / compress) * xdim * ydim * tdim;
	int framesize = xdim * ydim * zdim;
	int compressorsize = xdim * ydim;//also, slice size
	int averagesize = (zdim / compress) * xdim * ydim;
	float* compressor = (float*)malloc(sizeof(float) * compressorsize);
	float* average = (float*)malloc(sizeof(float) * averagesize);
	float* fullout = (float*)malloc(outsize * sizeof(float));
	if (!compressor || !average || !fullout)
	{
		printf("could not allocate required memory\n");
		return -1;
	}
	float fullmax = 0.0f, avemax = 0.0f;
	int outslice, base, base2;
	for (t = 0; t < tdim; ++t)
	{
		slicecount = 0;
		outslice = 0;
		for (k = 0; k < zdim; ++k)
		{
			base = compressorsize * k + t * framesize;//remove integer multiply from small loops
			if (slicecount == 0)
			{
				for (i = 0; i < compressorsize; ++i)
				{//reinitialize the slice compressor
					//compressor[i] = imagedata[base + i] * scales[t];
					compressor[i] = imagedata[base + i];
				}
			} else {
				for (i = 0; i < compressorsize; ++i)
				{
					//compressor[i] += imagedata[base + i] * scales[t];
					compressor[i] += imagedata[base + i];
				}
			}
			if (++slicecount >= compress)
			{
				slicecount = 0;
				base = outslice * compressorsize;
				base2 = base + t * averagesize;
				for (i = 0; i < compressorsize; ++i)
				{
					average[base + i] += compressor[i];//we renormalize later, so don't divide now
					if (fullmax < (fullout[base2 + i] = compressor[i]))
					{
						fullmax = fullout[base2 + i];
					}
				}
				++outslice;
			}
		}
	}
	free(imagedata);
	free(compressor);
	//free(scales);
	short* shortaverage = (short*)malloc(sizeof(short) * averagesize);
	short* shortfullout = (short*)malloc(sizeof(short) * outsize);
	if (!shortaverage)
	{
		printf("could not allocate required memory\n");
	}
	for (i = 0; i < averagesize; ++i)
	{
		if (avemax < average[i])
		{
			avemax = average[i];//WARNING: it is actually the sum across frames, not average
		}
	}
	for (i = 0; i < averagesize; ++i)
	{
		shortaverage[i] = (short)floor((average[i] / avemax) * 32767.49f + 0.5f);//but we normalize, so it doesn't matter
		if (shortaverage[i] < 0 && average[i] > 0.0f)
		{
			printf("rescale problem: %i from floor(%f / %f * 32767.49 + 0.5)\n", shortaverage[i], average[i], avemax);
		}
	}//NOTE: (short)(32768.0f) wraps to -32768!!!
	for (i = 0; i < outsize; ++i)
	{
		shortfullout[i] = (short)floor((fullout[i] / fullmax) * 32767.49f + 0.5f);
		if (shortfullout[i] < 0 && fullout[i] > 0.0f)
		{
			printf("rescale problem: %i from floor(%f / %f * 32767.49 + 0.5)\n", shortfullout[i], fullout[i], fullmax);
		}
	}
	if (islittle)
	{
		byteswap((char*)shortaverage, 2, averagesize);
		byteswap((char*)shortfullout, 2, outsize);
	}//shortaverage, shortfullout ready to write
	free(average);
	free(fullout);
	char outname[256];
	sprintf(outname, "%s.t01", argv[3]);
	FILE* outfile = fopen(outname, "wb");
	if (!outfile)
	{
		printf("error opening file '%s'\n", outname);
		return -1;
	}
	if ((int)fwrite((void*)&myhead, 1, 2048, outfile) != 2048)
	{
		printf("error writing data, out of space?\n");
		return -1;
	}
	if ((int)fwrite((void*)shortfullout, sizeof(short), outsize, outfile) != outsize)
	{
		printf("error writing data, out of space?\n");
		return -1;
	}
	fclose(outfile);
	sprintf(outname, "%s.x01", argv[3]);
	outfile = fopen(outname, "wb");
	if (!outfile)
	{
		printf("error opening file '%s'\n", outname);
		return -1;
	}
	if ((int)fwrite((void*)&myhead, 1, 2048, outfile) != 2048)
	{
		printf("error writing data, out of space?\n");
		return -1;
	}
	if ((int)fwrite((void*)shortaverage, sizeof(short), averagesize, outfile) != averagesize)
	{
		printf("error writing data, out of space?\n");
		return -1;
	}
	fclose(outfile);
	free(shortfullout);
	free(shortaverage);
	return 0;
}
