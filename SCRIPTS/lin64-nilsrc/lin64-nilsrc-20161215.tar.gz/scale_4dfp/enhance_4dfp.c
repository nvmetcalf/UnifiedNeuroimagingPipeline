/*$Header: /data/petsun4/data1/src_solaris/scale_4dfp/RCS/enhance_4dfp.c,v 1.1 2015/05/06 06:58:45 avi Exp $*/
/*$Log: enhance_4dfp.c,v $
 * Revision 1.1  2015/05/06  06:58:45  avi
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <endianio.h>				/* getpid () */
#include <Getifh.h>
#include <rec.h>

#define MAXL	256

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

static char rcsid[] = "$Id: enhance_4dfp.c,v 1.1 2015/05/06 06:58:45 avi Exp $";
int main (int argc, char *argv[]) {
/*************/
/* image I/O */
/*************/
	FILE 		*fp_img, *fp_out;
	char            imgfile[MAXL];
	char            outfile[MAXL];
	char 		imgroot[MAXL];
	char 		outroot[MAXL];
	char		trailer[8] = "enha";
/**************/
/* processing */
/**************/
	IFH		ifh;
        int  		imgdim[4], dimension, orient, isbig;
        float	 	voxdim[3];	
	float		*image3d;
	float		y, v, u, gain = 1.;			/* multiplicative scaling factor */
	float		mode = 1000.;
	char		control = '\0';

/***********/
/* utility */
/***********/
	int		c, i, k;
	char 		*ptr, command[4*MAXL], program[MAXL];

/*********/
/* flags */
/*********/
	int		test = 0;
	int		status = 0;
	int		e37_flag = 1;			/* preserve 1.0e-37 values */

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'Z': e37_flag = 0;				break;
				case '@': control = *ptr++;			*ptr = '\0'; break;
				case 'b': mode = atof (ptr);			*ptr = '\0'; break;
				case 'g': gain = atof (ptr);			*ptr = '\0'; break;
			}
		} else switch (k) {
			case 0:	getroot (argv[i], imgroot);			k++; break;
		}	
	}
	if (k < 1) {
		printf ("Usage:\t%s <image_4dfp> [options]\n", program);
		printf ("\toption\n");
		printf ("\t-Z\tcode 1.e-37 values as 0 (default 1.e-37)\n");
		printf ("\t-b<flt>\tspecify mode (default=%.0f)\n", mode);
		printf ("\t-g<flt>\tspecify gain (default=%.4f)\n", gain);
		printf ("\t-@<b|l>\toutput big or little endian (default input endian)\n");
		exit (1);
	}
	printf ("%s: gain=%.4f\n", program, gain);
	printf ("%s: mode=%.0f\n", program, mode);

	sprintf (outroot, "%s_%s", imgroot, trailer);
/*****************************/
/* get input 4dfp dimensions */
/*****************************/
	sprintf (imgfile, "%s.4dfp.img", imgroot);
	sprintf (outfile, "%s.4dfp.img", outroot);
	if (get_4dfp_dimoe (imgfile, imgdim, voxdim, &orient, &isbig) < 0) errr (program, imgfile);
	if (Getifh (imgfile, &ifh)) errr (program, imgroot);
	if (!control) control = (isbig) ? 'b' : 'l';
	dimension = imgdim[0]*imgdim[1]*imgdim[2];

/****************/
/* alloc buffer */
/****************/
	if (!(image3d = (float *) malloc (dimension*sizeof (float)))) errm (program);

/***********/
/* process */
/***********/
	if (!(fp_img = fopen (imgfile, "rb"))) errr (program, imgfile);
	if (!(fp_out = fopen (outfile, "wb"))) errw (program, outfile);
	fprintf (stdout, "Reading: %s\n", imgfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	for (k = 0; k < imgdim[3]; k++) {
		fseek (fp_img, (long) k*dimension*sizeof (float), SEEK_SET);
		if (eread (image3d, dimension, isbig, fp_img)) errr (program, imgfile);
		for (i = 0; i < dimension; i++) {
			if (image3d[i] == (float) 1.0e-37) {
				if (!e37_flag) image3d[i] = 0.;
				continue;
			}
			y = image3d[i]/mode - 1.0;
			v = tanh(y*gain);
			u = v/tanh(gain) + 1.;
			image3d[i] = u*mode;
		}
		fseek (fp_out, (long) k*dimension*sizeof (float), SEEK_SET);
		if (ewrite (image3d, dimension, control, fp_out)) errw (program, outfile);
	}
	fclose (fp_img);
	fclose (fp_out);

/***************/
/* ifh and hdr */
/***************/
	if (Writeifh (program, outfile, &ifh, control)) errw (program, outfile);
	sprintf (command, "ifh2hdr %s -r%.0f", outroot, 2.*mode); printf ("%s\n", command);
	status = system (command);
/*******/
/* rec */
/*******/
	startrece (outfile, argc, argv, rcsid, control);
	catrec (imgfile);
	endrec ();

	free (image3d);
	exit (status);
}
