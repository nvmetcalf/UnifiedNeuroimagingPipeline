c$Header: /data/petsun4/data1/src_solaris/algebra_4dfp/RCS/dft_test.f,v 1.1 2016/05/28 07:01:20 avi Exp $
c$Log: dft_test.f,v $
c Revision 1.1  2016/05/28  07:01:20  avi
c Initial revision
c

      subroutine dft_test(n)
      pointer (pF,F),(pFt,Ft),(pG,G)
      complex*8 F(0:n-1,0:n-1),Ft(0:n-1,0:n-1),G(0:n-1,0:n-1)
      
      twopi=8.*atan(1.)
      pF=malloc(8*n*n)
      pG=malloc(8*n*n)
      pFt=malloc(8*n*n)

      do 10 l=0,n-1
      do 10 m=0,n-1
      theta=(twopi*l*m)/n
   10 F(l,m)=cmplx(cos(theta),-sin(theta))
      do 11 l=0,n-1
      do 11 m=0,n-1
   11 Ft(l,m)=conjg(F(m,l))

      do 21 l=0,n-1
      do 21 m=0,n-1
      G(l,m)=cmplx(0.,0.)
      do 21 k=0,n-1
   21 G(l,m)=G(l,m)+F(l,k)*Ft(k,m)

      write(*,"('F')")
      do 30 l=0,6
   30 write(*,"(14f10.4)")(F(l,m),m=0,6)
      write(*,"('Ft')")
      do 31 l=0,6
   31 write(*,"(14f10.4)")(Ft(l,m),m=0,6)
      write(*,"('G')")
      do 32 l=0,6
   32 write(*,"(14f10.4)")(G(l,m),m=0,6)

      call free(pF)
      call free(pG)
      call free(pFt)
      return
      end
