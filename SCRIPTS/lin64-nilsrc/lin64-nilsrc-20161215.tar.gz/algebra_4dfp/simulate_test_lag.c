/*$Header: /data/petsun4/data1/src_solaris/algebra_4dfp/RCS/simulate_test_lag.c,v 1.9 2016/10/09 01:21:56 avi Exp avi $*/
/*$Log: simulate_test_lag.c,v $
 * Revision 1.9  2016/10/09  01:21:56  avi
 * correct multiple miscellaneous errors
 *
 * Revision 1.8  2016/10/06  23:24:37  avi
 * spline interpolation working
 *
 * Revision 1.7  2016/10/05  03:34:49  avi
 * shift code installed
 *
 * Revision 1.6  2016/10/04  00:22:25  avi
 * linear interpolation (gap.c) installed
 *
 * Revision 1.5  2016/10/02  02:35:31  avi
 * stabilized end censoring
 *
 * Revision 1.4  2016/10/01  05:25:38  avi
 * censoring code
 *
 * Revision 1.3  2016/09/28  03:25:27  avi
 * remove extraneous code
 * generate_format ()
 *
 * Revision 1.2  2016/09/27  04:48:14  avi
 * Hadamard subroutine
 *
 * Revision 1.1  2016/09/20  23:38:50  avi
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* R_OK */
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <float.h>
#include <assert.h>
#include <librms.h>

#define MAXL		256	/* maximum string length */
#define NROI		2
#define NITER		100
#define TR		1.0	/* default frame TR in sec */
#define TAUMAX		5.0	/* default +/- maximum lag in sec */
#define K_STILL		0.05	/* default  still state reciprocal time constant (Hz) */
#define K_MOTION	1.0	/* default motion state reciprocal time constant (Hz) */
#define INTERP_MODE	0	/* 0:none; 1:linear; 2:cubic spline */

/*************/
/* externals */
/*************/
extern double	dnormal (void);								/* dnormal.c */
extern int 	find_gaps1 (char *format, int tpad, int *t0, int *t1, int ngapmax);	/* gap.c */
extern void	fill_gaps (float *fpad,  int tpad, int *t0, int *t1, int ngap);		/* gap.c */
extern void	splinec (float *x, float *y, int n, float *y2);				/* splinec.c */
extern float	splintc (float *xa, float *ya, float *y2a, int n, float x);		/* splinec.c */
extern int	splinec_test (int argc, char *argv[]);					/* splinec.c */

/********************/
/* global variables */
/********************/
static char	rcsid[] = "$Id: simulate_test_lag.c,v 1.9 2016/10/09 01:21:56 avi Exp avi $";
static char	program[MAXL];
static int	debug = 0;
static int	verbose = 0;

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation error\n", program);
	exit (-1);
}

void errr (char* program, char* filespc) {
	fprintf (stderr, "%s: %s read error\n", program, filespc);
	exit (-1);
}

void errw (char* program, char* filespc) {
	fprintf (stderr, "%s: %s write error\n", program, filespc);
	exit (-1);
}

static int split (char *string, char *srgv[], int maxp) {
	int	i, m;
	char	*ptr;

	if (ptr = strchr (string, '#')) *ptr = '\0';
	i = m = 0;
	while (m < maxp) {
		while (!isgraph ((int) string[i]) && string[i]) i++;
		if (!string[i]) break;
		srgv[m++] = string + i;
		while (isgraph ((int) string[i])) i++;
		if (!string[i]) break;
		string[i++] = '\0';
	}
	return m;
}

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

float ***calloc_float3 (int n1, int n2, int n3) {
	unsigned int	i, j;
	float		***a;

	if (!(a = (float ***) malloc (n1 * sizeof (float **)))) errm (program);
	if (!(a[0] = (float **) malloc (n1 * n2 * sizeof (float *)))) errm (program);
	if (!(a[0][0] = (float *) calloc (n1 * n2 * n3, sizeof (float)))) errm (program);
	for (i = 0; i < n1; i++) {
		a[i] = a[0] + n2*i;
		for (j = 0; j < n2; j++) {
			a[i][j] = a[0][0] + n3*(n2*i + j);
		}
	}
	return a;
}

void free_float3 (float ***a) {
	free (a[0][0]);
	free (a[0]);
	free (a);
}

int **calloc_int2 (int n1, int n2) {
	int	i;
	int	**a;

	if (!(a = (int **) malloc (n1 * sizeof (int *)))) errm (program);
	if (!(a[0] = (int *) calloc (n1 * n2, sizeof (int)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_int2 (int **a) {
	free (a[0]);
	free (a);
}

double zero_mean (float *f, int npts) {
	int		i, n;
	double		u;

	for (u = n = i = 0; i < npts; i++) u += f[i];
	u /= npts;
	for (i = 0; i < npts; i++) f[i] -= u;
	return u;
}

double unit_var (float *f, int npts) {
	int		i;
	double		v;

	for (v = i = 0; i < npts; i++) v += f[i]*f[i];
	v /= npts;
	for (i = 0; i < npts; i++) f[i] /= sqrt (v);
	return v;
}

void matlst (float **C, int k) {
	int		i, j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < k; j++) printf ("%10.6f", C[j][i]);
		printf ("\n");
	}
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
        int             i;
        fprintf (outfp, "#%s", program);
        for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
        fprintf (outfp, "\n#%s\n", rcsid);
}

void hadamard_set (float ***H, int kmax) {
	float	s;
	int	i, j, k, n, no2, ii, jj;

	for (k = 0; k < kmax; k++) {
		n = 1 << k;
		H[k] = calloc_float2 (n, n);
		if (!k) {
			H[0][0][0] = 1.;
			continue;
		}
		no2 = n/2;
		if (0) printf ("k=%d n=%d\n", k, n);
		for (i = 0; i < 2; i++) for (j = 0; j < 2; j++) {
			s = (i*j) ? -1. : 1.;
			for (ii = 0; ii < no2; ii++) for (jj = 0; jj < no2; jj++) {
				H[k][i*no2 + ii][j*no2 + jj] = s*H[k - 1][ii][jj];
			}
		}
		printf ("H[%d]\n", k);
		matlst (H[k], n);
	}
}

void hadamard_free (float ***H, int kmax) {
	int	k;
	for (k = 0; k < kmax; k++) free_float2 (H[k]);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void parabolic_interp (float *f, float *delta, float *fmax) {
	double	a0, a1, a2, q;

	a0 = *f;
	a1 = (*(f + 1) - *(f - 1))/2.;
	a2 = (*(f + 1) + *(f - 1))/2. - a0;
	*delta = q = -a1/(2.*a2);
	*fmax = a0 + a1*q + a2*q*q;
}

void generate_format (float k_still, float k_motion, char *format, int npts) {
	int	istate;		/* 0 = still; 1 = motion */
	int	it, i1, i = 0, itsum[2] = {0, 0};
	float	k[2];		/* rate constants in units of /frame */
	float	t, tsum[2] = {0., 0.};

	k[0] = k_still; k[1] = k_motion;
	istate = (drand48() > 1/(1. + (k_motion/k_still))) ? 0 : 1;
	while (i < npts) {
		t = -log(drand48())/k[istate];
		tsum[istate] += t;
		it = (int) floor (t + 0.5);
		itsum[istate] += it;
		if (it < 1) continue;
		i1 = i + it; if (i1 > npts) i1 = npts;
		if (0) printf ("i=%3d it=%3d i1=%3d istate=%d k[istate]=%.2f\n", i, it, i1, istate, k[istate]);
		while (i < i1) format[i++] = istate;
		istate = (istate) ? 0 : 1;
	}
	if (0) printf ("floating still fraction = %.4f integer = %.4f\n",
		1./(1. + tsum[1]/tsum[0]), 1./(1. + (float) itsum[1]/itsum[0]));
}

void usage () {
	fprintf (stderr, "Usage:	%s <(int) npts> <(ASCII) model cor matrix>\n", program);
	fprintf (stderr, "	option\n");
	fprintf (stderr, "	-v	verbose mode\n");
	fprintf (stderr, "	-i<int>	specify srand48 seed (default 0)\n");
	fprintf (stderr, "	-N<int>	specify niter (default %d)\n", NITER);
	fprintf (stderr, "	-t<flt>	specify frame_TR in sec (default %.4f sec)\n", TR);
	fprintf (stderr, "	-T<flt>	specify taumax in sec (default %.2f sec)\n", TAUMAX);
	fprintf (stderr, "	-l<flt>	shift ROI1 relative to ROI0 by specified lag (in sec) (default no shift)\n");
	fprintf (stderr, "	-E	enable simulated frame censoring\n");
	fprintf (stderr, "	-F	print  simulated censoring time series\n");
	fprintf (stderr, "	-D	write (up to 10 Yn.dat files) simulated time series before/after interp\n");
	fprintf (stderr, "	-X	disable temporal segment boundary logic\n");
	fprintf (stderr, "	-I<int>	specify interpolation mode (default %d)\n", INTERP_MODE);
	fprintf (stderr, "		interpolation modes: 0 = none; 1 = linear; 2 = cubic spline;\n");
	fprintf (stderr, "	-L<str>	write lag output to named file\n");
	fprintf (stderr, "	-G<str>	write single iter ROI0:ROI1 cov functions (limit=30) to named file\n");
	fprintf (stderr, "	k_still=<flt>	specify still state  reciprocal time constant (default=%.4f Hz)\n",
					K_STILL);
	fprintf (stderr, "	k_motion=<flt>	specify motion state reciprocal time constant (default=%.4f Hz)\n",
					K_MOTION);
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*covfp, *lagfp, *corfp, *datfp;
	char		lagfile[MAXL] = "", datfile[MAXL] = "", covfile[MAXL] = "", corfile[MAXL];
	int		nROI = NROI, npts;
	int		one = 1, negone = -1;
	int		iter, niter = NITER;
	long		iseed = 0;
	float		**X, **Y, **Y1, **Z, **C, **W, **Wt, **S, **T, **B, **Qnorm, **D, **G, **YYt;
	float		**H[10];
	float		*a, *b, *p, *y2, psdsum, sump, suml, tr = TR;
	float		factor, freq, fhalf_lo = 0.01, fhalf_hi = 0.1, r_hi, r_lo, beta = 0.7;

/*********************/
/* lagged covariance */
/*********************/
 	int		**kmax, ncov, itau = 0, maxshift;
	float		***cov, **covmax, **covs, sign, taumax = TAUMAX;
	float		delta, tau = 0., phi, twopi = 2.*M_PI;

/*******************/
/* frame censoring */
/*******************/
	char		*format;
	float		k_still = K_STILL, k_motion = K_MOTION;		/* in units of /sec */
	long int	mpts = 0, ntot;
	int		*t0, *t1, igap, ngap, ngapmax;

/***********/
/* utility */
/***********/
	int		c, i, j, k, k0, k1, khad, m;
	char		*ptr, command[MAXL], *srgv[MAXL], string[8*MAXL];
;
	double		q, v;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		use_Qnorm = 0;
	int		Ex;
	int		interp_mode = INTERP_MODE;
	int		save_dat = 0;
	int		censor = 0;
	int		F_flag = 0;	/* printf simulated frame censoring */
	int		X_flag = 0;	/* disable matching (uncensored) inner product limits at all lags */

/*	float		fmax, f[3] = {1., 0., 1.};
	parabolic_interp (f + 1, &delta, &fmax); printf ("delta=%f fmax=%f\n", delta, fmax); exit (0);
*/
if (0) {
	splinec_test (argc, argv); exit (0);
}
	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'v': verbose++;				break;
				case 'd': debug++;				break;
				case 'D': save_dat++;				break;
				case 'E': censor++;				break;
				case 'F': F_flag++;				break;
				case 'X': X_flag++;				break;
				case 'L': strncpy (lagfile, ptr, MAXL - 1);	*ptr = '\0'; break;
				case 'G': strncpy (covfile, ptr, MAXL - 1);	*ptr = '\0'; break;
				case 'T': taumax = atof (ptr);			*ptr = '\0'; break;
				case 'l': tau = atof (ptr);			*ptr = '\0'; break;
				case 't': tr = atof (ptr);			*ptr = '\0'; break;
				case 'i': iseed = atoi (ptr);			*ptr = '\0'; break;
				case 'I': interp_mode = atoi (ptr);		*ptr = '\0'; break;
				case 'N': niter = atoi (ptr);			*ptr = '\0'; break;
			}
		} else if (ptr = strchr (argv[i], '=')) {
			m = ptr++ - argv[i];
			if (!strncmp (argv[i], "k_still",  m)) k_still  = atof (ptr);
			if (!strncmp (argv[i], "k_motion", m)) k_motion = atof (ptr);
		} else switch (k) {
			case 0: npts = atoi (argv[i]);				k++; break;
			case 1: strcpy (corfile, argv[i]);			k++; break;
		}	
	}
	if (k < 2) usage ();
	if (!censor) interp_mode = 0;

	printf ("npts=%d\n", npts);
/**********************/
/* initialize srand48 */
/**********************/
	srand48 (iseed);

if (0) {
/***************************/
/* test generate_format () */
/***************************/
	if (!(format = calloc (npts,  sizeof (char)))) errm (program);
	for (j = 0; j < 100; j++) {
		generate_format (k_still*tr, k_motion*tr, format, npts);
		for (i = 0; i < npts; i++) printf ("%d", format[i]); printf ("\n");
	}
	free (format);
	exit (0);
}

/****************/
/* read corfile */
/****************/
	if (corfile[0] == 'c') {
		k = atoi (corfile + 1);
		khad = 1; while (k >>= 1) khad++;
		nROI = 1 << khad - 1;
		printf ("nROI=%d khad=%d\n", nROI, khad);
		C =	calloc_float2 (nROI, nROI);
		W =	calloc_float2 (nROI, nROI);
		Wt =	calloc_float2 (nROI, nROI);
		D =	calloc_float2 (nROI, nROI);
		G =	calloc_float2 (nROI, nROI);
		T =	calloc_float2 (nROI, nROI);
		hadamard_set  (H, khad);
		for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) W[i][j] = H[khad - 1][i][j]/sqrt(nROI);
		transpos_ (W[0], Wt[0], &nROI);
		for (i = 0; i < nROI; i++) D[i][i] = 16. - i;
		matmul_ (W[0], D[0],  G[0], &nROI);
		matmul_ (G[0], Wt[0], T[0], &nROI);
		for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) C[i][j] = T[i][j]/sqrt(T[i][i]*T[j][j]);
		hadamard_free (H, khad);
		free_float2 (W); free_float2 (Wt); free_float2 (D); free_float2 (G); free_float2 (T);
	} else if (corfile[0] == 'd') {
		nROI = atoi (corfile + 1);
		C =	calloc_float2 (nROI, nROI);
		for (i = 0; i < nROI; i++) C[i][i] = 1.;
 		for (i = 0; i < nROI; i += 2) C[i + 1][i] = C[i][i + 1] = 0.9 - i/20.;
	} else {
		printf ("Reading: %s\n", corfile);
		if (!(corfp = fopen (corfile, "r"))) errr (program, corfile);
		nROI = 0; while (fgets (string, 8*MAXL, corfp)) {
			if (!(m = split (string, srgv, MAXL))) continue;
			nROI = m; break;
		}
		rewind (corfp);
		C = calloc_float2 (nROI, nROI);
		i = 0; while (fgets (string, 8*MAXL, corfp)) {
			if (!(m = split (string, srgv, MAXL))) continue;
			for (j = 0; j < nROI; j++) C[i][j] = atof (srgv[j]);
			i++;
		}
		assert (i = nROI);
		fclose (corfp);
	}
	printf ("nROI=%d\n", nROI);
	X	= calloc_float2 (nROI, npts);
	Y	= calloc_float2 (nROI, npts);
	Y1	= calloc_float2 (nROI, npts);	/* interpolated Y */
	Z	= calloc_float2 (nROI, npts);
	S	= calloc_float2 (nROI, npts);
	W	= calloc_float2 (nROI, nROI);
	Wt	= calloc_float2 (nROI, nROI);
	D	= calloc_float2 (nROI, nROI);
	T	= calloc_float2 (nROI, nROI);	/* sqrt(D) */
	G	= calloc_float2 (nROI, nROI);	/* sqrt(D)*Wt */
	B	= calloc_float2 (nROI, nROI);	/* B = sqrt(D)*Wt*Qnorm */
	YYt	= calloc_float2 (nROI, nROI);	/* computed C */
	Qnorm	= calloc_float2 (nROI, nROI);	/* sqrt(npts/sump)*I */
	if (!(format	= calloc (npts,  sizeof (char))))	errm (program);
	if (!(a		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(b		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(p		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(y2	= calloc (npts,  sizeof (float))))	errm (program);	/* spline coefficients */
	maxshift = (int) (taumax/tr + FLT_EPSILON);
	ncov = 2*maxshift + 1;
	cov	= calloc_float3 (nROI, nROI, ncov);
	covs	= calloc_float2 (niter, ncov);
	kmax	= calloc_int2   (nROI, nROI);
	covmax	= calloc_float2 (nROI, nROI);
	ngapmax = npts/2;
	if (!(t0 = (int *) calloc (ngapmax, sizeof (int)))) errm (program);
	if (!(t1 = (int *) calloc (ngapmax, sizeof (int)))) errm (program);

/****************/
/* filter kernel*/
/****************/
	a[0] = 1.;
	fft_ (a, b, &one, &npts, &one, &negone);	/* forward fft */
	for (i = 0; i < npts; i++) {
		freq = (float) i/(tr*npts);
		r_hi = pow((freq/fhalf_hi), 4.);	/* 4 = 2*order */
		r_lo = pow((freq/fhalf_lo), 4.);	/* 4 = 2*order */
		q = (i) ? pow(freq, -beta) : 0.;
		factor = q*sqrt(1./(1. + r_hi))*sqrt(r_lo/(1. + r_lo));	/* band-pass filtered scale-free */
		a[i] *= factor; b[i] *= factor;
		if (0) printf ("bin=%d freq=%f r_hi=%f factor=%f\n", i, freq, r_hi, factor);
	}
	fft_ (a, b, &one, &npts, &one, &one);		/* inverse fft */
/***************************************/
/* make kernel zero mean unit variance */
/***************************************/
	zero_mean (a, npts);
	unit_var  (a, npts);
	for (v = i = 0; i < npts; i++) v += a[i]*a[i];
	for (i = 0; i < npts; i++) b[i] = 0.;
	fft_ (a, b, &one, &npts, &one, &negone);
/**************/
/* define psd */
/**************/
	for (q = i = 0; i < npts; i++) q += p[i] = a[i]*a[i] + b[i]*b[i];
/**********************************/
/* demonstrate Parseval's theorem */
/**********************************/
	printf ("kernel var = %f fft var = %f\n", v/npts, q/(npts*npts));
	psdsum = q/(npts*npts);
	for (sump = i = 0; i < npts; i++) sump += p[i];
	for (i = 0; i < nROI; i++) Qnorm[i][i] = sqrt(npts/sump);
	if (0) printf ("sqrt(npts/sump) = %f\n", Qnorm[0][0]);

/*****************/
/* diagonalize C */
/*****************/
	matcop_   (C[0], D[0],  &nROI);
	eigen_    (D[0], W[0],  &nROI);
	transpos_ (W[0], Wt[0], &nROI);
	matmul_   (W[0], D[0],  G[0], &nROI);
	matmul_   (G[0], Wt[0], YYt[0], &nROI);
	if (nROI) matcop_ (YYt[0], C[0], &nROI);
	if (1) {
		printf ("C\n");			matlst (C,	nROI);
		printf ("W\n");			matlst (W,	nROI);
		printf ("Wt\n");		matlst (Wt,	nROI);
		printf ("D\n");			matlst (D, 	nROI);
		printf ("W*D*Wt\n");		matlst (YYt,	nROI);
	}
 	for (suml = i = 0; i < nROI; i++) suml += D[i][i];

	for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) {
		T[j][i] = (i == j) ? sqrt(D[j][i]) : 0.;	/* T = sqrt(D) */
		YYt[j][i] = 0.;
	}
	matmul_ (T[0],    Wt[0], G[0], &nROI);			/* G = sqrt(D)*Wt */
	matmul_ (G[0], Qnorm[0], B[0], &nROI);			/* B = sqrt(D)*Wt*Qnorm */
	if (verbose) {
		printf ("T = sqrt(D)\n"); matlst (T, nROI);
		printf ("G = sqrt(D)*Wt\n"); matlst (G, nROI);
	}

/****************************/
/* open lagfile for writing */
/****************************/
	if (strlen (lagfile)) {
		if (!(lagfp = fopen (lagfile, "w"))) errw (program, lagfile);
		fprintf (stdout, "Writing: %s\n", lagfile);
		write_command_line (lagfp, argc, argv);
	}

/**************/
/* populate Z */
/**************/
	for (iter = 0; iter < niter; iter++) {
		if (censor) generate_format (k_still*tr, k_motion*tr, format, npts);

/**************************************/
/* compute k range for cov evaluation */
/**************************************/
		k0 = maxshift;
		do {Ex = 0; k = k0; while (k > k0 - maxshift) {if (format[--k]) Ex++;} if (Ex) k0++;
		} while (Ex);
		k1 = npts - maxshift;
		do {Ex = 0; k = k1; while (k < k1 + maxshift + 1) {if (format[k++]) Ex++;} if (Ex) k1--;
		} while (Ex);
		if (F_flag) {
			for (i = 0; i < npts; i++) printf ("%d", format[i]); printf ("\n");
			printf ("k0=%d k1=%d\n", k0, k1);
		}
		if (X_flag) {k0 = 0; k1 = npts;}

		ngap = find_gaps1 (format, npts, t0, t1, ngapmax);
		if (0) for (igap = 0; igap < ngap; igap++) printf ("gap%5d%5d%5d\n", igap + 1, t0[igap], t1[igap]);

		for (j = 0; j < nROI; j++) {
			for (i = 0; i < npts; i++) {a[i] = dnormal(); b[i] = 0.;}
/****************************************/
/* apply spectral filter defined in psd */
/****************************************/
			fft_ (a, b, &one, &npts, &one, &negone);
			for (i = 0; i < npts; i++) {a[i] *= sqrt(p[i]); b[i] *= sqrt(p[i]);}
			fft_ (a, b, &one, &npts, &one, &one);

			for (i = 0; i < npts; i++) S[j][i] = X[j][i] = a[i];
			zero_mean (X[j], npts);
			unit_var  (X[j], npts);
			if (0 & iter < 1) {
				printf ("X/S ROI=%d\n", j) ;
				for (i = 0; i < 16; i++)  printf ("%10.6f", X[j][i]/S[j][i]); printf ("\n");
			}
		}
		if (verbose) {
			printf ("Z\n", j);
			for (i = 0; i < npts; i++) {
				for (j = 0; j < nROI; j++) printf ("%10.6f", Z[j][i]);
				printf ("\n");
			}
		}
		if (!use_Qnorm)	{
/*********************************/
/* Y is normalized by unit_var() */
/*********************************/
			matmulg_ (X[0], &npts, &nROI, G[0], &nROI, Y[0]);
		} else {
/*******************************/
/* Y is normalized using Qnorm */
/*******************************/
			matmulg_ (S[0], &npts, &nROI, B[0], &nROI, Y[0]);
		}

/**************/
/* shift Y[1] */
/**************/
		for (i = 0; i < npts; i++) {a[i] = Y[1][i]; b[i] = 0.;}
		fft_ (a, b, &one, &npts, &one, &negone);
		for (i = 1; i < npts/2; i++) {
			phi = twopi*i*tau/(npts*tr);
			a[npts - i] = a[i]*cos(phi) + b[i]*sin(phi);
			b[npts - i] = a[i]*sin(phi) - b[i]*cos(phi);
			a[i] =  a[npts - i];
			b[i] = -b[npts - i];
		}
		fft_ (a, b, &one, &npts, &one, &one);
		for (i = 0; i < npts; i++) Y[1][i] = a[i];

		if (interp_mode == 2) {
/**************************************/
/* cubic spline interpolate over gaps */
/**************************************/
			for (j = 0; j < nROI; j++) {
				m = 0;
				for (k = k0; k < k1; k++) {
					if (!format[k]) {
						a[m] = (float) k;
						b[m] = Y[j][k];
						m++;
					}
				}
				splinec (a, b, m, y2);
				for (k = k0; k < k1; k++) {
					Y1[j][k] = (format[k]) ? splintc (a, b, y2, m, (float) k) : Y[j][k];
				}
			}
		} else if (interp_mode == 1) {
/**********************************/
/* linearly interpolate over gaps */
/**********************************/
			for (j = 0; j < nROI; j++) {	
				for (i = 0; i < npts; i++) Y1[j][i] = Y[j][i];
				fill_gaps (Y1[j], npts, t0, t1, ngap);
			}
		}
		if (save_dat && iter < 10) {
			sprintf (datfile, "Y%d.dat", iter);
			printf ("Writing: %s\n", datfile);
			if (!(datfp = fopen (datfile, "w"))) errw (program, datfile);
			for (k = k0; k < k1; k++) {
				fprintf (datfp, "%10.4f", k*tr);
				for (j = 0; j < nROI; j++) fprintf (datfp, "%10.4f%10.4f", Y[j][k], Y1[j][k]);
				fprintf (datfp, "\n");
			}
			if (fclose (datfp)) errw (program, datfile);
		}
		if (interp_mode) for (j = 0; j < nROI; j++) for (k = k0; k < k1; k++) Y[j][k] = Y1[j][k];

/*****************************/
/* compute lagged covariance */
/*****************************/
		for (i = 0; i < nROI; i++ ) for (j = i; j < nROI; j++) {
			sign = (C[i][j] > 0.) ? 1.0 : -1.0;
			for (m = 0; m < ncov; m++) {
				cov[i][j][m] = ntot = 0;
				for (k = k0; k < k1; k++) {
					itau = m - maxshift + k;
					if (interp_mode || (!format[k] && !format[itau])) {
						cov[i][j][m] += Y[i][k]*Y[j][itau];
						ntot++;
					}
				}
				cov[i][j][m] /= ntot;
			}

/****************************/
/* locate cov function peak */
/****************************/
			for (kmax[i][j] = k = 0; k < ncov; k++) {
				if (sign*cov[i][j][k] > sign*cov[i][j][kmax[i][j]]) kmax[i][j] = k;
			}
			if (kmax[i][j] > 0 && kmax[i][j] < ncov - 1) {
				parabolic_interp (cov[i][j] + kmax[i][j], &delta, &covmax[i][j]);
			} else {
				covmax[i][j] = cov[i][j][kmax[i][j]];
				delta = 0.;
			}
			if (strlen (lagfile)) fprintf (lagfp, "%5d%5d%10.4f%10.4f%10.4f\n",
					i, j, (kmax[i][j] + delta)*tr - taumax, covmax[i][j], C[i][j]);
		}
		mpts += ntot;
		for (m = 0; m < ncov; m++) covs[iter][m] = cov[0][1][m];

	}	/* iter loop */
	if (strlen (lagfile)) if (fclose (lagfp)) errw (program, lagfile);

	if (censor) printf ("k_still = %.4f k_motion = %.4f\n", k_still, k_motion);
	ntot = (X_flag) ? npts : (npts - 2*maxshift);
	if (0) printf ("ntot=%d mpts=%d niter=%d\n", ntot, mpts, niter);
	q = (float) mpts / (float) (niter*ntot);
	printf ("uncensored fraction = %.4f\n", q);

	if (strlen (covfile)) {
/*********************************************************/
/* write computed lagged covariance functions (ROIs 0 1) */
/*********************************************************/
		printf ("Writing: %s\n", covfile);
		if (!(covfp = fopen (covfile, "w"))) errw (program, covfile);
		for (k = 0; k < ncov; k++) {
			fprintf (covfp, "%10.4f", (k - maxshift)*tr);
			for (iter = 0; iter < 30; iter++) fprintf (covfp, "%10.4f", covs[iter][k]);
			fprintf (covfp, "\n");
		}
		if (fclose (covfp)) errw (program, covfile);
	}

DONE:	free_float2 (C);
	free_float2 (X); free_float2 (Y);   free_float2 (Y1); free_float2 (Z); free_float2 (S);
	free_float2 (W); free_float2 (Wt);  free_float2 (D);  free_float2 (T); free_float2 (G);
	free_float2 (B); free_float2 (YYt); free_float2 (Qnorm);
	free (format); free (a); free (b); free (p); free (y2);
	free_float3 (cov); free_float2 (covs); free_int2 (kmax); free_float2 (covmax);
	free (t0); free (t1);
	exit (status);
}
