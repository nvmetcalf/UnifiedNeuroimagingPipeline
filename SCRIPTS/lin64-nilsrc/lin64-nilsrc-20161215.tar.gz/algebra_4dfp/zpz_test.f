c$Header: /data/petsun4/data1/src_solaris/algebra_4dfp/RCS/zpz_test.f,v 1.2 2016/06/12 08:41:29 avi Exp $
c$Log: zpz_test.f,v $
c Revision 1.2  2016/06/12  08:41:29  avi
c subroutine JMcC_test
c subroutine ytildetytilde_test
c
c Revision 1.1  2016/06/07  05:41:34  avi
c Initial revision
c
      subroutine zpz_test(Z,nROI,npts,p,ZPZ)
      complex*8  Z(0:nROI-1,0:npts-1),ZPZ(0:nROI-1,0:nROI-1)
      real*4 p(0:npts-1)
      pointer (pZp,Zp)
      complex*8 Zp(0:nROI-1,0:npts-1)

      pZp=malloc(8*npts*nROI)

c     do 21 j = 0,nROI-1
c  21 write(*,"(10f10.2)")(Z(j,k),k=0,4)

c     write(*,"(10f10.2)")(p(k),k=0,9)
c     psum=0.
c     do 22 k=0,npts-1
c  22 psum=psum+p(k)
c     write(*,"('psum/npts='f10.2)")psum/npts

      do 10 l=0,nROI-1
      do 10 k=0,npts-1
   10 Zp(l,k)=Z(l,k)*p(k)

      do 11 l=0,nROI-1
      do 11 m=0,nROI-1
      do 11 k=0,npts-1
   11 ZPZ(l,m)=ZPZ(l,m)+Zp(l,k)*conjg(Z(m,k))

      call free(pZp)
      return
      end

      subroutine jmcc_test(Zt,npts,nROI,A,ZtAZ)
      complex*8	Zt(0:npts-1,0:nROI-1),ZtAZ(0:npts-1,0:npts-1)
      real*4	A(0:nROI-1,0:nROI-1)
      pointer   (pB,B)
      complex*8 B(0:npts-1,0:nROI-1)

      pB=malloc(8*npts*nROI)

      do 10 i=0,npts-1
      do 10 j=0,nROI-1
      B(i,j)=cmplx(0.,0.)
      do 10 k=0,nROI-1
   10 B(i,j)=B(i,j)+Zt(i,k)*A(k,j)

      do 11 l=0,npts-1
      do 11 m=0,npts-1
      do 11 k=0,nROI-1
   11 ZtAZ(l,m)=ZtAZ(l,m)+B(l,k)*conjg(Zt(m,k))

      call free(pB)
      return
      end

      subroutine ytildetytilde_test(Yt,npts,nROI,YtY)
      complex*8	Yt(0:npts-1,0:nROI-1),YtY(0:npts-1,0:npts-1)

      do 11 l=0,npts-1
      do 11 m=0,npts-1
      do 11 k=0,nROI-1
   11 YtY(l,m)=YtY(l,m)+Yt(l,k)*conjg(Yt(m,k))

      return
      end
