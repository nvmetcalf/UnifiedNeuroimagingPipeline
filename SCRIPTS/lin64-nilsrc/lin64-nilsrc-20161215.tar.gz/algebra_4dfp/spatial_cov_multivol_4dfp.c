/*$Header: /data/petsun4/data1/src_solaris/algebra_4dfp/RCS/spatial_cov_multivol_4dfp.c,v 1.8 2015/12/09 19:34:26 avi Exp $*/
/*$Log: spatial_cov_multivol_4dfp.c,v $
 * Revision 1.8  2015/12/09  19:34:26  avi
 * correct Z_flag code
 *
 * Revision 1.7  2015/11/03  02:27:29  avi
 * detect and ignore completely undefined input volumes
 *
 * Revision 1.6  2015/02/01  07:55:01  avi
 * diagonalize after writing cov as text
 *
 * Revision 1.5  2015/02/01  04:13:17  avi
 * also output scree plot
 *
 * Revision 1.4  2015/01/31  05:16:12  avi
 * option -p (make PC images)
 **/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* R_OK */
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <float.h>
#include <assert.h>
#ifndef _FEATURES_H		/* defined by math.h in Linux */
	#include <ieeefp.h>
	#include <sunmath.h>	/* isnormal() */
#endif
#include <librms.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>

#define MAXL		256	/* maximum string length */

/********************/
/* global variables */
/********************/
static char	rcsid[] = "$Id: spatial_cov_multivol_4dfp.c,v 1.8 2015/12/09 19:34:26 avi Exp $";
static char	program[MAXL];
static int	debug = 0;

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
	int		i;

	fprintf (outfp, "#%s", program);
	for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
	fprintf (outfp, "\n");
	fprintf (outfp, "#%s\n", rcsid);
}

void usage () {
	fprintf (stderr, "Usage:	%s <(4dfp) image> <(4dfp) mask>\n", program);
	fprintf (stderr, "	option\n");
	fprintf (stderr, "	-Z	compute covariance with respect to zero (default wrt image mean)\n");
	fprintf (stderr, "	-p<int>	generate specified number of PCs (default none)\n");
	fprintf (stderr, "	-c<flt>	scale text output covariance matrix values by specified factor\n");
	fprintf (stderr, "N.B.:	%s counts only defined (not NaN or 1.e-37) voxels\n", program);
	fprintf (stderr, "N.B.:	zero voxels are counted as   defined in <(4dfp) image> in cov computation\n");
	fprintf (stderr, "N.B.:	zero voxels are counted as undefined in <(4dfp) image> in <(4dfp) mask>\n");
	fprintf (stderr, "N.B.:	all zero or all undefined <(4dfp) image> volumes are ignored\n");
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*fpimg, *fptxt;
	IFH		ifh;
	char		imgroot[2][MAXL], imgfile[MAXL];
	char		outfile[MAXL];
	float		**img1, *mean, **cov, **w, scale = 1.0;
	int		*imgm, *vlst;
	float		voxdim[3], voxdim1[3];
	int		orient, orient1, imgdim[2][4], nvox, vdim, nvol, nvol0, isbig[2];

/***********/
/* utility */
/***********/
	int		c, i, j, k, l, k1, l1;
	char		*ptr, command[MAXL];
	double		q;

/*****************/
/* PC generation */
/*****************/
	int		iPC, nPC = 0;
	char		weifile[MAXL];

/*********/
/* flags */
/*********/
	int		defined;
	int		debug = 0;
	int		Z_flag = 0;
	int		status = 0;

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'd': debug++;			break;
				case 'Z': Z_flag++;			break;
				case 'c': scale = atof (ptr);		*ptr = '\0';	break;
				case 'p': nPC = atoi (ptr);		*ptr = '\0';	break;
			}
		} else switch (k) {
			case 0:
			case 1:	getroot (argv[i], imgroot[k++]);	break;
		}	
	}
	if (k < 2) usage ();

/*********************************/
/* check dimensional consistency */
/*********************************/
	for (i = 0; i < 2; i++) {
		printf ("input %3d: %s\n", i + 1, imgroot[i]);
		if (!i) {
			if (get_4dfp_dimoe (imgroot[i], imgdim[i],  voxdim, &orient,  isbig + i)) exit (-1);
			if (Getifh (imgroot[i], &ifh)) errr (program, imgroot[i]);
		} else {
			if (get_4dfp_dimoe (imgroot[i], imgdim[i], voxdim1, &orient1, isbig + i)) exit (-1);
			status = (orient1 != orient);
			for (k = 0; k < 3; k++) status |= (imgdim[i][k] != imgdim[0][k]);
			for (k = 0; k < 3; k++) status |= (fabs (voxdim1[k] - voxdim[k]) > 1.e-5);
		}
		if (status) {
			fprintf (stderr, "%s: %s %s nvox mismatch\n", program, imgroot[0], imgroot[i]);
			exit (-1);
		}
	}
	vdim  = imgdim[0][0]*imgdim[0][1]*imgdim[0][2];
	nvol0 = imgdim[0][3];
	img1 = calloc_float2 (2, vdim);

/*************/
/* read mask */
/*************/
	if (!(imgm = (int *) calloc (vdim,  sizeof (int)))) errm (program);
	sprintf (imgfile, "%s.4dfp.img", imgroot[1]);
	printf ("Reading: %s\n", imgfile);
	if (!(fpimg = fopen (imgfile, "rb")) || eread (img1[1], vdim, isbig[1], fpimg)
	|| fclose (fpimg)) errr (program, imgfile);
	for (j = 0; j < vdim; j++) {
		defined = isnormal (img1[1][j]) && img1[1][j] != (float) 1.e-37;
		imgm[j] = (defined) ? 1 : 0;
	}

/***************************/
/* open multi-volume image */
/***************************/
	sprintf (imgfile, "%s.4dfp.img", imgroot[0]);
	printf ("Reading: %s\n", imgfile);
	if (!(fpimg = fopen (imgfile, "rb"))) errr (program, imgfile);

/************************************************************/
/* compile list of valid (not completely undefined) volumes */
/************************************************************/
	if (!(vlst = (int *) calloc (nvol0, sizeof (int)))) errm (program);
	for (nvol = l = k = 0; k < nvol0; k++) {
		vlst[k] = 1;
		if (eread (img1[0], vdim, isbig[0], fpimg)) errr (program, imgfile);
		for (l = j = 0; j < vdim; j++) {
			defined = isnormal (img1[0][j]) && img1[0][j] != (float) 1.e-37;
			if (!defined) l++;
		}
		if (l == vdim) {
			vlst[k] = 0;
		} else {
			nvol++;
		}
	}
	rewind (fpimg);
	printf ("valid volume count = %d\n", nvol);

/**************************/
/* compute defined voxels */
/**************************/
	for (k = 0; k < nvol0; k++) if (vlst[k]) {
		if (fseek (fpimg, (long) k*vdim*sizeof (float), SEEK_SET)
		||  eread (img1[0], vdim, isbig[0], fpimg)) errr (program, imgfile);
		for (j = 0; j < vdim; j++) if (imgm[j]) {
			defined = (isnormal (img1[0][j]) || img1[0][j] == 0.0) && img1[0][j] != (float) 1.e-37;
			if (!defined) imgm[j] = 0;
		}
	}
	rewind (fpimg);
	for (nvox = j = 0; j < vdim; j++) if (imgm[j]) nvox++;

/************************/
/* compute volume means */
/************************/
	if (!(mean = (float *) calloc (nvol, sizeof (float)))) errm (program);
	if (!Z_flag) {
		for (k1 = k = 0; k < nvol0; k++) if (vlst[k]) {
			if (fseek (fpimg, (long) k*vdim*sizeof (float), SEEK_SET)
			||  eread (img1[0], vdim, isbig[0], fpimg)) errr (program, imgfile);
			for (q = j = 0; j < vdim; j++) if (imgm[j]) q += img1[0][j];
			mean[k1++] = q/nvox;
		}
		assert (k1 == nvol);
	}
	rewind (fpimg);
	printf ("defined voxel count = %d\n", nvox);

/******************************/
/* compute spatial covariance */
/******************************/
	cov  = calloc_float2 (nvol, nvol); w = calloc_float2 (nvol, nvol);
	printf ("computing covariance matrix row");
	for (k1 = k = 0; k < nvol0; k++) if (vlst[k]) {printf (" %d", k1 + 1); fflush (stdout);
		if (fseek (fpimg, (long) k*vdim*sizeof (float), SEEK_SET)
		||  eread (img1[0], vdim, isbig[0], fpimg)) errr (program, imgfile);
		l1 = k1;
		for (l = k; l < nvol0; l++) if (vlst[l]) {
			if (fseek (fpimg, (long) l*vdim*sizeof (float), SEEK_SET)
			||  eread (img1[1], vdim, isbig[0], fpimg)) errr (program, imgfile);
			for (q = j = 0; j < vdim; j++) if (imgm[j]) q += (img1[0][j] - mean[k1])*(img1[1][j] - mean[l1]);
			cov[k1][l1] = cov[l1][k1] = q/nvox;
			l1++;
		}
		assert (l1 == nvol);
		k1++;
	}
	assert (k1 == nvol);
	printf ("\n");
	if (fclose (fpimg)) errr (program, imgfile);

/***********************************/
/* write covariance matrix as text */
/***********************************/
	sprintf (outfile, "%s_covariance_matrix.dat", imgroot[0]);
	if (!(fptxt = fopen (outfile, "w"))) errw (program, outfile);
	printf ("Writing: %s\n", outfile);
	write_command_line (fptxt, argc, argv);
	fprintf (fptxt, "#defined voxel count = %d\n", nvox);
	fprintf (fptxt, "#covariance matrix values scaled by = %.1f\n", scale);
	for (k = 0; k < nvol; k++) {
		for (l = 0; l < nvol; l++) fprintf (fptxt, " %9.6f", scale*cov[k][l]);
		fprintf (fptxt, "\n");
	}
	if (fclose (fptxt)) errw (program, outfile);

/***************/
/* diagonalize */
/***************/
	eigen_ (cov[0], w[0], &nvol);

/****************************************/
/* write diagonalization result as text */
/****************************************/
	for (q = i = 0; i < nvol; i++) q += cov[i][i];	/* q <- total variance */
	sprintf (outfile, "%s_scree.dat", imgroot[0]);
	if (!(fptxt = fopen (outfile, "w"))) errw (program, outfile);
	printf ("Writing: %s\n", outfile);
	write_command_line (fptxt, argc, argv);
	fprintf (fptxt, "#eigenvalues scaled by = %.1f\n", scale);
	for (i = 0; i < nvol; i++) {
		fprintf (fptxt, "%5d %10.4f %10.6f\n", i + 1, scale*cov[i][i], 100.*cov[i][i]/q);
	}
	if (fclose (fptxt)) errw (program, outfile);

/*************************************************************************/
/* use actmapf_4dfp to compute PCs as weighted sums of multivolume input */
/*************************************************************************/
	for (iPC = 0; iPC < nPC; iPC++) {
		printf ("computing PC%d eigenvalue = %12.4e\n", iPC + 1, cov[iPC][iPC]);
		sprintf (weifile, "%s_weights%d.dat", imgroot[0], iPC + 1);
		if (!(fptxt = fopen (weifile, "w"))) errw (program, weifile);
		printf ("Writing: %s\n", weifile);
/***********************************************************************/
/* factor of nvol0 compensated during actmapf_4dfp final normalization */
/***********************************************************************/
		for (k1 = k = 0; k < nvol0; k++) {
			if (vlst[k]) {
				fprintf (fptxt, "%.6f\n", w[iPC][k1++]*nvol0/sqrt(nvol));
			} else {
				fprintf (fptxt, "%.6f\n", 0.);
			}
		}
		assert (k1 == nvol);
		if (fclose (fptxt)) errw (program, weifile);
		sprintf (command, "actmapf_4dfp -w%s -aPC%d %d+ %s", weifile, iPC + 1, nvol0, imgroot[0]);
		printf ("%s\n", command);
		status = system (command);
		if (status) exit (status);
	}

DONE:	free_float2 (img1);
	free_float2 (cov); free_float2 (w);
	free (imgm); free (vlst);
	free (mean);
	exit (status);
}
