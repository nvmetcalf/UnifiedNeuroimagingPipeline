/*$Header: /data/petsun4/data1/src_solaris/algebra_4dfp/RCS/simulate_test.c,v 1.12 2016/06/16 02:07:41 avi Exp avi $*/
/*$Log: simulate_test.c,v $
 * Revision 1.12  2016/06/16  02:07:41  avi
 * correct order of operations in computation of B
 * demonstrate that Qnorm preserves spectral structure whereas unit_var() slightly distorts it (evident in PXbar.dat output)
 *
 * Revision 1.11  2016/06/13  03:03:49  avi
 * more useful ZtildetCZtilde.dat output
 *
 * Revision 1.10  2016/06/12  08:43:23  avi
 * ytildetytilde_test works
 *
 * Revision 1.9  2016/06/12  04:02:01  avi
 * include jmcc_test_()
 *
 * Revision 1.8  2016/06/12  02:07:09  avi
 * prior to including jmcc_test_()
 *
 * Revision 1.7  2016/06/07  05:40:25  avi
 * verify E[SSt], E[ZtildePZtildet]
 *
 * Revision 1.6  2016/05/28  07:06:26  avi
 * option -D (run_dft_test)
 *
 * Revision 1.5  2016/05/24  05:05:02  avi
 * psd_test()
 *
 * Revision 1.4  2016/05/23  23:13:24  avi
 * option -e (read eigfile)
 *
 * Revision 1.3  2016/05/23  01:49:21  avi
 * kurtosis_Mardia
 *
 * Revision 1.1  2016/05/17  05:43:59  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* R_OK */
#include <string.h>
#include <math.h>
#include <float.h>
#include <librms.h>

#define MAXL		256	/* maximum string length */
#define NROI		2
#define NITER		100

typedef struct {
	float	r, i;
} CMPLX;

/*************/
/* externals */
/*************/
extern double	dnormal (void);
extern void	dft_test_ (int *n);
extern void	zpz_test_  (CMPLX *Ztilde,  int *nROI, int *npts, float *p, CMPLX *ZPZ);
extern void	jmcc_test_ (CMPLX *Ztildet, int *npts, int *nROI, float *A, CMPLX *ZtCZ);
extern void	ytildetytilde_test_ (CMPLX *ytildet, int *npts, int *nROI, CMPLX *YtildetYtilde);

/********************/
/* global variables */
/********************/
static char	rcsid[] = "$Id: simulate_test.c,v 1.12 2016/06/16 02:07:41 avi Exp avi $";
static char	program[MAXL];
static int	debug = 0;
static int	verbose = 0;

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation error\n", program);
	exit (-1);
}

void errr (char* program, char* filespc) {
	fprintf (stderr, "%s: %s read error\n", program, filespc);
	exit (-1);
}

void errw (char* program, char* filespc) {
	fprintf (stderr, "%s: %s write error\n", program, filespc);
	exit (-1);
}

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm (program);
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

CMPLX **calloc_CMPLX2 (int n1, int n2) {
	int	i;
	CMPLX	**a;

	if (!(a = (CMPLX **) malloc (n1 * sizeof (CMPLX *)))) errm (program);
	if (!(a[0] = (CMPLX *) calloc (n1 * n2, sizeof (CMPLX)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_CMPLX2 (CMPLX **a) {
	free (a[0]);
	free (a);
}

double zero_mean (float *f, int npts) {
	int		i, n;
	double		u;

	for (u = n = i = 0; i < npts; i++) u += f[i];
	u /= npts;
	for (i = 0; i < npts; i++) f[i] -= u;
	return u;
}

double unit_var (float *f, int npts) {
	int		i;
	double		v;

	for (v = i = 0; i < npts; i++) v += f[i]*f[i];
	v /= npts;
	for (i = 0; i < npts; i++) f[i] /= sqrt (v);
	return v;
}

void matlst (float **C, int k) {
	int		i, j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < k; j++) printf ("%10.6f", C[j][i]);
		printf ("\n");
	}
}

void dmatlst (double **C, int k) {
	int		i, j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < k; j++) printf ("%10.6f", C[j][i]);
		printf ("\n");
	}
}

double kurtosis_Mardia (float **G, int nROI, int npts) {
	int		i, j, k;
	double 		q, t, det, *uG, **S, **D, **D2, **X, **Xt, **T;

	if (!(uG= calloc (nROI, sizeof (double)))) errm (program);
	X  = calloc_double2 (nROI, npts);
	Xt = calloc_double2 (npts, nROI);
	T  = calloc_double2 (nROI, npts);
	S  = calloc_double2 (nROI, nROI);
	D  = calloc_double2 (npts, npts);
	D2 = calloc_double2 (npts, npts);

	for (j = 0; j < nROI; j++) {
		for (q = i = 0; i < npts; i++) q += G[j][i];
		uG[j] = q/npts;
	}
	for (j = 0; j < nROI; j++) for (i = 0; i < npts; i++) Xt[i][j] = X[j][i] = G[j][i] - uG[j];
	for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) {
		for (q = k = 0; k < npts; k++) q += X[j][k]*X[i][k];
		S[j][i] = q/npts;
	}
	if (0) {printf ("S\n"); dmatlst (S, nROI);}
	dmatinv_  (S[0], &nROI, &det);
	dmatmulg_ (X[0], &npts, &nROI, S[0],  &nROI, T[0]);
	dmatmulg_ (T[0], &npts, &nROI, Xt[0], &npts, D[0]);
	for (t = i = 0; i < npts; i++) t += D[i][i]*D[i][i];
	t /= npts;

/*************************************************************************************/
/* alternatives uusing D^2 yield the same answer because D is essentially idempotent */
/*************************************************************************************/
/*
	for (t = i = 0; i < npts; i++) {
		for (q = k = 0; k < npts; k++) q += D[i][k]*D[k][i];
		t += q*q;
	}
	t /= npts*npts*npts;

	dmatmul_ (D[0], D[0], D2[0], &npts);
	if (0) printf ("D2[0][1]=%f D2[1][0]=%f\n", D2[0][1], D2[1][0]);
	if (0) printf ("D2[0][0]=%f D2[1][1]=%f\n", D2[0][0], D2[1][1]);
	for (q = i = 0; i < npts; i++) q += D2[i][i]*D2[i][i];
	q /= npts*npts*npts;
	if (0) printf ("t=%f q=%f\n", t, q);
*/
	free (uG);
	free_double2 (S); free_double2 (D); free_double2 (D2); free_double2 (X); free_double2 (Xt); free_double2 (T);
	return t;
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
        int             i;
        fprintf (outfp, "#%s", program);
        for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
        fprintf (outfp, "\n#%s\n", rcsid);
}

void psd_test (int npts, int niter) {
	FILE		*outfp;
	char		outfile[MAXL];
	int		nROI = NROI;
	int		one = 1, negone = -1;
	int		iter;
	float		**Y;
	float		*a, *b, **p;
	float		*kurt;
	float		scale[2] = {0.1, 1.0};

/***********/
/* utility */
/***********/
	int		i, j, k;
	int		odd;

/*********/
/* flags */
/*********/
	int		alternate = 1;
	int		split_psd = 0;

	Y	= calloc_float2 (nROI, npts);
	p	= calloc_float2 (nROI, npts);
	if (!(a		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(b		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(kurt	= calloc (niter, sizeof (float))))	errm (program);

	if (split_psd) {
		for (i = 1;          i <= npts/4; i++) p[0][npts - i] = p[0][i] = 2.;
		for (i = npts/4 + 1; i <  npts/2; i++) p[1][npts - i] = p[1][i] = 2.;
	} else {
		for (j = 0; j < nROI; j++) for (i = 0; i < npts; i++) p[j][i] = 1.;
	}

	strcpy (outfile, "occupancy.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	for (iter = 0; iter < niter; iter++) {
		for (j = 0; j < nROI; j++) {
			for (i = 0; i < npts; i++) {a[i] = dnormal(); b[i] = 0.;}
/****************************************/
/* apply spectral filter defined in psd */
/****************************************/
			fft_ (a, b, &one, &npts, &one, &negone);
			for (i = 0; i < npts; i++) {a[i] *= sqrt(p[j][i]); b[i] *= sqrt(p[j][i]);}
			fft_ (a, b, &one, &npts, &one, &one);
			for (i = 0; i < npts; i++) {
				Y[j][i] = a[i];
				odd = (4*i/npts) % 2; k = (odd + j) % 2;
				if (alternate) Y[j][i] *= scale[k];
			}
		}
		for (i = 0; i < npts; i++) {
			fprintf (outfp, "%10.4f%10.4f\n", Y[0][i], Y[1][i]);
		}
		kurt[iter] = kurtosis_Mardia (Y, nROI, npts);
	}
	if (fclose (outfp)) errw (program, outfile);

	printf ("niter=%d npts=%d\n", niter, npts);
	strcpy (outfile, "kurt.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	for (iter = 0; iter < niter; iter++) fprintf (outfp, "%10.6f\n", kurt[iter]);
	if (fclose (outfp)) errw (program, outfile);

	free_float2 (Y); free_float2 (p);
	free (a); free (b); free (kurt);
	exit (0);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void usage () {
	fprintf (stderr, "Usage:	%s <(int) npts>\n", program);
	fprintf (stderr, "	option\n");
	fprintf (stderr, "	-v	verbose mode\n");
	fprintf (stderr, "	-P	run psd_test (default full simulation)\n");
	fprintf (stderr, "	-D	run dft_test (default full simulation)\n");
	fprintf (stderr, "	-Q	normalize Y using qnorm (default normalize Y using unit_var())\n");
	fprintf (stderr, "	-i<int>	specify srand48 seed (default 0)\n");
	fprintf (stderr, "	-m<int>	specify nROI (default %d)\n", NROI);
	fprintf (stderr, "	-N<int>	specify niter (default %d)\n", NITER);
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*outfp, *eigfp;
	char		outroot[MAXL], outfile[MAXL], string[MAXL], eigfile[MAXL] = "";
	int		nROI = NROI, npts = 512;
	int		one = 1, negone = -1;
	int		iter, niter = NITER, neig = 0;
	long		iseed = 0;
	float		**X, **Y, **Z, **C, **W, **Wt, **S, **T, **B, **Qnorm, **D, **G, **XXt, **YYt, **SSt, **ZZt;
	float		*a, *b, *p, **PXbar, **PYbar, *eigvals, psdsum, sump, suml;
	float		factor, freq, fhalf_lo = 0.01, fhalf_hi = 0.1, r_hi, r_lo, beta = 0.7;
	float		*kurt;
	CMPLX		**Ztilde, **Ztildet, **Ytildet, **YtildetYtilde, **ZPZ, **ZtCZ;

/***********/
/* utility */
/***********/
	int		c, i, j, k;
	char		*ptr, command[MAXL];
	double		q, v;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		run_psd_test = 0;
	int		run_dft_test = 0;
	int		use_Qnorm = 0;

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'v': verbose++;			break;
				case 'd': debug++;			break;
				case 'P': run_psd_test++;		break;
				case 'D': run_dft_test++;		break;
				case 'Q': use_Qnorm++;			break;
				case 'i': iseed = atoi (ptr);		*ptr = '\0';	break;
				case 'm': nROI = atoi (ptr);		*ptr = '\0';	break;
				case 'N': niter = atoi (ptr);		*ptr = '\0';	break;
				case 'e': strcpy (eigfile, ptr);	*ptr = '\0';	break;
			}
		} else switch (k) {
			case 0: npts = atoi (argv[i]);			k++; break;
		}	
	}
	if (k < 1) usage ();

	if (run_dft_test) {
		dft_test_ (&npts);
		exit (0);
	}

/**********************/
/* initialize srand48 */
/**********************/
	srand48 (iseed);
	if (run_psd_test) psd_test (npts, niter);

/****************/
/* read eigfile */
/****************/
	if (strlen (eigfile)) {
		printf ("Reading: %s\n", eigfile);
		if (!(eigfp = fopen (eigfile, "r"))) errr (program, eigfile);
		neig = 0; while (fgets (string, MAXL, eigfp)) neig++;
		if (!(eigvals = calloc (neig, sizeof (float))))	errm (program);
		rewind (eigfp);
		for (i = 0; i < neig; i++) {
			fscanf (eigfp, "%f", eigvals + i);
			printf (" %f", eigvals[i]);
		}
		printf ("\n");
		fclose (eigfp);
		if (nROI > neig) nROI = neig;
	}

	X	= calloc_float2 (nROI, npts);
	Y	= calloc_float2 (nROI, npts);
	Z	= calloc_float2 (nROI, npts);
	S	= calloc_float2 (nROI, npts);
	PXbar	= calloc_float2 (nROI, npts);
	PYbar	= calloc_float2 (nROI, npts);
	C	= calloc_float2 (nROI, nROI);
	W	= calloc_float2 (nROI, nROI);
	Wt	= calloc_float2 (nROI, nROI);
	D	= calloc_float2 (nROI, nROI);
	T	= calloc_float2 (nROI, nROI);	/* sqrt(D) */
	G	= calloc_float2 (nROI, nROI);	/* sqrt(D)*Wt */
	B	= calloc_float2 (nROI, nROI);	/* B = sqrt(D)*Wt*Qnorm */
	Qnorm	= calloc_float2 (nROI, nROI);	/* sqrt(npts/sump)*I */
	XXt	= calloc_float2 (nROI, nROI);
	YYt	= calloc_float2 (nROI, nROI);
	ZZt	= calloc_float2 (nROI, nROI);
	SSt	= calloc_float2 (nROI, nROI);
	Ztilde	= calloc_CMPLX2 (npts, nROI);	/* FORTRAN will see  Ztilde(nROI,npts) */
	Ztildet	= calloc_CMPLX2 (nROI, npts);	/* FORTRAN will see Ztildet(npts,nROI) */
	Ytildet	= calloc_CMPLX2 (nROI, npts);	/* FORTRAN will see Ytildet(npts,nROI) */
	YtildetYtilde	= calloc_CMPLX2 (npts, npts);
	ZPZ	= calloc_CMPLX2 (nROI, nROI);
	ZtCZ	= calloc_CMPLX2 (npts, npts);
	if (!(a		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(b		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(p		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(kurt	= calloc (niter, sizeof (float))))	errm (program);

/*****************/
/* define kernel */
/*****************/
if (0) {
	for (i = 0; i < npts; i++) {
		a[i] = i*i*exp(-i/0.5);
		b[i] = 0.;
	}
} else {
	a[0] = 1.;
}

/****************/
/* filter kernel*/
/****************/
	fft_ (a, b, &one, &npts, &one, &negone);	/* forward fft */
	for (i = 0; i < npts; i++) {
		freq = (float) i/npts;			/* assume sampling at 1 Hz */
		r_hi = pow((freq/fhalf_hi), 4.);	/* 4 = 2*order */
		r_lo = pow((freq/fhalf_lo), 4.);	/* 4 = 2*order */
		q = (i) ? pow(freq, -beta) : 0.;														
		factor = q*sqrt(1./(1. + r_hi))*sqrt(r_lo/(1. + r_lo));	/* band-pass filtered scale-free */
		a[i] *= factor; b[i] *= factor;
		if (0) printf ("bin=%d freq=%f r_hi=%f factor=%f\n", i, freq, r_hi, factor);
	}
	fft_ (a, b, &one, &npts, &one, &one);		/* inverse fft */
/***************************************/
/* make kernel zero mean unit variance */
/***************************************/
	zero_mean (a, npts);
	unit_var  (a, npts);
	for (v = i = 0; i < npts; i++) v += a[i]*a[i];
	for (i = 0; i < npts; i++) b[i] = 0.;
	fft_ (a, b, &one, &npts, &one, &negone);
/**************/
/* define psd */
/**************/
	for (q = i = 0; i < npts; i++) q += p[i] = a[i]*a[i] + b[i]*b[i];
/**********************************/
/* demonstrate Parseval's theorem */
/**********************************/
	printf ("kernel var = %f fft var = %f\n", v/npts, q/(npts*npts));
	psdsum = q/(npts*npts);

	if (0) for (i = 0; i < npts; i += 2) p[i] = 0.;	/***** debugging code *****/
	if (0) {					/***** debugging code *****/
		for (i = 0; i < npts; i++)   p[i] = 1.;
		p[0] = 0.; p[npts/2] = 0.;
	}
	for (sump = i = 0; i < npts; i++) sump += p[i];
	for (i = 0; i < nROI; i++) Qnorm[i][i] = sqrt(npts/sump);
	printf ("sqrt(npts/sump) = %f\n", Qnorm[0][0]);

/************/
/* define C */
/************/
	for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) T[j][i] = dnormal();
	transpos_ (T[0], Wt[0], &nROI);
	matmul_   (T[0], Wt[0], C[0], &nROI);
	matcop_   (C[0], D[0],  &nROI);
	eigen_    (D[0], W[0],  &nROI);
	transpos_ (W[0], Wt[0], &nROI);
	if (neig) for (i = 0; i < nROI; i++) D[i][i] = eigvals[i]/100.;	/* replace eigenvalues with input values */
	matmul_   (W[0], D[0],  G[0], &nROI);
	matmul_   (G[0], Wt[0], YYt[0], &nROI);
	if (neig) matcop_ (YYt[0], C[0], &nROI);
	if (1) {
		printf ("C\n");			matlst (C,	nROI);
		printf ("W\n");			matlst (W,	nROI);
		printf ("Wt\n");		matlst (Wt,	nROI);
		printf ("D\n");			matlst (D, 	nROI);
		printf ("W*D*Wt\n");		matlst (YYt,	nROI);
	}
 	for (suml = i = 0; i < nROI; i++) suml += D[i][i];

	for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) {
		T[j][i] = (i == j) ? sqrt(D[j][i]) : 0.;	/* T = sqrt(D) */
		SSt[j][i] = ZZt[j][i] = YYt[j][i] = 0.;
	}
	matmul_ (T[0],    Wt[0], G[0], &nROI);			/* G = sqrt(D)*Wt */
	matmul_ (G[0], Qnorm[0], B[0], &nROI);			/* B = sqrt(D)*Wt*Qnorm */
	if (verbose) {
		printf ("T = sqrt(D)\n"); matlst (T, nROI);
		printf ("G = sqrt(D)*Wt\n"); matlst (G, nROI);
	}
	printf ("neig=%d\n", neig);

/**************/
/* populate Z */
/**************/
	for (iter = 0; iter < niter; iter++) {
		if (!(iter % 100)) printf (" %d", iter); else printf ("."); fflush (stdout);
		for (j = 0; j < nROI; j++) {
			for (i = 0; i < npts; i++) {a[i] = dnormal(); b[i] = 0.;}
/****************************************/
/* apply spectral filter defined in psd */
/****************************************/
			fft_ (a, b, &one, &npts, &one, &negone);
			for (i = 0; i < npts; i++) {
				Ztilde[i][j].r = a[i]; Ztilde[i][j].i = b[i];
			}
			for (i = 0; i < npts; i++) {a[i] *= sqrt(p[i]); b[i] *= sqrt(p[i]);}
			fft_ (a, b, &one, &npts, &one, &one);

			for (i = 0; i < npts; i++) S[j][i] = X[j][i] = a[i];
			zero_mean (X[j], npts);
			unit_var  (X[j], npts);
			if (0 & iter < 1) {
				printf ("X/S ROI=%d\n", j) ;
				for (i = 0; i < 16; i++)  printf ("%10.6f", X[j][i]/S[j][i]); printf ("\n");
			}
		}
		zpz_test_ (Ztilde[0], &nROI, &npts, p, ZPZ[0]);

		for (j = 0; j < nROI; j++) for (i = 0; i < npts; i++) Ztildet[j][i] = Ztilde[i][j];
		jmcc_test_ (Ztildet[0], &npts, &nROI, C[0], ZtCZ[0]);

		if (verbose) {
			printf ("Z\n", j);
			for (i = 0; i < npts; i++) {
				for (j = 0; j < nROI; j++) printf ("%10.6f", Z[j][i]);
				printf ("\n");
			}
		}
		for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) {
			for (k = 0; k < npts; k++) XXt[j][i] += X[j][k]*X[i][k];
			for (k = 0; k < npts; k++) ZZt[j][i] += Z[j][k]*Z[i][k];
			for (k = 0; k < npts; k++) SSt[j][i] += S[j][k]*S[i][k];
		}
		for (j = 0; j < nROI; j++) {
			for (k = 0; k < npts; k++) {a[k] = X[j][k]; b[k] = 0.;}
			fft_ (a, b, &one, &npts, &one, &negone);
			for (k = 0; k < npts; k++) PXbar[j][k] += a[k]*a[k] + b[k]*b[k];
		}

		if (!use_Qnorm)	{
/*********************************/
/* Y is normalized by unit_var() */
/*********************************/
			matmulg_ (X[0], &npts, &nROI, G[0], &nROI, Y[0]);
		} else {
/*******************************/
/* Y is normalized using Qnorm */
/*******************************/
			matmulg_ (S[0], &npts, &nROI, B[0], &nROI, Y[0]);
		}

		kurt[iter] = kurtosis_Mardia (Y, nROI, npts);
		for (j = 0; j < nROI; j++) for (i = 0; i < nROI; i++) {
			for (k = 0; k < npts; k++) YYt[j][i] += Y[j][k]*Y[i][k];
		}
		for (j = 0; j < nROI; j++) {
			for (k = 0; k < npts; k++) {a[k] = Y[j][k]; b[k] = 0.;}
			fft_ (a, b, &one, &npts, &one, &negone);
			for (k = 0; k < npts; k++) {
				Ytildet[j][k].r = a[k];
				Ytildet[j][k].i = b[k];
				PYbar[j][k] +=  a[k]*a[k] + b[k]*b[k];
			}
		}
		ytildetytilde_test_ (Ytildet[0], &npts, &nROI, YtildetYtilde[0]);
	}
	printf ("\nniter=%d nROI=%d npts=%d\n", niter, nROI, npts);
	for (j = 0; j < nROI; j++) for (i = 0; i < npts; i++) {
		PXbar[j][i]  /= niter*npts*npts;
		PYbar[j][i]  /= niter*npts*npts;
	}

	strcpy (outfile, "PXbar.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "#original psd and PXbar\n");
	for (i = 0; i < npts; i++) {
		freq = (float) i/npts;			/* assume sampling at 1 Hz */
		fprintf (outfp, "%10.6f", freq); fprintf (outfp, "%10.6f", p[i]/(npts*npts));
		for (j = 0; j < nROI; j++)  fprintf (outfp, "%10.6f", PXbar[j][i]);
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "PYbar.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "#original psd and PYbar\n");
	for (i = 0; i < npts; i++) {
		freq = (float) i/npts;			/* assume sampling at 1 Hz */
		fprintf (outfp, "%10.6f", freq); fprintf (outfp, "%10.6f", p[i]/(npts*npts));
		for (j = 0; j < nROI; j++)  fprintf (outfp, "%10.6f", PYbar[j][i]);
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "XXt.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "E[XXt]/npts (should be I)\n");
	for (i = 0; i < nROI; i++) {
		for (j = 0; j < nROI; j++) fprintf (outfp, "%10.4f", XXt[j][i]/(niter*npts));
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "SSt.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "sump/npts = %f\n", sump/npts);
	fprintf (outfp, "E[SSt]/npts\n");
	for (i = 0; i < nROI; i++) {
		for (j = 0; j < nROI; j++) fprintf (outfp, "%10.4f", SSt[j][i]/(niter*npts));
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "YYt.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "C\n");
	for (i = 0; i < nROI; i++) {
		for (j = 0; j < nROI; j++) fprintf (outfp, "%10.6f", C[j][i]);
		fprintf (outfp, "\n");
	}
	fprintf (outfp, "E[YYt]/npts\n");
	for (i = 0; i < nROI; i++) {
		for (j = 0; j < nROI; j++) fprintf (outfp, "%10.6f", YYt[j][i]/(niter*npts));
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "ZtildePZtildet.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "p");
	for (i = 0; i < npts; i++) fprintf (outfp, "%10.4f", p[i]); fprintf (outfp, "\n");
	fprintf (outfp, "sump/npts=%.6f\n", sump/npts);
	fprintf (outfp, "E[ZtildePZtildet]/npts^2\n");
	for (i = 0; i < nROI; i++) {
		for (j = 0; j < nROI; j++) fprintf (outfp, "%10.4f", ZPZ[j][i].r/(niter*npts*npts));
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "ZtildetCZtilde.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	for (q = i = 0; i < nROI; i++) q += C[i][i];
	fprintf (outfp, "trace(C) = %f\n", q);
	fprintf (outfp, "E[ZtildetCZtilde]/npts\n");
	for (i = 0; i < npts; i++) {
		for (j = 0; j < npts; j++) fprintf (outfp, "%10.4f", ZtCZ[j][i].r/(niter*npts));
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "YtildetYtilde.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "p[i]*suml/sump\n");
	for (i = 0; i < npts; i++) fprintf (outfp, "%10.6f", p[i]*suml/sump); fprintf (outfp, "\n");
	fprintf (outfp, "E[YtildetYtilde]/npts^2\n");
	for (i = 0; i < npts; i++) {
		for (j = 0; j < npts; j++) fprintf (outfp, "%10.6f", YtildetYtilde[j][i].r/(niter*npts*npts));
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "YtildetYtilde_16.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "p[i]*suml/sump\n");
	for (i = 0; i < 16; i++) fprintf (outfp, "%10.6f", p[i]*suml/sump); fprintf (outfp, "\n");
	fprintf (outfp, "E[YtildetYtilde]/npts^2\n");
	for (i = 0; i < 20; i++) {
		for (j = 0; j < 16; j++) fprintf (outfp, "%10.6f", YtildetYtilde[j][i].r/(niter*npts*npts));
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	strcpy (outfile, "kurt.dat");
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	for (iter = 0; iter < niter; iter++) fprintf (outfp, "%10.6f\n", kurt[iter]);
	if (fclose (outfp)) errw (program, outfile);

	if (neig) free (eigvals);
	free_float2 (X); free_float2 (Y); free_float2 (Z); free_float2 (S);
	free_float2 (T); free_float2 (Qnorm); free_float2 (B);
	free_float2 (C); free_float2 (W); free_float2 (Wt);
	free_float2 (G); free_float2 (XXt); free_float2 (YYt); free_float2 (ZZt); free_float2 (SSt);
	free (a); free (b); free (p); free_float2 (PXbar); free_float2 (PYbar);
	free (kurt);
	free_CMPLX2 (Ztilde); free_CMPLX2 (Ztildet); free_CMPLX2 (Ytildet); free_CMPLX2 (YtildetYtilde);
	free_CMPLX2 (ZPZ); free_CMPLX2 (ZtCZ);

	exit (status);
}
