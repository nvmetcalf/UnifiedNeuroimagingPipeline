/*$Header: /data/petsun4/data1/src_solaris/algebra_4dfp/RCS/interp_lag_test.c,v 1.1 2016/06/02 05:40:00 avi Exp $*/
/*$Log: interp_lag_test.c,v $
 * Revision 1.1  2016/06/02  05:40:00  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* R_OK */
#include <string.h>
#include <math.h>
#include <float.h>
#include <librms.h>

#define MAXL		256	/* maximum string length */
#define NROI		2
#define NITER		10
#define TR		0.01	/* default frame TR in sec */


/*************/
/* externals */
/*************/
extern double	dnormal (void);

/********************/
/* global variables */
/********************/
static char	rcsid[] = "$Id: interp_lag_test.c,v 1.1 2016/06/02 05:40:00 avi Exp $";
static char	program[MAXL];
static int	debug = 0;
static int	verbose = 0;

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation error\n", program);
	exit (-1);
}

void errr (char* program, char* filespc) {
	fprintf (stderr, "%s: %s read error\n", program, filespc);
	exit (-1);
}

void errw (char* program, char* filespc) {
	fprintf (stderr, "%s: %s write error\n", program, filespc);
	exit (-1);
}

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm (program);
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

double zero_mean (float *f, int npts) {
	int		i, n;
	double		u;

	for (u = n = i = 0; i < npts; i++) u += f[i];
	u /= npts;
	for (i = 0; i < npts; i++) f[i] -= u;
	return u;
}

double unit_var (float *f, int npts) {
	int		i, n;
	double		v;

	for (v = n = i = 0; i < npts; i++) v += f[i]*f[i];
	v /= npts;
	for (i = 0; i < npts; i++) f[i] /= sqrt (v);
	return v;
}

void matlst (float **C, int k) {
	int		i, j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < k; j++) printf ("%10.6f", C[j][i]);
		printf ("\n");
	}
}

void dmatlst (double **C, int k) {
	int		i, j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < k; j++) printf ("%10.6f", C[j][i]);
		printf ("\n");
	}
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
        int             i;
        fprintf (outfp, "#%s", program);
        for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
        fprintf (outfp, "\n#%s\n", rcsid);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void usage () {
	fprintf (stderr, "Usage:	%s <(int) npts>\n", program);
	fprintf (stderr, "	option\n");
	fprintf (stderr, "	-v	verbose mode\n");
	fprintf (stderr, "	-i<int>	specify srand48 seed (default %d)\n", 0);
	fprintf (stderr, "	-N<int>	specify niter (default %d)\n", NITER);
	fprintf (stderr, "	-t<flt>	specify frame_TR (default %.4f)\n", TR);
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*outfp, *eigfp;
	char		outroot[MAXL], outfile[MAXL], string[MAXL];
	int		nROI = NROI, npts = 1024;
	int		one = 1, negone = -1;
	int		iter, niter = NITER, ncov, itau;
	long		iseed = 0;
	float		**Z;
	float		*a, *b, *p, *cov;
	float		factor, freq, fhalf_lo = 0.01, fhalf_hi = 0.1, r_hi, r_lo, beta = 0.7, tr = TR, lag = 1., t;
	float		a0, a1, a2;		/* parabolic interpolation */

/***********/
/* utility */
/***********/
	int		c, i, j, k, kmax, m;
	char		*ptr, command[MAXL];
	double		q, v;

/*********/
/* flags */
/*********/
	int		status = 0;

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'v': verbose++;			break;
				case 'd': debug++;			break;
				case 'i': iseed = atoi (ptr);		*ptr = '\0';	break;
				case 'm': nROI = atoi (ptr);		*ptr = '\0';	break;
				case 'N': niter = atoi (ptr);		*ptr = '\0';	break;
				case 't': tr = atof (ptr);		*ptr = '\0';	break;
			}
		} else switch (k) {
			case 0: npts = atoi (argv[i]);			k++; break;
		}	
	}
	if (k < 1) usage ();

/**********************/
/* initialize srand48 */
/**********************/
	srand48 (iseed);
	ncov = 20./tr + 1;
	Z	= calloc_float2 (nROI, npts);
	if (!(a		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(b		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(p		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(cov	= calloc (ncov,  sizeof (float))))	errm (program);

/****************/
/* filter kernel*/
/****************/
	a[0] = 1.;
	fft_ (a, b, &one, &npts, &one, &negone);	/* forward fft */
	for (i = 0; i < npts; i++) {
		freq = (float) i/(tr*npts);
		r_hi = pow((freq/fhalf_hi), 4.);	/* 4 = 2*order */
		r_lo = pow((freq/fhalf_lo), 4.);	/* 4 = 2*order */
		q = (i) ? pow(freq, -beta) : 0.;														
		factor = q*sqrt(1./(1. + r_hi))*sqrt(r_lo/(1. + r_lo));	/* band-pass filtered scale-free */
		a[i] *= factor; b[i] *= factor;
		if (0) printf ("bin=%d freq=%f r_hi=%f factor=%f\n", i, freq, r_hi, factor);
	}
	fft_ (a, b, &one, &npts, &one, &one);		/* inverse fft */
/***************************************/
/* make kernel zero mean unit variance */
/***************************************/
	zero_mean (a, npts);
	unit_var  (a, npts);
	for (v = i = 0; i < npts; i++) v += a[i]*a[i];
	for (i = 0; i < npts; i++) b[i] = 0.;
	fft_ (a, b, &one, &npts, &one, &negone);

/**************/
/* define psd */
/**************/
	for (q = i = 0; i < npts; i++) q += p[i] = a[i]*a[i] + b[i]*b[i];
/**********************************/
/* demonstrate Parseval's theorem */
/**********************************/
	printf ("kernel var = %f fft var = %f\n", v/npts, q/(npts*npts));
	sprintf (outfile, "%s_psd.dat", program);
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	for (i = 1; i < npts/2; i++) {
		freq = i/(tr*npts);
		fprintf (outfp, "%10.6f %10.6f\n", freq, p[i]);
	}
	if (fclose (outfp)) errw (program, outfile);

	for (iter = 0; iter < niter; iter++) {
/**************/
/* populate Z */
/**************/
		for (j = 0; j < 1; j++) {
			for (i = 0; i < npts; i++) {a[i] = dnormal(); b[i] = 0.;}
/****************************************/
/* apply spectral filter defined in psd */
/****************************************/
			fft_ (a, b, &one, &npts, &one, &negone);
			for (i = 0; i < npts; i++) {a[i] *= sqrt(p[i]); b[i] *= sqrt(p[i]);}
			fft_ (a, b, &one, &npts, &one, &one);

			for (i = 0; i < npts; i++) Z[j][i] = a[i];
			zero_mean (Z[j], npts);
			unit_var  (Z[j], npts);
		}
		for (i = 0; i < npts; i++) {
			k = i + lag/tr;
			if (k >= npts) k -= npts;
			Z[1][k] = Z[0][i];

		}
		if (!iter) {
			sprintf (outfile, "%s_timeseries.dat", program);
			if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
			fprintf (stdout, "Writing: %s\n", outfile);
			write_command_line (outfp, argc, argv);
			for (i = 0; i < npts; i++) {
				t = i*tr; fprintf (outfp, "%10.6f", t);
				for (j = 0; j < nROI; j++) fprintf (outfp, "%10.6f", Z[j][i]);
				fprintf (outfp, "\n");
			}
			if (fclose (outfp)) errw (program, outfile);
		}
		for (k = 0; k < ncov; k++) for (i = 0; i < npts; i++) {
			itau = k - 10./tr + i;
			if (itau < 0)     itau += npts;
			if (itau >= npts) itau -= npts;
			cov[k] += Z[0][i]*Z[1][itau];
		}
	}
	for (kmax = k = 0; k < ncov; k++) {
		cov[k] /= niter*npts;
		if (cov[k] > cov[kmax]) kmax = k;
	}
	printf ("true time of peak lag = %.4f\n", kmax*tr - 10.);

	sprintf (outfile, "%s_cov.dat", program);
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "#true time of peak lag = %.4f\n", kmax*tr - 10.);
	for (k = 0; k < ncov; k++) {
		t = k*tr - 10.; fprintf (outfp, "%10.6f%10.6f\n", t, cov[k]);
	}
	if (fclose (outfp)) errw (program, outfile);
	sprintf (outfile, "%s_cov_downsample.dat", program);
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	for (j = -4; j <= 4; j++) {
		k = 1000 + j*208;
		t = k*tr - 10.; fprintf (outfp, "%10.6f%10.6f\n", t, cov[k]);
	}
	if (fclose (outfp)) errw (program, outfile);

	a0 = cov[1000];
	a1 = 0.5*(cov[1000 + 208] - cov[1000 - 208]);
	a2 = 0.5*(cov[1000 + 208] + cov[1000 - 208] - 2.*cov[1000]);
	printf ("a0, a1, a2 %10.4f%10.4f%10.4f\n", a0, a1, a2);
	sprintf (outfile, "%s_cov_interp.dat", program);
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "#time of peak lag = %.4f\n", -2.08*0.5*a1/a2);
	for (i = -208; i <= 208; i++) {
		t = i/208.0;
		q = a0 + a1*t + a2*t*t;
		fprintf (outfp, "%10.4f%10.4f\n", t*2.08, q);
	}
	if (fclose (outfp)) errw (program, outfile);
	printf ("interpolated time of peak lag = %.4f\n", -2.08*0.5*a1/a2);

	free_float2 (Z);
	free (a); free (b); free (p); free (cov);

	exit (status);
}
