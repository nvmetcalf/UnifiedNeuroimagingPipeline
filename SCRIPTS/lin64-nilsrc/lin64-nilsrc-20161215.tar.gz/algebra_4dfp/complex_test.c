# include <stdlib.h>
# include <stdio.h>
# include <math.h>
# include <complex.h>
# include <stdlib.h>

void test01 ( );

int main ( ) {
	printf ("COMPLEX_NUMBERS\n" );
	printf ("Demonstrate complex number usage\n" );
	test01 ( );
}

void test01 ( ) {
/***************************************************************/
/* declare complex number a, complex vector b, complex array c */
/***************************************************************/
	complex a, b[3], c[2][2];
	int i, j;

	printf ("TEST01\n");
	a = 1.0 + 2.0 * I;
	b[0] = 1.0 + 2.0 * I;
	b[1] = 3.0 + 4.0 * I;
	b[2] = 5.0 + 6.0 * I;
	c[0][0] = 1.0 + 0.1 * I;
	c[0][1] = 1.0 + 0.2 * I;
	c[1][0] = 2.0 + 0.1 * I;
	c[1][1] = 2.0 + 0.2 * I; 
	printf ("Scalar a:\n" );
	printf ("(%g, %g)\n", creal (a), cimag (a));
	printf ("Vector b:\n" );
	for (i = 0; i < 3; i++ ) {
		printf ("(%g, %g)\n", creal (b[i]), cimag (b[i]));
	}
	printf ("Array c:\n" );
	for (i = 0; i < 2; i++ ) {
		for (j = 0; j < 2; j++ ) {
			printf ("(%g, %g)", creal (c[i][j]), cimag (c[i][j]));
		}
		printf ("\n");
	}
	return;
 }
