/*$Header$*/
/*$Log$*/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* R_OK */
#include <string.h>
#include <math.h>
#include <float.h>
#include <librms.h>

#define MAXL		256	/* maximum string length */
#define TR		0.01	/* default frame TR in sec */
#define TAUMAX		5.0	/* default +/- cov lag in sec */

/*************/
/* externals */
/*************/
extern double	dnormal (void);

/********************/
/* global variables */
/********************/
static char	rcsid[] = "$Id$";
static char	program[MAXL];
static int	debug = 0;
static int	fast = 0;
static int	verbose = 0;

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation error\n", program);
	exit (-1);
}

void errr (char* program, char* filespc) {
	fprintf (stderr, "%s: %s read error\n", program, filespc);
	exit (-1);
}

void errw (char* program, char* filespc) {
	fprintf (stderr, "%s: %s write error\n", program, filespc);
	exit (-1);
}

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm (program);
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

double zero_mean (float *f, int npts) {
	int		i, n;
	double		u;

	for (u = n = i = 0; i < npts; i++) u += f[i];
	u /= npts;
	for (i = 0; i < npts; i++) f[i] -= u;
	return u;
}

double unit_var (float *f, int npts) {
	int		i, n;
	double		v;

	for (v = n = i = 0; i < npts; i++) v += f[i]*f[i];
	v /= npts;
	for (i = 0; i < npts; i++) f[i] /= sqrt (v);
	return v;
}

void matlst (float **C, int k) {
	int		i, j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < k; j++) printf ("%10.6f", C[j][i]);
		printf ("\n");
	}
}

void dmatlst (double **C, int k) {
	int		i, j;
	for (i = 0; i < k; i++) {
		for (j = 0; j < k; j++) printf ("%10.6f", C[j][i]);
		printf ("\n");
	}
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
        int             i;
        fprintf (outfp, "#%s", program);
        for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
        fprintf (outfp, "\n#%s\n", rcsid);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

void usage () {
	fprintf (stderr, "Usage:	%s <(int) npts>\n", program);
	fprintf (stderr, "	option\n");
	fprintf (stderr, "	-v	verbose mode\n");
	fprintf (stderr, "	-i<int>	specify srand48 seed (default %d)\n", 0);
	fprintf (stderr, "	-o<str>	append quantitative output to named file\n");
	fprintf (stderr, "	-t<flt>	specify frame_TR (default %.4f)\n", TR);
	fprintf (stderr, "	-T<flt>	specify taumax (default %.2f)\n", TAUMAX);
	fprintf (stderr, "	-p[1|2]=<flt>	specify angle of noise/signal (default 0)\n");
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*outfp, *eigfp;
	char		outroot[MAXL], outfile[MAXL], qntfile[MAXL] = "", string[MAXL];
	int		npts = 1024;
	int		one = 1, negone = -1;
	int		ncov, itau = 0;
	long		iseed = 0;
	float		**Z, **F;
	float		*a, *b, *p, *cov;
	float		taumax = TAUMAX;
	float		factor, freq, fhalf_lo = 0.01, fhalf_hi = 0.1, r_hi, r_lo, beta = 0.7, tr = TR, t;
	float		c1, c2, c3, c4, phi1 = 0., phi2 = 0.;

/***********/
/* utility */
/***********/
	int		c, i, j, k, kmax, m;
	char		*ptr, command[MAXL];
	double		q, v;

/*********/
/* flags */
/*********/
	int		status = 0;

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'v': verbose++;				break;
				case 'd': debug++;				break;
				case 'f': fast++;				break;
				case 'o': strncpy (qntfile, ptr, MAXL - 1);	*ptr = '\0';	break;
				case 'i': iseed = atoi (ptr);			*ptr = '\0';	break;
				case 't': tr = atof (ptr);			*ptr = '\0';	break;
				case 'T': taumax = atof (ptr);			*ptr = '\0';	break;
				case 'p': c = *ptr++;
					if (debug) printf ("c=%c\n", c);
					switch (c) {
						case '1': phi1 = atof (++ptr); break;
						case '2': phi2 = atof (++ptr); break;
					}					*ptr = '\0';	break;
			}
		} else switch (k) {
			case 0: npts = atoi (argv[i]);			k++; break;
		}	
	}
	if (k < 1) usage ();

/****************************/
/* define process constants */
/****************************/
	c1 = sin(2.*M_PI*phi1); c3 = cos(2.*M_PI*phi1); c2 = sin(2.*M_PI*phi2); c4 = cos(2.*M_PI*phi2);
	if (debug) printf ("phi1=%f phi2=%f c1=%f c2=%f c3=%f c4=%f\n", phi1, phi2, c1, c2, c3, c4);

/**********************/
/* initialize srand48 */
/**********************/
	srand48 (iseed);
	ncov = (int) (2.*taumax/tr +.0001) + 1;
	if (debug) printf ("ncov=%d\n", ncov);
	Z	= calloc_float2 (3, npts);
	F	= calloc_float2 (2, npts);
	if (!(a		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(b		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(p		= calloc (npts,  sizeof (float))))	errm (program);
	if (!(cov	= calloc (ncov,  sizeof (float))))	errm (program);

/****************/
/* filter kernel*/
/****************/
	a[0] = 1.;
	fft_ (a, b, &one, &npts, &one, &negone);	/* forward fft */
	for (i = 0; i < npts; i++) {
		freq = (float) i/(tr*npts);
		r_hi = pow((freq/fhalf_hi), 4.);	/* 4 = 2*order */
		r_lo = pow((freq/fhalf_lo), 4.);	/* 4 = 2*order */
		q = (i) ? pow(freq, -beta) : 0.;														
		factor = q*sqrt(1./(1. + r_hi))*sqrt(r_lo/(1. + r_lo));	/* band-pass filtered scale-free */
		a[i] *= factor; b[i] *= factor;
		if (0) printf ("bin=%d freq=%f r_hi=%f factor=%f\n", i, freq, r_hi, factor);
	}
	fft_ (a, b, &one, &npts, &one, &one);		/* inverse fft */
/***************************************/
/* make kernel zero mean unit variance */
/***************************************/
	zero_mean (a, npts);
	unit_var  (a, npts);
	for (i = 0; i < npts; i++) b[i] = 0.;
	fft_ (a, b, &one, &npts, &one, &negone);
/**************/
/* define psd */
/**************/
	for (q = i = 0; i < npts; i++) q += p[i] = a[i]*a[i] + b[i]*b[i];

/**************/
/* populate Z */
/**************/
	for (j = 0; j < 3; j++) {
		for (i = 0; i < npts; i++) {a[i] = dnormal(); b[i] = 0.;}
/****************************************/
/* apply spectral filter defined in psd */
/****************************************/
		fft_ (a, b, &one, &npts, &one, &negone);
		for (i = 0; i < npts; i++) {a[i] *= sqrt(p[i]); b[i] *= sqrt(p[i]);}
		fft_ (a, b, &one, &npts, &one, &one);

		for (i = 0; i < npts; i++) Z[j][i] = a[i];
		zero_mean (Z[j], npts);
		unit_var  (Z[j], npts);
	}
/**************/
/* populate F */
/**************/
	for (i = 0; i < npts; i++) {
		F[0][i] = c1*Z[1][i] + c3*Z[0][i];
		F[1][i] = c2*Z[2][i] + c4*Z[0][i];
	}

/**********************/
/* compute covariance */
/**********************/
	for (k = 0; k < ncov; k++) for (i = 0; i < npts; i++) {
		itau = k - taumax/tr + i;
		if (itau >= 0 && itau < npts) cov[k] += F[0][i]*F[1][itau];
	}
	for (kmax = k = 0; k < ncov; k++) {
		cov[k] /= npts;
		if (cov[k] > cov[kmax]) kmax = k;
	}
	printf ("time of peak lag = %.4f cov at peak = %.4f rho = %.4f\n", kmax*tr - taumax, cov[kmax], c3*c4);
	if (strlen (qntfile)) {
		if (!(outfp = fopen (qntfile, "a"))) errw (program, qntfile);
		fprintf (outfp, "%10.4f%10.4f%10.4f\n", kmax*tr - taumax, cov[kmax], c3*c4);
		if (fclose (outfp)) errw (program, outfile);
	}
	if (fast) goto DONE;

	sprintf (outfile, "%s_timeseries.dat", program);
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	for (i = 0; i < npts; i++) {
		t = i*tr; fprintf (outfp, "%10.6f", t);
		for (j = 0; j < 2; j++) fprintf (outfp, "%10.6f", F[j][i]);
		fprintf (outfp, "\n");
	}
	if (fclose (outfp)) errw (program, outfile);

	sprintf (outfile, "%s_cov.dat", program);
	if (!(outfp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (stdout, "Writing: %s\n", outfile);
	write_command_line (outfp, argc, argv);
	fprintf (outfp, "#true time of peak lag = %.4f\n", kmax*tr - taumax);
	for (k = 0; k < ncov; k++) {
		t = k*tr - taumax; fprintf (outfp, "%10.6f%10.6f\n", t, cov[k]);
	}
	if (fclose (outfp)) errw (program, outfile);

DONE:	free_float2 (Z); free_float2 (F);
	free (a); free (b); free (p); free (cov);
	exit (status);
}
