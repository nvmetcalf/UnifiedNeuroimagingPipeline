/*$Header: /data/petsun4/data1/src_solaris/maskimg_4dfp/RCS/mask_cubes_4dfp.c,v 1.2 2015/12/12 05:36:28 avi Exp $*/
/*$Log: mask_cubes_4dfp.c,v $
 * Revision 1.2  2015/12/12  05:36:28  avi
 * install check jndex < dimension
 *
 * Revision 1.1  2013/06/08  04:15:22  avi
 * Initial revision
 **/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <unistd.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>

#define MAXL  256
#define LCUBE 2

static char rcsid[]= "$Id: mask_cubes_4dfp.c,v 1.2 2015/12/12 05:36:28 avi Exp $";
int main (int argc, char *argv[]) {
/*************/
/* image I/O */
/*************/
	FILE            *imgfp;
	IFH		ifh;		/* only for first input image = mask */
	char            imgroot[2][MAXL], imgfile[2][MAXL];

/**************/
/* processing */
/**************/
	int             imgdim[2][4], isbig, dimension, orient;
	int		i0, j0, k0, ii, jj, kk, jndex, nvox, ROI, lcube = LCUBE;
	float           voxdim[3];
	float           *imgt[2];
	char		control = '\0';

/***********/
/* utility */
/***********/
	char            *ptr, command[MAXL], program[MAXL];
	int             c, i, j, k;

/*********/
/* flags */
/*********/
	int             debug = 0;
	int             status = 0;
	int		tflag = 0;

	fprintf (stdout, "%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

/************************/
/* process command line */
/************************/
	for (j = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'd': debug++;			break;
				case 'l': lcube = atoi (ptr);		*ptr = '\0'; break;
				case '@': control = *ptr++;		*ptr = '\0'; break;
			}
		} else {
                	if (j < 2) getroot (argv[i], imgroot[j++]);
		}
	}
	if (j < 2) {
		printf ("Usage:\t%s <(4dfp) mask> <(4dfp) outroot>\n", program);
        	printf (" e.g.:\t%s N33_fdg_333_0.9mask GM_cubes_333\n", program);
        	printf ("\toption\n");
        	printf ("\t-l<int>\tspecify cube dimension in voxels (default = %d)\n", lcube);
		printf ("\t-@<b|l>\toutput big or little endian (default <imgfile> endian)\n");
		exit (1);
	}

/*****************************/
/* get input 4dfp dimensions */
/*****************************/
	for (j = 0; j < 2; j++) {
		sprintf (imgfile[j], "%s.4dfp.img", imgroot[j]);
	}
	if (Getifh (imgfile[0], &ifh)) errr (program, imgroot[0]);
	if (get_4dfp_dimoe (imgfile[0], imgdim[0], voxdim, &orient, &isbig) < 0) errr (program, imgfile[0]);

/********************************/
/* alloc buffers and open files */
/********************************/
	dimension = imgdim[0][0]*imgdim[0][1]*imgdim[0][2];
	for (j = 0; j < 2; j++) {
		if (!(imgt[j] = (float *) calloc (dimension, sizeof (float)))) errm (program);
	}
	if (!(imgfp = fopen (imgfile[0], "rb"))) errr (program, imgfile[0]);
	fprintf (stdout, "Reading: %s\n", imgfile[0]);
	if (eread (imgt[0], dimension, isbig, imgfp)) errr (program, imgfile[0]);
	fclose (imgfp);
	if (!control) control = (isbig) ? 'b' : 'l';

/***********/
/* process */
/***********/
	ROI = 0;
	i0 = (imgdim[0][0]/2) % lcube;
	j0 = (imgdim[0][1]/2) % lcube;
	k0 = (imgdim[0][2]/2) % lcube;
	for (k = k0; k < imgdim[0][2]; k += lcube) {
	for (j = j0; j < imgdim[0][1]; j += lcube) {
	for (i = i0; i < imgdim[0][0]; i += lcube) {
		nvox = 0;
		for (kk = 0; kk < lcube; kk++) {
		for (jj = 0; jj < lcube; jj++) {
		for (ii = 0; ii < lcube; ii++) {
			jndex = (i + ii) + imgdim[0][0]*((j + jj) + imgdim[0][1]*(k + kk));
			if (jndex >= dimension) continue;
			if (imgt[0][jndex] != 0. && imgt[0][jndex] != (float) 1.e-37) nvox++;
		}}}
		if (2*nvox < lcube*lcube*lcube) continue;
		for (kk = 0; kk < lcube; kk++) {
		for (jj = 0; jj < lcube; jj++) {
		for (ii = 0; ii < lcube; ii++) {
			jndex = (i + ii) + imgdim[0][0]*((j + jj) + imgdim[0][1]*(k + kk));
			if (jndex >= dimension) continue;
			if (imgt[0][jndex] != 0. && imgt[0][jndex] != (float) 1.e-37) imgt[1][jndex] = ROI + 2;
		}}}
		ROI++;
	}}}

/****************/
/* write output */
/****************/
	if (!(imgfp = fopen (imgfile[1], "wb"))) errw (program, imgfile[1]);
	fprintf (stdout, "Writing: %s\n", imgfile[1]);
	if (ewrite (imgt[1], dimension, control, imgfp)) errw (program, imgfile[1]);
	fclose (imgfp);

/*******************/
/* create rec file */
/*******************/
	startrece (imgfile[1], argc, argv, rcsid, control);
	sprintf (command, "Cube dimensions = %d voxels\n", lcube);	printrec (command);
	sprintf (command, "ROI count = %d\n", ROI);			printrec (command);
	catrec (imgfile[0]);
	endrec ();

/*******/
/* ifh */
/*******/
	if (Writeifh (program, imgroot[1], &ifh, control)) errw (program, imgroot[1]);

/*******/
/* hdr */
/*******/
	sprintf (command, "ifh2hdr %s -r%d", imgroot[1], ROI);
	printf ("%s\n", command);
	status |= system (command);

	free (imgt[0]); free (imgt[1]);
	exit (status);
}
