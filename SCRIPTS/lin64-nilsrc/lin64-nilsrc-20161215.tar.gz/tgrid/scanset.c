/*$Header: /home/usr/shimonyj/tgrid/RCS/scanset.c,v 1.1 2006/03/31 07:27:11 avi Exp $*/
/*$Log: scanset.c,v $
 * Revision 1.1  2006/03/31  07:27:11  avi
 * Initial revision
 **/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
	int	seq;
	int	val;
} SE;

static int secompare (const void *i, const void *j) {
	SE  *pi, *pj;
	pi = (SE *) i; pj = (SE *) j;
	return (pi->val - pj->val);
}

void scanset (int *seq, int nseq) {
	SE		*list;
	int		k;

	if (!(list = (SE *) malloc (nseq * sizeof (SE)))) errm ("scanset");
	for (k = 0; k < nseq; k++) {
		list [k].seq = k;
		list [k].val = random ();
	}
	fprintf (stdout, "call qsort...");  fflush (stdout);
	qsort ((void *) list, nseq, sizeof (SE), secompare);
	printf ("done\n");

	for (k = 0; k < nseq; k++) seq [k] = list [k].seq;
	free (list);
}


/* main (int argc, char *argv[]) { */
void scanset_test () {
	int	i, seq[100];

	scanset (seq, 100);
	for (i = 0; i < 100; i++) printf ("%10d%10d\n", i, seq[i]);
	exit (0);
}
