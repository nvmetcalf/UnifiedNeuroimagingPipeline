/*$Header: /home/usr/shimonyj/tgrid/RCS/get_radius.c,v 1.1 2005/11/03 06:21:48 adrian Exp $*/
/*$Log: get_radius.c,v $
 * Revision 1.1  2005/11/03  06:21:48  adrian
 * Initial revision
 **/
#include <stdio.h>
#include <math.h>
#include <unistd.h>
#include <string.h>

void	dcross (double *a, double *b, double *c) {
	c[0]= a[1]*b[2]-a[2]*b[1];
	c[1]=-a[0]*b[2]+a[2]*b[0];
	c[2]= a[0]*b[1]-a[1]*b[0];
}

double	ddot (double *a, double *b) {
	return a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
}

double	radius_of_curvature (float x1[3], float x2[3], float x3[3]) {
	double	a[3][3], ainv[3][2], det, d11, d22, r[3];
	int	i;

	for (i = 0; i < 3; i++) {
		a[0][i] = x2[i] - x1[i];
		a[1][i] = x3[i] - x2[i];
	}
	d11 = ddot (a[0], a[0]);
	d22 = ddot (a[1], a[1]);
	dcross (a[0], a[1], a[2]);
	for (i = 0; i < 3; i++) a[2][i] /= (d11*d22);	/* bring det closer to 1 */

	det = a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])
	     +a[0][1]*(a[1][2]*a[2][0]-a[1][0]*a[2][2])
	     +a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0]);
	ainv[0][0]= (a[1][1]*a[2][2]-a[2][1]*a[1][2])/det;
	ainv[0][1]=-(a[0][1]*a[2][2]-a[2][1]*a[0][2])/det;
	ainv[1][0]=-(a[1][0]*a[2][2]-a[2][0]*a[1][2])/det;
	ainv[1][1]= (a[0][0]*a[2][2]-a[2][0]*a[0][2])/det;
	ainv[2][0]= (a[1][0]*a[2][1]-a[1][1]*a[2][0])/det;
	ainv[2][1]=-(a[0][0]*a[2][1]-a[2][0]*a[0][1])/det;

	for (i = 0; i < 3; i++) r[i] = 0.5*(-ainv[i][0]*d11 + ainv[i][1]*d22);
	return sqrt (ddot (r,r));
}

radius_of_curvature_test (int argc, char *argv[]) {
/* main (int argc, char *argv[]) { */
	float	theta, pi;
	float	x[3][3];
	int	i;
	double	radius;

	pi = 4.*atan(1.);
	theta = pi/4.;
	printf ("input points\n");
	for (i = 0; i < 3; i++) {
		x[i][0] = cos (i*theta);
		x[i][1] = sin (i*theta);
		x[i][2] = 0.0;
		printf ("%10.6f%10.6f%10.6f\n", x[i][0], x[i][1], x[i][2]);
	}

	radius = radius_of_curvature (x[0], x[1], x[2]);
	printf ("computed radius %10.6f\n", radius);
}
