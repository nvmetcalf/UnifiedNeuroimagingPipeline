/*Id: tracker3.c,v 1.1 2004/06/09 21:53:09 adrian Exp adrian $*/
/*$Log: tracker5.c,v $
 * Revision 1.9  2009/03/09  23:28:52  shimonyj
 * corrected errd
 * adrian partial conversion using t4tolin bypassed and saved in tracker5.c.adrian
 *
 * Revision 1.8  2008/06/06  18:55:55  adrian
 * 8 volume tensor volume input
 *
 * Revision 1.7  2008/05/23  04:14:09  adrian
 * added stop criteria for angle between user defined number of beads
 *
 * Revision 1.6  2007/09/17  05:04:39  avi
 * last argument to interpolate() has to recognize that it is assumed allocated by nrutil
 *
 * Revision 1.5  2007/08/30  06:51:48  avi
 * supply all prototypes; correct BEAD gwrite
 *
 * Revision 1.4  2007/08/30  04:00:33  adrian
 * solaris and linux endian compliant
 *
 * Revision 1.3  2007/08/29  04:57:52  avi
 * updated i/o and partial (4dfp) endian compliance
 * eliminate debug code and improve cide appearance
 *
 * Revision 1.2  2007/08/28  04:25:30  avi
 * free of -lnrc and -lrms
 *
 * Revision 1.1  2007/08/26  03:15:55  adrian
 * Initial revision
 *
 * Revision 1.4  2006/01/18  04:39:17  adrian
 * read in Behrens-like tensor files for probablistic tracking
 *
 * Revision 1.3  2005/11/25  20:25:57  adrian
 * added radius of curvature limit
 *
 * Revision 1.2  2005/11/03  06:06:20  adrian
 * corrected for single voxel computation and optional .trk file output suppression
 *
 * Revision 1.1  2005/07/19  03:36:48  adrian
 * Initial revision
 *
 * Revision 1.4  2005/07/18  15:22:56  adrian
 * revised data output to save visitation grid in same space as input image
 *
 * Revision 1.3  2004/08/17  18:54:33  adrian
 * added RAVE and PICo tracking algorithms
 * revised data input to accept or save diffusion tensor interpolation
 *
 * Revision 1.2  2004/07/12  16:12:50  adrian
 * added TEND algorithm as a subroutine
 *
 * Revision 1.1  2004/06/09  21:53:09  adrian
 * Initial revision
 *
 * Revision 1.12  2004/02/19  06:25:17  avi
 * redo clock/time related code
 *
 * Revision 1.11  2004/02/18  04:33:53  avi
 * -I: option (set I0 trackability threshold)
 *
 * Revision 1.10  2004/02/10  03:06:54  avi
 * put big included rec files always at end of output recfile
 * limit brec depth to 2
 *
 * Revision 1.9  2004/02/10  02:21:17  avi
 * correct track_num logic so that final track count is not too great by 1
 *
 * Revision 1.8  2004/02/06  02:21:04  avi
 * add Dbar trackability limit
 *
 * Revision 1.7  2004/02/04  02:52:30  avi
 * errd ()
 * better prototyping
 *
 * Revision 1.6  2004/01/20  23:48:00  avi
 * improved interpolation method usage and rec file
 *
 * Revision 1.5  2004/01/20  21:24:25  avi
 * working interpolation in tensor space
 * in arm output swap e_prin and e_vals indices
 *
 * Revision 1.4  2004/01/20  01:43:32  avi
 * consolidate image reading and spline computation
 *
 * Revision 1.3  2004/01/19  23:46:40  avi
 * cleaned in preparation for alternate interpolation scheme
 *
 * Revision 1.2  2004/01/18  06:25:03  avi
 * code simplification
 * use most recent spline module
 *
 * Revision 1.1  2004/01/16  00:01:28  avi
 * Initial revision
 *
 * Revision 1.2  2003/12/06  02:44:35  avi
 * allow any number of axes to be controlled with the -f option
 *
 * Revision 1.1  2003/12/06  02:20:21  avi
 * Initial revision
 *
 * Revision 2.23  1999/10/05  00:11:39  avi
 * correct memory initialization for linear interpolation mode
 *
 * Revision 2.22  1999/08/25  00:46:44  avi
 * recompile with updated Getifh.c and get_tp7_images.c
 *
 * Revision 2.21  1999/08/24  03:17:50  avi
 * correct computation of x0[k] = x[k] immediately above The Tracking Algorithm
 * taking x_start[k] out of parentheses muliplying *del
 *
 * Revision 2.20  1998/07/13  16:42:01  tscull
 * improve usage of seedmask
 *
 * Revision 2.19  1998/07/10  02:02:55  tscull
 * better counter using seconds from 1970
 * problem with yr 2000 :)
 *
 * Revision 2.18  1998/06/23  21:52:25  tscull
 * installed clock function and est. time of completion
 *
 * Revision 2.17  1998/06/18  22:48:32  tscull
 * percent complete output added
 * glmin = 0
 *
 * Revision 2.16  1998/06/09  19:40:34  tscull
 * seed index output
 * time accumulation output
 *
 * Revision 2.15  1998/06/03  02:05:04  avi
 * random seed point algorithm
 *
 * Revision 2.14  1998/05/28  22:32:00  tscull
 * removed test_grid tracks now consider visit threshhold
 * as a reverse condition and are written out to trk file
 * instead of being removed
 *
 * Revision 2.13  1998/05/28  20:51:52  tscull
 * flag names changed for clarity
 *
 * Revision 2.12  1998/05/24  23:43:13  avi
 * NOUTS 6->8 (two lower eigenvetors)
 *
 * Revision 2.11  1998/05/22  19:29:54  tscull
 * grid hdr is always short int datatype 4 databits 16
 *
 * Revision 2.10  1998/05/22  00:49:30  tscull
 * usage cleaned up
 *
 * Revision 2.9  1998/05/22  00:32:00  tscull
 * n_limit_hits, v_limit_hits, -q:#
 * print out at summary not as debug
 *
 * Revision 2.8  1998/05/16  01:41:32  avi
 * check for numerical stability in l_squares_min2 ()
 *
 * Revision 2.7  1998/05/15  21:52:18  tscull
 * added angles and shapes to arm
 *
 * Revision 2.6  1998/05/15  09:46:55  avi
 * new usage
 *
 * Revision 2.5  1998/05/14  08:52:48  avi
 * new Inithdr for writing grid image
 *
 * Revision 2.4  1998/05/14  04:13:28  avi
 * does not core dump with 4dfp input but
 * jacobi still exits with cubic spline interpolation
 *
 * Revision 2.3  1998/05/13  21:55:56  tscull
 * Revision 2.2  1998/05/13  19:36:50  tscull
 * removed nint function
 * declared pointers instead of arrays.
 * tracked to completion where before it crashed in tracking.
 *
 * Revision 2.1  1998/05/13  18:05:52  tscull
 * Revision 1.6  1998/05/11  08:36:35  avi
 * some cleaning
 *
 * Revision 1.5  1998/05/09  04:33:46  avi
 * declare imgdim[4] (not 3) and similarly for seed_sim
 *
 * Revision 1.3  1998/05/08  22:10:19  tscull
 * Revision 1.2  1998/05/08  22:09:11  tscull
 * fixed forgotten alloc of *params
 *
 * Revision 1.1  1998/05/01  22:06:27  tscull
 * Initial revision
 **/
/*******************************************/
/* step by step tracker using eigenvectors */
/* Tom Cull & AZS Apr 98                   */
/*******************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <float.h>
#include <math.h>
#include <endianio.h>
#include <Getifh.h>
#include <spline23dvgh.h>
#include <rec.h>
#include <JSSutil.h>
#include <sys/types.h>
#include <time.h>
#include <assert.h>

#define MAXL		256
#define MASK_CRIT	0
#define NOUTS		8
#define NKTRK		512
#define DbarMAX		1.5		/* Dbar trackability limit */
#define I0THRESH	0.0		/* I0 intensity trackability threshold */
#define MONTECARLO	100	
#define MINRADCURV 	0.3
#define MAXROIS		64 		/*max number of possible ROIs in end_img */
#define MAXAngtest 	25
#define NSTEPSTEST 	1

typedef struct {
 	int	id;
	float	x;
	float	y;
	float	z;
} BEAD;

typedef struct {
        float	ang[4];
	int 	imaj; /* index of major eigenvector */
        float	Dbar;
        float	Asig;
	float 	FA;
        float	Anu;
        float	prolat;
        float	eta;
        float	eps;
        float	Amaj;
        float	Amin;
} D_PARAMS_2;

void usage (char *program) {
	fprintf (stderr, "Usage:\t%s <prm_file> <input_root> <output_root>\n", program);
	fprintf (stderr, "\toption\n");
	fprintf (stderr, "\t-m:<interpolation method>\n");
	fprintf (stderr, "\t\t0 none; 2 cubic spline (CS) in image space; 4 CS in tensor space;\n");
	fprintf (stderr, "\t\tadd 1 to convert CS -> linear [default method 2]\n");
	fprintf (stderr, "\t-seedspace:<seed point grid spacing (mm)> [default 1.0]\n");
	fprintf (stderr, "\t-f<x|y|z>\tflip principal eigenvector components [default flips (+1, +1, -1)]\n");
	fprintf (stderr, "\t-step:<step size (mm)> [default 0.5]\n");
	fprintf (stderr, "\t-Track:< TEND,f,g> | RAVE[,alpha] | PICo | BICo > \t Choose tracking Algorithm (default: Euler)\n");
	fprintf (stderr, "\t\tTEND: \tTensor Deflection algorithm \n");
	fprintf (stderr, "\t\t\twith f (Streamlined Tracking) and g (Tensor Deflection) weighting\n");
	fprintf (stderr, "\t\tRAVE: \tRandom Vector Perterbation, alpha: largest eigenvector to random vector proportionality\n");
	fprintf (stderr, "\t\tPICo: \tParker Probabilistic Index of Connectivity\n"); 
	fprintf (stderr, "\t\tBICo: \tBehrens-like Probabilistic Index of Connectivity\n");
	fprintf (stderr, "\t-MC:<int> user specified number of MonteCarlo-like simulations for probablistic tracking (default %d)\n", MONTECARLO); 
	fprintf (stderr, "\t-D\t input file is 8 volume D tensor file (ADC, RA, xx, yy, zz, xy, xz, yz)\n");
	fprintf (stderr, "\t-r\tuse Runge-Kutta integration\n");
	fprintf (stderr, "\t-seedmask:<seedmask_file> use specified short int seedmask\n");
	fprintf (stderr, "\t-ROIs:<endmask_file> use specified short int ROI file to label seeds (Behrens)\n"); 
	fprintf (stderr, "\t-a:<critical_value>\tuse Asigma (default: .13)\n");
	fprintf (stderr, "\t-FA:<critical_value>\tuse Fractional Anisotopy threshold (instead of Asigma) (default: .2)\n");
	fprintf (stderr, "\t-D:<critical_value>\tspecify Dbar trackability cutoff [default %.4f]\n", DbarMAX);
	fprintf (stderr, "\t-I:<threshold>\tspecify I0 intensity trackability threshold [default %.1f]\n", I0THRESH);
	fprintf (stderr, "\t-ROC:<flt>\tspecify radius of curvature limit (mm) [default %.4f]\n", MINRADCURV);
	fprintf (stderr, "\t-nsteps:<int>\tspecify bead spacing to test ROC or Angle threshold [default %d]\n",NSTEPSTEST);
	fprintf (stderr, "\t-Ang:<flt>\tangle threshold cutoff between steps, and to force angle between track beads (using BICo) within threshold\n");
	fprintf (stderr, "\t-t\tsuppress output of all non trk spaghetti\n");
	fprintf (stderr, "\t-T\tsuppress output of trk file and diffusion parameters\n");
	fprintf (stderr, "\t-v\tverbose mode\n");
	fprintf (stderr, "\t-lDtensor:<filename[.Dtensor]> load a diffusion tensor interpolation file\n");
	fprintf (stderr, "\t-sDtensor:<filename[.Dtensor]> save the diffusion tensor interpolation to file\n");
	fprintf (stderr, "\t-@<b|l> output big or little endian images (default input endian)\n");
	fprintf (stderr, "N.B.:\tonly one ':' option per field allowed\n");
	exit (1);
}

static void getrootl (char *filespc, char *imgroot) {
	char	*str;
	strcpy (imgroot, filespc);
	while (str = strrchr (imgroot, '.')) {
			if (!strcmp (str, ".rec"))	*str = '\0';
		else	if (!strcmp (str, ".img"))	*str = '\0';
		else	if (!strcmp (str, ".ifh"))	*str = '\0';
		else	if (!strcmp (str, ".4dfp"))	*str = '\0';
		else	if (!strcmp (str, ".hdr"))	*str = '\0';
		else 	if (!strcmp (str, ".Dtensor")) 	*str = '\0';
		else	break;
	}
}

void errd (char* program, char* file1, char* file2) {
	fprintf (stderr, "%s: %s %s dimension mismatch\n", program, file1, file2);
	exit (-1);
}
extern void		flipx (float *imag, int *nx, int *ny, int *nz);		/* cflip.c */
extern void		flipy (float *imag, int *nx, int *ny, int *nz);		/* cflip.c */
extern void		flipz (float *imag, int *nx, int *ny, int *nz);		/* cflip.c */
extern int		dti_dimen (char *file);										/* get_dti_params.c */
extern int		get_dti_params_nrc (char *file, int n, float *b_vals, float **q_vals);				/* get_dti_params.c */
extern void dparam_calc_noswap (float *dvec, float **dinv, float *eigenval, float **eigenvec, D_PARAMS_2 *dparam);	/* dtensor.c */
extern int Inithdr	(struct dsr *phdr, int *imgdim, float *voxdim, char *proto_imgfile);				/* Inithdr.c */
extern void		scanset (int *seq, int nseq);									/* scanset.c */
extern int		TEND (float *Vin, float f, float g, int imaj, float **eigenvec, float *eigenval, float *Vout); 	/* tend.c */
extern int 		RAVE (float *Vin, float alpha, int imaj, float **eigenvec, float *eigenval, float *Vout); 	/* tend.c */
extern int 		BICo (float *Vin, float stdTheta, float stdPhi, int imaj, float **eigenvec, float *eigenval, float *Vout); /*tend.c*/
extern int 		PICo (float *Vin, float A, int imaj, float **eigenvec, float *eigenval, float *Vout); 		/* tend.c */
extern double 		radius_of_curvature (float x1[3], float x2[3], float x3[3]);	/* get_radius.c */

/*********/
/* below */
/*********/
int interpolate		(int interp_flag, int n, float *fimg, int nvox, float *aix, int *imgdim, float *img_vals);
void spline3d		(float *fimg, int *imgdim, int nvol);
int match_dir 		(int track_flag, float **eigenvec1, float **eigenvec);
int load_bayes_tensor 	(float *fimg, int nvox, int j, float *dimg );

static char rcsid[] = "$Id: tracker5.c,v 1.9 2009/03/09 23:28:52 shimonyj Exp $";
int main (int argc, char *argv[]) {
/*******/
/* i/o */
/*******/
	FILE		*fp_rec, *fp_out[NOUTS], *fp_grid, *fp_hdr, *fp_seed, *fp_Dtensor, *fp_end;
	FILE		*fp_time, *fp;
	BEAD		arm[NKTRK][NOUTS];
	int		nouts = NOUTS;
	struct dsr	hdr;
	static char	*outs[NOUTS] = {"trk", "e_prin", "e_vals", "moments", "ang", "shape", "e_vec1", "e_vec2"};
	char		input_root[MAXL], output_root[MAXL];
	char		Dtensor_root[MAXL], Dtensor_file[MAXL];
	char		input_file[MAXL], output_file[MAXL], seed_root[MAXL], seed_file[MAXL], end_file[MAXL], end_root[MAXL]; 
	char		*ptr, cmd[MAXL], program[MAXL];
	char 		recfile[MAXL], imgfile[MAXL];
	char		prmfile[MAXL];

/****************/
/* image arrays */
/****************/
	char		*timg;		/* trackability based on I0thresh */
	IFH		ifh;		/* ifh of input dwi image */
	float		*fptr, *fimg;
	float		voxsiz[3];
	int		imgdim[4], orient, isbig, nvox;
	char		control = '\0';
	char		control_trk = 'b';
	int		ix[3];
	
/*************************/
/* diffusion calculation */
/*************************/
	float		*ival, *bval, *ang, *dvec, *eigenval, *img_vals;
	float		**qval, **eigenvec, **eigenvec1, **eigenvec0, **dinv, **exp_arr;
	float		*dimg, *stdTimg, *stdPimg, stdTheta, stdPhi;		/* for interpolating in tensor space, and the error images if needed */
	D_PARAMS_2	dparam, dparam0;

/******************************/
/* Numerical Recipies testing */
/******************************/
	float		jacobi_err = 0.;
	int		njac = 0;

/*********/
/* flags */
/*********/
	int		interp_flag = 2;
	int		rk_flag = 0;
	int		verbose = 0;
	int 		debug = 0;
	int 		use_TEND = 0;
	int		use_RAVE = 0;
	int 		use_PICo = 0;
	int 		use_BICo = 0;
	int 		use_FA = 0;
	int		save_Dtensor = 0, load_Dtensor = 0;
	int 		swab_flag = 0;
	int             tensor_data = 0;
	int problem = 0;

/************/
/* tracking */
/************/
	char		datestring[MAXL];
	float		x[3], x0[3], aix[3], bix[3];
	float		Vin[3], Vout[3], e_principal0[3], e_principal1[3];
	float 		x1[3], x2[3], x3[3]; 		/* presently needed for ROC test */
	float 		rcurv, minradcurv = MINRADCURV;
	float		k2[3], k3[3], k4[3];		/* for Runge-Kutta */
	float		pflip[3] = {1., 1., -1.};	/* principal eigenvector flips */
	float		del = 1.0;			/* starting point separation */
	float		step = 0.5;			/* tracking arclength increment */
	float		Asig_limit = 0.13; 		/* default Asig and comparable FA limits are set */
	float 		FA_limit = 0.2;
	float		I0thresh = I0THRESH;
	float		ratio32, dbarmax = DbarMAX;
	int		ktrk, k_turn, track_num, k_total = 0, k_max = 0;
	int		go, reverse, decisive;
	int		n_limit_hits = 0, v_hits_track, roc_limit_hits = 0;
	float 		TEND_f = 0., TEND_g = 0.;
	float 		RAVE_alpha = .2;
	int 		iMC, nMC = 0;
	float 		maxtAngle = 0., V1dotV2, cosTheta, degperrad;
	int 		iAngtest, numAngtest = 0, ang_limit_hits = 0, nsteps_test = NSTEPSTEST;

/********************/
/* start point grid */
/********************/
	int		start_dim[3], nstart, istart, jstart, astart = 0, mstart = 0;
	float		x_start[3], x_end[3];		/* user specified FOV restrictions */
	int		*seq;				/* randomized sequence */

/*************/
/* seed mask */
/*************/
	short		*start_img, *spt, *end_img;
	int		seedmask = 0, endmask = 0, nendvox, nstartvox, labelled_vox_count[256], iR;

/*******************/
/* visitation grid */
/*******************/
	int 		*end_roi_lut, *serial_order_end_lut, *start_roi_lut, *serial_order_start_lut;
	short		*grid, *sgrid;
	float 		**Ggrid, *oimg, Norm; /* Normalize grid when put into Ggrid */
	int		ngrid[4], jndex0, newvoxflag;

/***********/
/* utility */
/***********/
	float		ftmp, sign;
	int		n, c, i, j, k, l, jndex;

/*******************/
/* clock variables */
/*******************/
	typedef struct {
	 	time_t		starttime;
		int		istart;
	} PCTDONE;
	PCTDONE		pctdone[101];
	float		runrate, remaintime, runtime;

	printf ("%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (cmd, argv[i]); ptr = cmd;
   			if (!strstr (ptr, ":")) while (c = *ptr++) switch (c) {
				case '@': control = *ptr++; *ptr = '\0'; break;
				case 'v': verbose++;	break;
				case 'r': rk_flag++;	break;
				case 't': nouts = 1;	break;
				case 'T': nouts = 0; 	break;
				case 'd': debug++;	break;
				case 'f': while (c = *ptr++) switch (c) {
						case 'x': case 'X': pflip[0] *= -1.; break;
						case 'y': case 'Y': pflip[1] *= -1.; break;
						case 'z': case 'Z': pflip[2] *= -1.; break;
					  }
				case 'D': tensor_data++; break;
			} else {
				if (strstr (ptr, "-m:"))		interp_flag = atoi (ptr + 3);
				if (strstr (ptr, "-D:"))		dbarmax = atof (ptr + 3);
				if (strstr (ptr, "-I:"))		I0thresh = atof (ptr + 3);
				if (strstr (ptr, "-ROC:")) 		minradcurv = atof (ptr + 5);
				if (strstr (ptr, "-Ang:")) 		maxtAngle = atof (ptr + 5);
				if (strstr (ptr, "-a:")) 		Asig_limit = atof (ptr + 3);
				if (strstr (ptr, "-FA:")) {
					use_FA++;
					FA_limit = atof (ptr + 4);
				}
				if (strstr (ptr,"-Track:")) {
					if (strstr (ptr+7,"TEND,")) {
						use_TEND++;
						TEND_f = atof (strtok (ptr + 12 , ","));
						TEND_g = atof (ptr + strlen(ptr) + 1);
						if (TEND_f < 0. || TEND_g < 0. || TEND_f > 1. || TEND_g > 1.){
							fprintf(stderr,"ERROR: incorrect TEND variables\n");
							usage(program);
						}
					}
					else if (strstr (ptr + 7, "RAVE")) {
						use_RAVE++;
						if (strstr (ptr + 11, ","))
							RAVE_alpha = atof (ptr + 12);
						if (nMC == 1) nMC = MONTECARLO; /*if nMC hasn't been set yet at commandline, set to default*/
					}
					else if (strstr (ptr + 7, "PICo")) {
						use_PICo++;
						if ( !nMC ) nMC = MONTECARLO; 
					}
					else if (strstr (ptr + 7, "BICo")) {
						use_BICo++;
						if ( !nMC ) nMC = MONTECARLO; 
					}
					else {
						fprintf(stderr, "ERROR: incorrect track algorithm variables : %s\n",ptr);
						usage (program);
					}
				}
				if (strstr (ptr, "-MC:")) 		nMC = atoi (ptr + 4);
				if (strstr (ptr, "-step:"))		step = atof (ptr + 6);
				if (strstr (ptr, "-seedspace:"))	del = atof (ptr + 11);
				if (strstr (ptr, "-seedmask:")) {
					getrootl (ptr + 10, seed_root);
					seedmask = 1;
				}
				if (strstr (ptr, "-ROIs:")){
					getrootl (ptr+6, end_root);
					endmask=1;
				}
				if (strstr (ptr, "-lDtensor:")){
					load_Dtensor++;
					getrootl (ptr + 10, Dtensor_root);
				}
				if (strstr (ptr, "-sDtensor:")){
					save_Dtensor++;
					getrootl (ptr + 10, Dtensor_root);
				}

			}
		}
		else switch (k) {
			case 0:	strcpy  (prmfile, argv[i]);	k++; break;
			case 1:	getrootl (argv[i], input_root);	k++; break;
			case 2:	getrootl (argv[i], output_root);	k++; break;
		}	
	}
	if (k < 3) usage (program);

	degperrad = 45./atan(1.);
	cosTheta = cos (maxtAngle/degperrad);

/*************************************************/
/* read 4dfp image data and define search volume */
/*************************************************/
	printf ("%s: input_root=%s\n", program, input_root);
	if (get_4dfp_dimoe (input_root, imgdim, voxsiz, &orient, &isbig)) errr (program, input_root);
	Getifh (input_root, &ifh);
	if (!control) control = (isbig) ? 'b' : 'l';
	nvox = imgdim[0] * imgdim[1] * imgdim[2];
	n = imgdim[3];
	if (!(use_BICo || tensor_data) && n != dti_dimen (prmfile)) errd (program, prmfile, input_root);

/****************************************************/
/* open seedmask and check for dimensional matching */
/****************************************************/
	if (seedmask) {
		sprintf (seed_file, "%s.hdr", seed_root);

		if (!(fp_hdr = fopen (seed_file, "r")) || fread (&hdr, sizeof (struct dsr), 1, fp_hdr) != 1
		|| fclose (fp_hdr)) errr (program, seed_file);

		/*byte order test*/
		swab_flag = 0;
		if (hdr.hk.sizeof_hdr != sizeof (struct dsr)) {
			printf ("swapping hdr byte order\n");
			swab_hdr (&hdr);
			swab_flag++;
		}
		if (hdr.dime.datatype != 4 || hdr.dime.bitpix != 16) {
			fprintf (stderr, "%s: unrecognized data type %s\n", program, seed_file);
			exit (-1);
		}

		for (i = 0; i < 3; i++) {
			if (hdr.dime.dim[i + 1] != imgdim[i]) errd (program, seed_root, input_root);
		}
		if (!(start_img = (short *) malloc (nvox * sizeof (short)))) errm (program);
		sprintf (seed_file, "%s.img", seed_root);
		if (!(fp_seed = fopen (seed_file, "rb"))
		|| fread (start_img, sizeof (short), nvox, fp_seed) != nvox
		|| fclose (fp_seed)) errr (program, seed_file);
		if (swab_flag) for (i = 0; i < nvox; i++) swab2 ((char *) &start_img[i]);

/*******************************/
/* initialize start point grid */
/*******************************/
		for (k = 0; k < 3; k++) {x_start[k] = FLT_MAX; x_end[k] = -FLT_MAX;}
		spt = start_img;
		for (ix[2] = 0; ix[2] < imgdim[2]; ix[2]++) {
		for (ix[1] = 0; ix[1] < imgdim[1]; ix[1]++) {
		for (ix[0] = 0; ix[0] < imgdim[0]; ix[0]++) {
			if (*spt++) for (k = 0; k < 3; k++) {
				if (ix[k]*voxsiz[k] < x_start[k]) x_start[k] = ix[k]*voxsiz[k];
				if ((ix[k] + 1)*voxsiz[k] > x_end[k]) x_end[k] = (ix[k] + 1)*voxsiz[k];
			}
		}}}
	} else {
		for (k = 0; k < 3; k++) {
			x_start[k] = voxsiz[k] * 0.5;
			x_end[k]   = voxsiz[k] * ((float) imgdim[k] - 0.5);
		}
	}
	for (nstart = 1, k = 0; k < 3; k++) {
		start_dim[k] = (int) .5 + (x_end[k] - x_start[k]) / del;
		nstart *= start_dim[k];
		if (debug) printf ("%d x_start:%10.4f x_end:%10.4f start_dim:%d \n",k, x_start[k], x_end[k], start_dim[k]);
	}

	if (endmask) {
		sprintf (end_file, "%s.hdr", end_root);
		if (!(fp_hdr = fopen (end_file, "r")) || fread (&hdr, sizeof (struct dsr), 1, fp_hdr) != 1
		|| fclose (fp_hdr)) errr (program, end_file);

		/*byte order test*/
		swab_flag = 0;
		if (hdr.hk.sizeof_hdr != sizeof (struct dsr)) {
			printf ("swapping hdr byte order\n");
			swab_hdr (&hdr);
			swab_flag++;
		}
		if (hdr.dime.datatype != 4 || hdr.dime.bitpix != 16) {
			fprintf (stderr, "%s: unrecognized data type %s\n", program, end_file);
			exit (-1);
		}

		for (i = 0; i < 3; i++) {
			if (hdr.dime.dim[i + 1] != imgdim[i]) errd (program, end_root, input_root);
		}
		if (!(end_img = (short *) malloc (nvox * sizeof (short)))) errm (program);
		if (!(end_roi_lut = (int *) malloc (nvox * sizeof (int)))) errm (program);
		if (!(start_roi_lut = (int *) malloc (nvox * sizeof (int)))) errm (program);
		sprintf (end_file, "%s.img", end_root);
		if (!(fp_end = fopen (end_file, "rb"))
		|| fread (end_img, sizeof (short), nvox, fp_end) != nvox
		|| fclose (fp_end)) errr (program, end_file);
		if (swab_flag) for (i = 0; i < nvox; i++) swab2 ((char *) &end_img[i]);

/*******************************************************************/
/* assign serial order to each labelled voxel in the end_roi image */ 
/*******************************************************************/
		for (nendvox = nstartvox = i = 0; i<nvox; i++){ 
			if (end_img[i]) end_roi_lut[i] = ++nendvox;
			else end_roi_lut[i] = 0;
			if (start_img[i]) start_roi_lut[i] = ++nstartvox;
			else start_roi_lut[i] = 0;
		}
		printf("nendvox=%d\n",nendvox); fflush(stdout);
		if (!(serial_order_end_lut = (int *) malloc (nendvox * sizeof (int)))) errm (program);
		if (!(serial_order_start_lut = (int *) malloc (nstartvox * sizeof (int)))) errm (program);
		for (j=k=i=0; i<nvox; i++) {
			if (end_img[i]) serial_order_end_lut[k++]=i;
			if (start_img[i]) serial_order_start_lut[j++]=i;
		}
		assert (k == nendvox); assert (j==nstartvox);

		printf("made LUT\n"); fflush(stdout);
		Ggrid = matrix (1,nstartvox,1,nendvox); /* called according to array indices */
		
		printf ("initializing Ggrid,nstar=%d,nstartvox=%d,nendvox=%d\n",nstart,nstartvox,nendvox); fflush(stdout);	
		for (i = 1; i <= nstartvox; i++) for (k = 1; k <=nendvox; k++) Ggrid[i][k] = 0.0;
	}

/********************************************/
/* set up pseudorandom start point sequence */
/********************************************/
	fprintf (stderr, "%s: setting up pseudo-random start point sequence for %d points\n", program, nstart);
	if (!(seq = (int *) malloc (nstart * sizeof (int)))) errm (program);
	scanset (seq, nstart);

/******************************/
/* initialize visitation grid */
/******************************/
	for (k = 0; k < 3; k++) {
		ngrid[k] = imgdim[k];
	}
	ngrid[3] = 1;				/* for Inithdr () */
	if (!(grid =  (short *) calloc (nvox, sizeof (short)))) errm (program);
	if (!(sgrid = (short *) calloc (nvox, sizeof (short)))) errm (program);
	Norm = 1./nMC;

/******************/
/* start rec file */
/******************/
	if (save_Dtensor) {
		sprintf (Dtensor_file,"%s.Dtensor.rec",Dtensor_root);
		startrecl (Dtensor_file, argc, argv, rcsid);
		endrec ();
	}
	sprintf (recfile, "%s.trk.rec", output_root);
	startrecle (recfile, argc, argv, rcsid, control_trk);
	if (!(fp_rec = fopen (recfile, "a"))) errw (program, recfile);
	fprintf (fp_rec, "track capacity %d beads\n", NKTRK);
	if (use_FA) fprintf (fp_rec, "Fractional Anisotropy threshold %f\n",FA_limit);
	else fprintf (fp_rec, "Asigma threshold %f\n",Asig_limit); 
	fprintf (fp_rec, "Dbar trackability cutoff %.4f\n", dbarmax);
	fprintf (fp_rec, "I0 trackability threshold %.1f\n", I0thresh);
	fprintf (fp_rec, "Radius of Curvature limit %.4f\n", minradcurv);
	fprintf (fp_rec, "interpolation method (%d) ", interp_flag);
	if (interp_flag) {
		switch (interp_flag & 1) {
			case 1: fprintf (fp_rec, "linear ");		break;
			case 0: fprintf (fp_rec, "cubic spline ");	break;
		}
		switch (interp_flag & 4) {
			case 1: fprintf (fp_rec, "in tensor space\n");	break;
			case 0: fprintf (fp_rec, "in image space\n");	break;
		}
	} else {
		fprintf (fp_rec, "none\n");
	}
	if (seedmask) {
		fprintf (fp_rec, "seedmask\t%s\n", seed_root);
	} else {
		fprintf (fp_rec, "seedmask not used\n");
	}
	if (use_TEND) fprintf (fp_rec, "TEND: f = %.4f, g = %.4f\n", TEND_f, TEND_g);
	if (use_RAVE) fprintf (fp_rec, "RAVE: alpha = %.4f, MC = %d\n",RAVE_alpha, nMC); 
	fprintf (fp_rec, "start point grid%8d%8d%8d\n", start_dim[0], start_dim[1], start_dim[2]);
	fprintf (fp_rec, "start corner    %8.2f%8.2f%8.2f\n", x_start[0], x_start[1], x_start[2]);
	fprintf (fp_rec, "end   corner    %8.2f%8.2f%8.2f\n", x_end[0], x_end[1], x_end[2]);
	fprintf (fp_rec, "start point separation %.6f mm\n", del);
	fprintf (fp_rec, "start point count %d (random seeding)\n", nstart);
	fprintf (fp_rec, "tracking step length %.4f mm\n", step);
	fprintf (fp_rec, "principal eigenvector component multipliers (%3.0f%3.0f%3.0f)\n", pflip[0], pflip[1], pflip[2]);
	fprintf (fp_rec, "number of output files %d\n", nouts);
	fprintf (fp_rec, "input_root\t%s\n", input_root);
	fprintf (fp_rec, "output_root\t%s\n", output_root);
	fflush  (fp_rec);

/***************************************/
/* allocate memory and read image data */
/***************************************/
		k = (interp_flag & 4 || !interp_flag) ? 1 : 4;
		if (!(fimg = (float *) calloc (k * n * nvox, sizeof (float)))) errm (program);
		sprintf (imgfile, "%s.4dfp.img", input_root);
		printf ("Reading: %s\n", imgfile);
		if (!(fp = fopen (imgfile, "rb"))) errr (program, imgfile);
		fptr = fimg;
		for (j = 0; j < n; j++) {		/* loop on volumes */
			if (eread (fptr, nvox, isbig, fp)) errr (program, imgfile);
/************************/
/* flip 4dfp to analyze */
/************************/
			switch (orient) {
				case 4:	flipx (fptr, imgdim+0, imgdim+1, imgdim+2);
				case 3:	flipz (fptr, imgdim+0, imgdim+1, imgdim+2);
				case 2:	flipy (fptr, imgdim+0, imgdim+1, imgdim+2); break;
				default: fprintf (stderr, "%s: illegal %s orientation (%d)\n", 
					program, imgfile, orient); exit (-1);
			}
			fptr += k*nvox;
		}
		fclose (fp);
		if (k == 4 && !(interp_flag & 1)) spline3d (fimg, imgdim, n);
	
/****************************************/
/* compute I0thresh trackability volume */
/****************************************/
	if (!(timg = (char *) malloc (nvox * sizeof (char)))) errm (program);
	for (j = 0; j < nvox; j++) timg[j] = (fimg[j] > I0thresh) ? 1 : 0;

/**************************************/
/* allocate memory for diffusion calc */
/**************************************/
	ival =		vector(1, n);
	img_vals =	vector(1, n);
	bval =		vector(1, n);
	eigenval =	vector(1, 3);
	ang =		vector(1, 9);
	dvec =		vector(1, 7);
	if (!ival || !bval || !eigenval || !ang || !dvec) errm (program);

	exp_arr = 	matrix(1, n, 1, 7);
	eigenvec =	matrix(1, 3, 1, 3);
	eigenvec1 =	matrix(1, 3, 1, 3);
	eigenvec0 =	matrix(1, 3, 1, 3);
	dinv =		matrix(1, 3, 1, 3);
	qval =		matrix(1, n, 1, 3);
	if (!exp_arr || !eigenvec || !dinv || !qval) errm (program);

/***********************************************/
/* get the b values and direction unit vectors */
/***********************************************/
	if (!use_BICo && !tensor_data) {
			get_dti_params_nrc (prmfile, n, bval, qval);
			for (i=0;i<n;i++)
				for (j=0;j<3;j++)
					qval[i+1][j+1] = qval[i+1][j+1] * pflip[j];

/****************************************/
/* set up svd for diffusion calculation */
/****************************************/
			set_svd (n, bval, qval, exp_arr);
	}
	
	if (interp_flag & 4) {
/******************************************/
/* prepare to interpolate in tensor space */
/******************************************/
		if (!(dimg = (float *) calloc (4 * 6 * nvox, sizeof (float)))) errm (program);
		if (use_BICo){
			if (!(stdTimg = (float *) calloc (4 * nvox, sizeof (float)))) errm (program);
			if (!(stdPimg = (float *) calloc (4 * nvox, sizeof (float)))) errm (program);
			j = 0; printf ("evaluating bayesian D slice");

			for (ix[2] = 0; ix[2] < imgdim[2]; ix[2]++) {printf (" %d", ix[2] + 1); fflush (stdout);
			for (ix[1] = 0; ix[1] < imgdim[1]; ix[1]++) {
			for (ix[0] = 0; ix[0] < imgdim[0]; ix[0]++) {
				/* calc diffusion tensor form bayes data*/
				load_bayes_tensor (fimg, nvox, j, dimg);
				stdTimg[j] = (fimg + 14*nvox)[j];
				stdPimg[j] = (fimg + 13*nvox)[j];
				timg[j] = ((fimg + 7*nvox)[j] > I0thresh) ? 1 : 0;
				j++;
			}}}
			printf ("\nInterpolating tensor images\n"); fflush (stdout);
			if (!(interp_flag & 1)) spline3d (stdTimg, imgdim, 1);
			if (!(interp_flag & 1)) spline3d (stdPimg, imgdim, 1);
		}
		else if (tensor_data){
			j = 0; printf ("loading D slice");

			for (ix[2] = 0; ix[2] < imgdim[2]; ix[2]++) {printf (" %d", ix[2] + 1); fflush (stdout);
			for (ix[1] = 0; ix[1] < imgdim[1]; ix[1]++) {
			for (ix[0] = 0; ix[0] < imgdim[0]; ix[0]++) {
			        (dimg + 4*0*nvox)[j] = (fimg + 2*nvox)[j];
				(dimg + 4*1*nvox)[j] = (fimg + 3*nvox)[j];
				(dimg + 4*2*nvox)[j] = (fimg + 4*nvox)[j];
				(dimg + 4*3*nvox)[j] = (fimg + 5*nvox)[j];
				(dimg + 4*4*nvox)[j] = (fimg + 6*nvox)[j];
				(dimg + 4*5*nvox)[j] = (fimg + 7*nvox)[j];
				j++;
			}}}
		}
		else if (load_Dtensor) { 	/* load previously saved Dtensor file */
			fprintf (stdout, "loading diffusion tensor data ... \n");
			sprintf (Dtensor_file, "%s.Dtensor", Dtensor_root);
			if (!(fp_Dtensor = fopen (Dtensor_file, "rb")) || fread (dimg, sizeof (float), 4*6*nvox, fp_Dtensor) != 4*6*nvox 
			|| fclose (fp_Dtensor)) errr (program, Dtensor_file);
		} else {
			j = 0; printf ("evaluating D slice");
			for (ix[2] = 0; ix[2] < imgdim[2]; ix[2]++) {printf (" %d", ix[2] + 1); fflush (stdout);
			for (ix[1] = 0; ix[1] < imgdim[1]; ix[1]++) {
			for (ix[0] = 0; ix[0] < imgdim[0]; ix[0]++) {
				for (i = 0; i < n; i++) ival[i + 1] = (fimg + i*nvox)[j];
				calc_svd (n, ival, exp_arr, dvec);
				for (i = 0; i < 6; i++) (dimg + 4*i*nvox)[j] = dvec[i + 1];
				j++;
			}}}
			printf ("\n"); fflush (stdout);
/**************************************/
/* save Dtensor interpolation to file */
/**************************************/
			if (save_Dtensor) {
				fprintf(stdout,"saving diffusion tensor data ... \n");
				sprintf (Dtensor_file, "%s.Dtensor", Dtensor_root);
				if (!(fp_Dtensor = fopen (Dtensor_file, "wb")) || fwrite (dimg, sizeof (float), 4*6*nvox, fp_Dtensor) != 4*6*nvox 
				|| fclose (fp_Dtensor)) errw (program, Dtensor_file);
			}
		}
		if (!(interp_flag & 1)) spline3d (dimg, imgdim, 6);
		free (fimg);
	}

/***************************/
/* open track output files */
/***************************/
	for (i = 0; i < nouts; i++) {
		sprintf (output_file, "%s.%s", output_root, outs[i]); 
		if (!(fp_out[i] = fopen (output_file, "wb"))) errw (program, output_file);
	}

/*********************************/
/* start tracking on seed points */
/*********************************/
	if (debug) {printf("About to start GO GO GO\n"); fflush(stdout);}
	sprintf (output_file, "%s.time", output_root);
	if (!(fp_time = fopen (output_file, "w"))) errw (program, output_file);
	get_time_usr (datestring);
	fprintf (fp_time, "Started %s\n", datestring);
	fprintf (stdout, "computing tractography...\n");
	pctdone[0].istart = mstart = astart = track_num = 0;
	time (&pctdone[0].starttime);

	for (istart = 0; istart < nstart; istart++) {	/* seed point loop */
/*****************************/
/* reset sgrid for next seed */
/*****************************/
		for (k = 0; k < nvox; k++) sgrid[k] = 0;

/*****************/
/* time tracking */
/*****************/
		if ((astart += 100) >= nstart) {
		astart -= nstart;
		mstart++;
		time (&pctdone[mstart].starttime); pctdone[mstart].istart = istart;
		runtime = (float) (pctdone[mstart].starttime - pctdone[0].starttime) / 60.;
		k = mstart; while (k && (pctdone[mstart].starttime - pctdone[k].starttime < 5)) k--;
		runrate = (float) (pctdone[mstart].istart    - pctdone[k].istart) /
			  (float) (pctdone[mstart].starttime - pctdone[k].starttime);
		remaintime = (nstart - istart) / runrate;
		get_time_usr (datestring);
		fprintf (fp_time, "%s: %3d percent done\t %s\n", program, mstart, datestring);
		fprintf (fp_time, "Elapsed time (minutes)              %9.2f\n", runtime);
		fprintf (fp_time, "Tracking rate (seeds/minute)        %9.2f\n", runrate * 60.);
		fprintf (fp_time, "Estimated completion time (minutes) %9.2f\n", remaintime / 60.);
		fflush  (fp_time);
		}
		go = 1;

/*********************************************************************************************************/
/* loop on number of tracks per seed for probabalistic tracking methods nMC = 1 for Streamlined Tracking */
/*********************************************************************************************************/
		for (jndex0 = -1, iMC = 0; iMC < nMC; iMC++){
		if (verbose) {printf ("MC: %d\n",iMC+1); fflush (stdout);}
		
		jstart = seq[istart];
/************************************************************/
/* convert seed (x,y,z) (mm) to image array indices (i,j,k) */
/************************************************************/
		for (k = 0; k < 3; k++) {
			x0[k] = x[k] = x_start[k] + (0.5 + (float) (jstart % start_dim[k])) * del;
			jstart /= start_dim[k];
			aix[k] = x[k] / voxsiz[k];
			ix[k] = (int) aix[k];
			go &= (aix[k] > 0.0 && ix[k] < imgdim[k]);
		}
		if (debug) printf ("Tracknum:%d start point (mm) %10.4f%10.4f%10.4f (fndex) %10.4f%10.4f%10.4f go=%d\n",
					track_num, x[0], x[1], x[2], aix[0], aix[1], aix[2], go); fflush (stdout);

		if (go) {
/***********************************************************/
/* convert image index (i,j,k) to serial image array index */
/***********************************************************/
			jndex = ix[0] + imgdim[0]*(ix[1] + imgdim[1]*ix[2]);
			go &= timg[jndex];
/*************************************************************************/
/* make sure that seed is in the seed image mask, seed grid is rectangle */
/*************************************************************************/
			if (seedmask) go &= (start_img[jndex] > MASK_CRIT);
		}

/********************************/
/* track starting at seed point */
/********************************/
			if (verbose) {printf ("start track\n"); fflush (stdout);}		
			v_hits_track = reverse = ktrk = k_turn = 0;
			for (reverse = 0; reverse < 2; reverse++){ 
				/* loop  successful propogation in one direction from a seed point */
				while (go)                                                                         {
				memset (&dparam, '\0', sizeof (D_PARAMS_2));
				if (verbose) {printf ("Seed: %d\t MC: %d\t Tracknum: %d\t reverse: %d \n", istart, iMC, track_num + 1, reverse); fflush (stdout);}

				/* Test out of bounds */
				for (i = 0; i < 3; i++) {
					aix[i] = x[i] / voxsiz[i];
					ix[i] = (int) aix[i];
if (verbose) {printf ("x: %f\t %f\t  %f\t ix:  %f\t  %f\t  %f\t\n", x[0], x[1], x[2], aix[0], aix[1], aix[2]); fflush (stdout);}
					if (aix[i] < 0.0 || ix[i] > imgdim[i]-1) { 
				           problem = 1;
					   if (verbose) { printf ("problem\n"); fflush(stdout);}
					}
				}
				if (problem) { problem = 0; break;}

				if (verbose ) {printf ("inside tests\n"); fflush (stdout);}			
			/* Test out of mask */
				jndex = ix[0] + imgdim[0]*(ix[1] + imgdim[1]*ix[2]);
if (verbose) {printf ("jndex: %d\n", jndex); fflush (stdout);}
				if (!timg[jndex]) break;
				if (jndex != jndex0) {newvoxflag = 1; jndex0=jndex;} else newvoxflag=0;
			
			/* Calculate diffusion parameters on a new point */
				if (interp_flag & 4) {
					interpolate (interp_flag, 6, dimg, nvox, aix, imgdim, dvec);
				} else {
					if (interpolate (interp_flag, n, fimg, nvox, aix, imgdim, ival)) break;
					calc_svd (n, ival, exp_arr, dvec);
				}
				dparam_calc_noswap (dvec, dinv, eigenval, eigenvec, &dparam);
				if (tensor_data) 
				  for (i = 0; i < 3; i++) for (j = 0; j < 3; j++) 
				    eigenvec[i+1][j+1] *= pflip[i]; /* flip as we flip the gradients above*/
	

			/* test Dbar threshold */
				if (dparam.Dbar > dbarmax) break;
			
			/* test anisotropy threshold */
				if (use_FA) {
					if (dparam.FA < FA_limit) break;					
				} else {
					if (dparam.Asig < Asig_limit) break;
				}

			/* test Radius of Curvature threshold */
				if (ktrk-k_turn > 2*nsteps_test) {
					x1[0] = arm[ktrk- nsteps_test][0].x;
					x1[1] = arm[ktrk- nsteps_test][0].y;
					x1[2] = arm[ktrk- nsteps_test][0].z;

					x2[0] = arm[ktrk- 2*nsteps_test][0].x;
					x2[1] = arm[ktrk- 2*nsteps_test][0].y;
					x2[2] = arm[ktrk- 2*nsteps_test][0].z;
				}

				rcurv = radius_of_curvature (x2,x1,x);
				if (rcurv < minradcurv) {
					roc_limit_hits++;
					break;
				}

			/* write bead to visitation volume */
				if (newvoxflag) grid[jndex]++;
				if (newvoxflag) sgrid[jndex]++;
				
			/* save first point info for tracking in reverse */
				if (!ktrk) {
					for (i = 0; i < 3; i++){
						for (j = 0; j < 3; j++)
							eigenvec1[j + 1][i + 1] = eigenvec0[j + 1][i + 1] = eigenvec[j + 1][i + 1];
						Vin[i] = eigenvec[i + 1][dparam.imaj];
					}
					/* copy dparam */
					dparam0.imaj = dparam.imaj;
				}

				
			/* test max track length */
				if (ktrk >= NKTRK) {
					n_limit_hits++;
					if (verbose) fprintf (stderr, "track%8d went to max length %d\n", track_num + 1, NKTRK);
					break;
				}

				arm[ktrk][0].x = x[0];
				arm[ktrk][0].y = x[1];
				arm[ktrk][0].z = x[2];
				arm[ktrk][1].x = eigenvec[1][dparam.imaj];  /* principal eigenvector, as sorted by dparam_calc */
				arm[ktrk][1].y = eigenvec[2][dparam.imaj];
				arm[ktrk][1].z = eigenvec[3][dparam.imaj];
				if (nouts > 2) {
				arm[ktrk][2].x = eigenval[1];
				arm[ktrk][2].y = eigenval[2];
				arm[ktrk][2].z = eigenval[3];
				arm[ktrk][3].x = dparam.Dbar;
				arm[ktrk][3].y = dparam.Asig;
				arm[ktrk][3].z = dparam.Anu;
				arm[ktrk][4].x = dparam.ang[1];
				arm[ktrk][4].y = dparam.ang[2];
				arm[ktrk][4].z = dparam.ang[3];
				arm[ktrk][5].x = dparam.Amaj;
				arm[ktrk][5].y = dparam.Amin;
				arm[ktrk][5].z = dparam.prolat;
				/* indices are not accurate for no swap case
				arm[ktrk][6].x = eigenvec[1][1];
				arm[ktrk][6].y = eigenvec[2][1];
				arm[ktrk][6].z = eigenvec[3][1];
				arm[ktrk][7].x = eigenvec[1][2];
				arm[ktrk][7].y = eigenvec[2][2];
				arm[ktrk][7].z = eigenvec[3][2];
				*/
				}
				ktrk++;
				
			/* Compute direction to propogate track */
				if (use_PICo)
					PICo (Vin, dparam.Asig, dparam.imaj, eigenvec, eigenval, Vout);
				else if (use_BICo) {
					/* -1 in following call because last argument of interpolate is expected to have been allocated by nr */
					interpolate (interp_flag, 1, stdTimg, nvox, aix, imgdim, &stdTheta-1);
					interpolate (interp_flag, 1, stdPimg, nvox, aix, imgdim, &stdPhi-1);
					BICo (Vin, stdTheta, stdPhi, dparam.imaj, eigenvec, eigenval, Vout);
					if (maxtAngle){
					   V1dotV2 = abs((Vin[0] * Vout[0]) + (Vin[1]*Vout[1]) + (Vin[2]*Vout[2]));
					   iAngtest = 0;
					   while (V1dotV2 < cosTheta && iAngtest < MAXAngtest){
						if (!iAngtest) numAngtest++;
						BICo (Vin, stdTheta, stdPhi, dparam.imaj, eigenvec, eigenval, Vout);
						V1dotV2 = abs((Vin[0] * Vout[0]) + (Vin[1]*Vout[1]) + (Vin[2]*Vout[2]));
						iAngtest++;
					   }
					}
				}
				else if (use_RAVE)
					RAVE(Vin, RAVE_alpha, dparam.imaj, eigenvec, eigenval, Vout);
				else if (use_TEND) 
					TEND(Vin, TEND_f * dparam.Asig, TEND_g, dparam.imaj, eigenvec, eigenval, Vout); 
				else {
					for (i = 0; i < 3; i++) Vout[i] = eigenvec[i + 1][dparam.imaj];
					/* Calculate sign between previous and current vectors */
					for (ftmp = i = 0; i < 3; i++) ftmp += Vin[i] * Vout[i];
					sign = (ftmp < 0.0) ? -1.0 : +1.0;
					for (i=0; i<3; i++) Vout[i] = Vout[i] * sign;
				}

		if (debug) {printf("Ktrk:%d Vin: %10.6f,%10.6f,%10.6f eigenvec[%d]: %10.6f,%10.6f,%10.6f Vout: %10.6f,%10.6f,%10.6f \n", \
		ktrk, Vin[0], Vin[1], Vin[2], dparam.imaj, eigenvec[1][dparam.imaj],eigenvec[2][dparam.imaj],eigenvec[3][dparam.imaj], \
		Vout[0], Vout[1], Vout[2]); fflush(stdout); }

			/* Runge-Kutta */
				if (interp_flag && rk_flag) {	/* Modify Vout step increment using Runge-Kutta */
				/****************/
				/* calculate k2 */
				/****************/
					for (i = 0; i < 3; i++) {
						bix[i] = aix[i] + (step/2.0) * Vout[i];
					}
					if (interp_flag & 4) {
							interpolate (interp_flag, 6, dimg, nvox, bix, imgdim, dvec);
					} else {
						interpolate (interp_flag, n, fimg, nvox, bix, imgdim, ival);
						calc_svd (n, ival, exp_arr, dvec);
					}
					dparam_calc_noswap (dvec, dinv, eigenval, eigenvec, &dparam);
					for (ftmp = i = 0; i < 3; i++) {
						k2[i] = eigenvec[i + 1][dparam.imaj];
						ftmp += k2[i]*Vout[i];
					}
					if (ftmp < 0.0) for (i = 0; i < 3; i++) k2[i] *= -1.0;

				/****************/
				/* calculate k3 */
				/****************/
					for (i = 0; i < 3; i++) {
						bix[i] = aix[i] + (step/2.0)*k2[i];
					}
					if (interp_flag & 4) {
							interpolate (interp_flag, 6, dimg, nvox, bix, imgdim, dvec);
					} else {
						interpolate (interp_flag, n, fimg, nvox, bix, imgdim, ival);
						calc_svd (n, ival, exp_arr, dvec);
					}
					dparam_calc_noswap (dvec, dinv, eigenval, eigenvec, &dparam);
					for (ftmp = i = 0; i < 3; i++) {
						k3[i] = eigenvec[i + 1][dparam.imaj];
						ftmp += k3[i]*Vout[i];
					}
					if (ftmp < 0.0) for (i = 0; i < 3; i++) k3[i] *= -1.0;

				/****************/
				/* calculate k4 */
				/****************/
					for (i = 0; i < 3; i++) {
						bix[i] = aix[i] + step*k3[i];
					}
					if (interp_flag & 4) {
							interpolate (interp_flag, 6, dimg, nvox, bix, imgdim, dvec);
					} else {
						interpolate (interp_flag, n, fimg, nvox, bix, imgdim, ival);
						calc_svd (n, ival, exp_arr, dvec);
					}
					dparam_calc_noswap (dvec, dinv, eigenval, eigenvec, &dparam);
					for (ftmp = i = 0; i < 3; i++) {
						k4[i] = eigenvec[i + 1][dparam.imaj];
						ftmp += k4[i]*Vout[i];
					}
					if (ftmp < 0.0) for (i = 0; i < 3; i++) k4[i] *= -1.0;
				
				/**************************/
				/* get final rk direction */
				/**************************/
					for (i = 0; i < 3; i++) {
						Vout[i] /= 6.0;
						Vout[i] += k2[i]/3.0 + k3[i]/3.0 + k4[i]/6.0; 
					}
				}

			if (maxtAngle){
				V1dotV2 = abs((Vin[0] * Vout[0]) + (Vin[1]*Vout[1]) + (Vin[2]*Vout[2]));
				if (V1dotV2 < cosTheta) {
					ang_limit_hits++;
					break;
				}
			}

			/* Step */
				for (i = 0; i < 3; i++) 
					x[i] += step * Vout[i];
			
			/* Update next step */	
				for (i = 0; i < 3; i++){
					for (j = 0; j < 3; j++)
						eigenvec1[j + 1][i + 1] = eigenvec[j + 1][i + 1];
					Vin[i] = Vout[i];
				}
			}
			if (!reverse){
			/* step variable so that track can be written in sequentially */
				k_turn = ktrk - 1;
		

			/*Set variable to continue tracking from seed point in other direction */
				for (i = 0; i < 3; i++){
					x[i] = x0[i];
					for (j = 0; j < 3; j++)
						eigenvec1[i + 1][j + 1] = -eigenvec0[i + 1][j + 1];
					Vin[i] = -eigenvec0[i + 1][dparam0.imaj];
				}
			}	
		}

/***********************/
/* print track summary */
/***********************/
		if (verbose) {
			for (j = ktrk - 1; j > k_turn; j--) { 
				fprintf (stderr, "%8d: %10.4f%10.4f%10.4f  %10.6f%10.6f%10.6f\n", track_num + 1,
						arm[j][0].x, arm[j][0].y, arm[j][0].z,
						arm[j][1].x, arm[j][1].y, arm[j][1].z);
			}
			for (j = 1; j <= k_turn; j++) { 
				fprintf (stderr, "%8d: %10.4f%10.4f%10.4f  %10.6f%10.6f%10.6f\n", track_num + 1,
						arm[j][0].x, arm[j][0].y, arm[j][0].z,
						arm[j][1].x, arm[j][1].y, arm[j][1].z);
			}
			fprintf (stderr, "track%8d length%4d k_turn%4d starting locus %8.2f%8.2f%8.2f\n",
				track_num + 1, ktrk, k_turn, x0[0], x0[1], x0[2]);
		}
		
		if (ktrk) {
			for (i = 0; i < nouts; i++) {
				for (j = ktrk - 1; j > k_turn; j--) { 
					arm[j][i].id = track_num + 1;
					if (gwrite ((char *) &arm[j][i], sizeof (float), 4, fp_out[i], control_trk))
						errw (program, output_root);
				}
				for (j = 1; j <= k_turn; j++) { 
					arm[j][i].id = track_num + 1;
					if (gwrite ((char *) &arm[j][i], sizeof (float), 4, fp_out[i], control_trk))
						errw (program, output_root);
				}
			}
			track_num++;
			k_total += ktrk;
			if (ktrk > k_max) k_max = ktrk;
		}

	} /*end MC loop */
	if (verbose) printf ("finished seed: %d outof %d\n", istart, nstart);

/************************/
/* put sgrid into Ggrid */
/************************/
	jstart = seq[istart];
	for (k = 0, go = 1; k < 3; k++) {
		x[k] = x_start[k] + (0.5 + (float) (jstart % start_dim[k])) * del;
		jstart /=  start_dim[k];
		aix[k] = x[k] / voxsiz[k];
		ix[k] = (int) aix[k];
		if (aix[k] < 0.0 || ix[k] > imgdim[k]) go = 0;
	}
	jndex = ix[0] + imgdim[0]*(ix[1] + imgdim[1]*ix[2]);
	if (seedmask) go &= (start_img[jndex] > MASK_CRIT);
	if (!go) continue;

	if (endmask) for (k = 0; k < nendvox; k++) {
		/* update Ggrid with the seeds connenctivity to end roi voxels */ 
		if (start_roi_lut[jndex] == 0) {
			printf ("severe error in start_roi_lut refrence, jndex=%d, start_roi_lut =%d\n",jndex,start_roi_lut[jndex]);
			exit (-1);
		}
		Ggrid[start_roi_lut[jndex]][k+1] += sgrid[serial_order_end_lut[k]];
	}

	} /* end start point loop */

/****************************/
/* close output track files */
/****************************/
	for (i = 0; i < nouts; i++) fclose (fp_out[i]);
	fclose (fp_time);

/***************************************************************/
/* collapse Ggrid into output images                           */
/* foreach ROI value (>0) output an image                      */
/* collapse the connectivity of endROI for each start voxel    */
/***************************************************************/
if (endmask) {
	fprintf (stderr, "Computing seed connectivity: %s_endROI.4dfp.img...\n",output_root);
	sprintf (output_file, "%s_endROI.4dfp.img", output_root);
	if (!(fp_grid = fopen (output_file, "wb"))) errw (program, output_file);

	for (i = 0; i < MAXROIS; i++) labelled_vox_count[i] = 0;
	for (i = 0; i <nvox; i++) if (end_img[i] < MAXROIS) labelled_vox_count[end_img[i]]++;
	for (imgdim[3] = 0, iR = 1; iR < MAXROIS; iR++) {
		if (!labelled_vox_count[iR]) continue;
		if (!(oimg = (float *) calloc (nvox, sizeof (float)))) errm (program);
		for (istart = 0; istart < nstartvox; istart++) {
/*********************************************************/
/* figure connectivity of current seed to current endROI */
/*********************************************************/
			jndex = serial_order_start_lut[istart];
			for (i = 0; i < nendvox; i++) {
				if (end_img[serial_order_end_lut[i]] == iR) oimg[jndex] += Ggrid[istart+1][i+1];
			}	
		}
/***********************************************/
/* write the connectivity image to current ROI */
/***********************************************/
		flipy (oimg,imgdim+0,imgdim+1,imgdim+2);
		if (ewrite (oimg, nvox, control, fp_grid)) errw (program, output_file);
		imgdim[3]++;
		free (oimg);
	}
	if (fclose (fp_grid)) errw (program, output_file);
	sprintf (output_file, "%s_endROI.4dfp.ifh", output_root);
	writeifhmce (program, output_file, imgdim, voxsiz, orient, ifh.mmppix, ifh.center, control);
/*NEED to add REC code*/	
}

/********************************/
/* dump grid to ANALYZE 7.5 img */
/********************************/
	for (k = 0; k < nvox; k++) grid[k] = grid[k]*Norm;
	sprintf (output_file, "%s.img", output_root);
	fprintf (stderr, "Writing: %s\n", output_file);

	if (!(fp_grid = fopen (output_file, "wb"))
	|| gwrite ((char *) grid, sizeof (short), nvox, fp_grid, control)
	|| fclose (fp_grid)) errw (program, output_file);

/***************************************/
/* create signed short ANALYZE 7.5 hdr */
/***************************************/
	Inithdr (&hdr, ngrid, voxsiz, "");
	for (k = 0, i = 0; i < nvox; i++) {
		if (grid[i] > k ) k = grid[i];
	}
	hdr.dime.glmax = k;
	hdr.dime.glmin = 0;
	sprintf (output_file, "%s.hdr", output_root);

	swab_flag = ((CPU_is_bigendian() != 0) && (control == 'l' || control == 'L'))
		||  ((CPU_is_bigendian() == 0) && (control == 'b' || control == 'B'));
	if (swab_flag) swab_hdr (&hdr);
	if (!(fp_hdr = fopen (output_file, "wb")) || fwrite (&hdr, sizeof (struct dsr), 1, fp_hdr) != 1
	|| fclose (fp_hdr)) errw (program, output_file);

/*********************/
/* complete rec file */
/*********************/
	if (maxtAngle && use_BICo) 
		fprintf (fp_rec, "number of BICo vectors recalculated due to angle thresh = %d\n",numAngtest);
	fprintf (fp_rec, "visitation grid max %d\n", hdr.dime.glmax);
	fprintf (fp_rec, "bead count %d\n", k_total);
	fprintf (fp_rec, "track count %d\n", track_num);
	fprintf (fp_rec, "maximum track length %d beads\n", k_max);
	fprintf (fp_rec, "number of arms hitting NKTRK limit %d\n", n_limit_hits);
	fprintf (fp_rec, "number of arms hitting Radius of Curvature limit %d\n", roc_limit_hits); 
	fprintf (fp_rec, "number of arms hitting Angle-between-beads threshold %d\n",ang_limit_hits);
	fprintf (fp_rec, "rms |Dbar_eval - Dbar_trace| %e\n", sqrt (jacobi_err / njac));
	fclose  (fp_rec);
	if (seedmask) catrec (seed_file);
	catrec (imgfile);
	endrec ();
	sprintf (cmd, "brec %s -2", recfile); system (cmd);

/*********************/
/* clean up and exit */
/*********************/
	if (interp_flag & 4) {
		free (dimg);
	} else {
		free (fimg);
	}
	free (grid); free (timg);
	if (seedmask) free (start_img);
	if (endmask) free (end_img);
	free (seq);

	free_vector(ival,1, n);
	free_vector(img_vals,1, n);
	free_vector(bval,1, n);
	free_vector(eigenval,1, 3);
	free_vector(ang,1, 9);
	free_vector(dvec,1, 7);
	free_matrix(exp_arr,1, n, 1, 7);
	free_matrix(eigenvec,1, 3, 1, 3);
	free_matrix(dinv,1, 3, 1, 3);
	free_matrix(qval,1, n, 1, 3);

	exit (0);
}

void spline3d (float *fimg, int *imgdim, int nvol) {
	int i, nvox;
	float *fptr;

	nvox = imgdim[0] * imgdim[1] * imgdim[2];
	printf ("computing 3d splines for %d voxels volume", nvox);
	fptr = fimg;
	for (i = 0; i < nvol; i++) {printf (" %d", i + 1); fflush (stdout);
			splinex_ (fptr, imgdim+0, imgdim+1, imgdim+2, fptr + 1*nvox);
			spliney_ (fptr, imgdim+0, imgdim+1, imgdim+2, fptr + 2*nvox);
		if (imgdim[2] > 64) {
			splinezf_(fptr, imgdim+0, imgdim+1, imgdim+2, fptr + 3*nvox);
		} else {
			splineza_(fptr, imgdim+0, imgdim+1, imgdim+2, fptr + 3*nvox);
		}
		fptr += 4*nvox;
	}
	printf ("\n"); fflush (stdout);
}

int interpolate (int interp_flag, int n, float *fimg, int nvox, float *aix, int *imgdim, float *img_vals) {
	int	i, jndex, ix[3];
	float	*fptr;

	fptr = fimg;
	if (interp_flag) for (i = 1; i <= n; i++) {	/* interpolate */
		splint3dv_ (fptr, imgdim + 0, imgdim + 1, imgdim + 2,
			fptr + 1*nvox, fptr + 2*nvox, fptr + 3*nvox,
			aix + 0, aix + 1, aix + 2, img_vals + i);
		fptr += 4 * nvox;
	} else {					/* no interpolation */
		ix[0] = (int) aix[0];
		ix[1] = (int) aix[1];
		ix[2] = (int) aix[2];
		for (i = 1; i <= n; i++) {
			jndex = ix[0] + imgdim[0]*(ix[1] + imgdim[1]*ix[2]);
			img_vals[i] = fptr[jndex];
			fptr += nvox;
		}
	}

/***************/
/* error check */
/***************/
	for (i = 1; i <= n; i++) if (img_vals[i] <= 0.0) return (1);
	return (0);
}

int match_dir (int track_flag, float **eigenvec1, float **eigenvec ) {
/* correct sign of eigenvector as compared to previous eigenvector */
/* Euler: compute sign between third vectors as they have been sorted */
/* TEND: compute sign between vectors that match by smallest angle */

	int i, j, ivec, icmp, match[3], op[3];
	float ftmp = 0., sign = 0.;
	
	switch (track_flag) {
		case 1: 
			for(i = 0; i < 3; i++) 
				ftmp += eigenvec1[i+1][3] * eigenvec[i+1][3];
			sign = (ftmp < 0.0) ? -1.0 : +1.0;
			for (i = 0; i < 3; i++)
				eigenvec[i+1][3] = sign * eigenvec[i+1][3];
			break;
		case 2: 
			/* compute sign between vectors that match by smallest angle */
			
			/* match vector to vector with largest abs(dotproduct) */
			for (ivec = 0; ivec < 3; ivec++){
				for (icmp = 0; icmp < 3; icmp++){
					for (op[icmp] = i = 0; i < 3; i++)
						op[icmp] += eigenvec[i+1][ivec+1] * eigenvec1[i+1][icmp+1];
				}
				/* find max abs */				
			        match[ivec] = 0;
				for (icmp = 1; icmp < 3; icmp++) 
					if (abs (op[icmp]) > abs (op[icmp-1])) match[ivec] = icmp;
				 
				/** apply sign of max abs to eigenvec[][ivec] **/
				sign = (op[ match[ivec] ] < 0) ? -1.0 : +1.0;
				for (i = 0; i < 3; i++)
					eigenvec[i+1][ivec+1] = sign * eigenvec[i+1][ivec+1];
		      
			}
	
			for (i = 0; i < 3; i++) for (j = 0; j < 3; j++) if (i != j ) assert (match[i] != match[j]);
      
			break;
	}
	
	return 1;
}


int load_bayes_tensor ( float *fimg, int nvox, int j, float *dimg){

	int m,n,k,l;
	double alfa, beta, gama, dxx, dyy, dzz;
	double sa, sb, sg, ca, cb, cg; 
	double rot[3][3], ddiag[3][3], dten[3][3];
			
	alfa = (fimg + 4*nvox)[j];
	beta = M_PI - (fimg + 5*nvox)[j]; /* z flip as we flip the gradients above*/
	gama = (fimg + 6*nvox)[j];
	dxx = (fimg + 1*nvox)[j];
	dyy = (fimg + 2*nvox)[j];
	dzz = (fimg + 3*nvox)[j];

	sa = sin(alfa); ca = cos(alfa);
	sb = sin(beta); cb = cos(beta);
	sg = sin(gama); cg = cos(gama);
			
	/* form the rotation matrix Arfken 2nd ed. pp.180 */
	rot[0][0] = cg*cb*ca - sg*sa;
	rot[0][1] = cg*cb*sa + sg*ca;
	rot[0][2] = -cg*sb;
	rot[1][0] = -sg*cb*ca - cg*sa;
	rot[1][1] = -sg*cb*sa + cg*ca;
	rot[1][2] = sg*sb;
	rot[2][0] = sb*ca;
	rot[2][1] = sb*sa;
	rot[2][2] = cb;

	/* init the diagonal diffusion tensor */
	ddiag[0][0] = dxx; ddiag[0][1] = 0.0; ddiag[0][2] = 0.0;
	ddiag[1][0] = 0.0; ddiag[1][1] = dyy; ddiag[1][2] = 0.0;
	ddiag[2][0] = 0.0; ddiag[2][1] = 0.0; ddiag[2][2] = dzz;

	/* rotate the d tensor into lab frame */
	for (m=0; m<3; ++m) 
	for (n=0; n<3; ++n) {
	    	dten[m][n] = 0.0;
	    	for (k=0; k<3; ++k) 
	    	for (l=0; l<3; ++l) {
			dten[m][n] += rot[k][m]*ddiag[k][l]*rot[l][n];
	    	}
    	}

	(dimg + 4*0*nvox)[j] = dten[0][0];
	(dimg + 4*1*nvox)[j] = dten[1][1];
	(dimg + 4*2*nvox)[j] = dten[2][2];
	(dimg + 4*3*nvox)[j] = dten[0][1];
	(dimg + 4*4*nvox)[j] = dten[0][2];
	(dimg + 4*5*nvox)[j] = dten[1][2];

	j++;
			
	return 1;
}
