/*$Id: tend.c,v 1.1 2007/08/30 04:54:58 avi Exp $*/
/*$Log: tend.c,v $
 * Revision 1.1  2007/08/30  04:54:58  avi
 * Initial revision
 **/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <float.h>
#include <math.h>
#include <JSSutil.h>

/****************************************/
/*********    TEND algorithm  ***********/
/** Lazar et al., HBM 18:306-321(2003) **/
/****************************************/

/* Fix eigenvec and eigenval so don't need to increment */

int TEND(float *Vin, float f, float g, int imaj, float **eigenvec, float *eigenval, float *Vout){
	float alpha[3], TEND_vec[3],mag, ftmp;
	int i,j, signE1, signTEND;
	
	alpha[0] = alpha[1] = alpha[2] = 0.;
	TEND_vec[0] = TEND_vec[1] = TEND_vec[2] = 0.;
	
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++){
			alpha[i] += Vin[j] * eigenvec[j+1][i+1]; 
		}
	}
	for (i = 0; i < 3; i++) {
		for (j = 0 ; j < 3; j++){
			TEND_vec[i] += alpha[j] * ( eigenval[j+1] / eigenval[imaj] ) * eigenvec[i+1][j+1]; 
		}
	}

	for(ftmp = i = 0; i < 3; i++) ftmp += Vin[i] * eigenvec[i+1][imaj];
	signE1 = (ftmp < 0.0) ? -1.0 : +1.0;

	for(ftmp = i = 0; i < 3; i++) ftmp += Vin[i] * TEND_vec[i];
	signTEND = (ftmp < 0.0) ? -1.0 : +1.0;


	for (i = 0; i < 3; i++) Vout[i] = f * eigenvec[i+1][imaj] * signE1 + (1. - f) * (1. - g) * Vin[i] + (1. - f) * g * TEND_vec[i] * signTEND;	

	/* Normalize Vout */
	for (mag = 0., i = 0; i < 3; i++) mag += Vout[i] * Vout[i];	
	for (i = 0; i < 3; i++) Vout[i] /= sqrt( mag );
	
	return 1;
}

/***************************************************************/
/*********************   RAVE algorithm   **********************/
/** Lazar et al., Proc. Intl. Soc. Mag. Reson. Med. 10 (2002) **/
/***************************************************************/

int RAVE(float *Vin, float alpha, int imaj, float **eigenvec, float *eigenval, float *Vout){
	int i, Y, Z;
	float stddevY, stddevZ, R2, R3, mag, ftmp, sign;
	static long int seed = -127;
	
	/*figure which are the y and z vectors */
	switch ( imaj ){
		case 1: Y = 2; Z = 3; break;
		case 2: Y = 1; Z = 3; break;
		case 3: Y = 1; Z = 2; break;
	}
	
	stddevY = alpha * sqrt( fabs (eigenval[Y]/eigenval[imaj]) );
	stddevZ = alpha * sqrt( fabs (eigenval[Z]/eigenval[imaj]) );


	R2 = gasdev(&seed) * stddevY;
	R3 = gasdev(&seed) * stddevZ;
	printf("R2: %10.4f R3: %10.4f\n",R2,R3);
	

	for (i = 0; i < 3; i++)
		Vout[i] =  eigenvec[i+1][imaj] + R2*eigenvec[i+1][Y] + R3*eigenvec[i+1][Z]; 

	/* Find sign between Vin and Vout */
	for(ftmp =0., i = 0; i < 3; i++) ftmp += Vin[i] * Vout[i];
	sign = (ftmp < 0.0) ? -1.0 : +1.0;
	
	/* Normalize Vout */
	for (mag = 0., i = 0 ;i < 3; i++) mag += Vout[i] * Vout[i];	
	for (i = 0; i < 3; i++) Vout[i] /= sqrt( mag );

	for(i=0; i<3; i++) Vout[i] = sign * Vout[i];

	return 1;
}


/***************************************************************/
/*********************   PICo algorithm   **********************/
/*********** Parker et al., JMRI, 18:242-254 (2003) ************/
/***************************************************************/

int PICo(float *Vin, float Asig, int imaj, float **eigenvec, float *eigenval, float *Vout){
	int i,j,X,Y;
	float phi, theta, mag, sigma, E1[3], ftmp, sign;
	static long int seed = -127;
	float alpha = 0.2;
	
	/*figure which are the y and z vectors */
	switch ( imaj ){
		case 1: X = 1; Y = 2; break;
		case 2: X = 0; Y = 2; break;
		case 3: X = 0; Y = 1; break;
	}

	sigma = 0.15 + (.85 / (1 +  exp (20 * (Asig - .25))));

	phi = ran1(&seed) * 2 * PI;
	theta = alpha * sigma * gasdev(&seed) * (PI / 2);

	E1[X] = sin(theta) * cos(phi);
	E1[Y] = sin(theta) * sin(phi);
	E1[imaj-1] = cos(theta);


	for (i=0; i<3; i++)
		for (Vout[i] = 0.,j=0; j<3; j++)
			Vout[i] += E1[j] * eigenvec[i+1][j+1];
	
	
	/* Find sign between Vin and Vout */
	for(ftmp =0., i = 0; i < 3; i++) ftmp += Vin[i] * Vout[i];
	sign = (ftmp < 0.0) ? -1.0 : +1.0;		

	/* Normalize Vout */
	for (mag = i = 0 ;i < 3; i++) mag += Vout[i] * Vout[i];	
	for (i = 0; i < 3; i++) Vout[i] /= sqrt( mag );

	for(i=0; i<3; i++) Vout[i] = sign * Vout[i];

	return 1;
}


int PICo1(float *Vin, float Asig, int imaj, float **eigenvec, float *eigenval, float *Vout){
	int i,j,X,Y;
	float phi, theta, mag, sigma, E1[3], ftmp, sign, LX, LY, R2;
	static long int seed = -127;
	float alpha = 0.2;
	
	/*figure which are the y and z vectors */
	switch ( imaj ){
		case 1: X = 2; Y = 3; break;
		case 2: X = 1; Y = 3; break;
		case 3: X = 1; Y = 2; break;
	}

	phi = ran1(&seed) * 2 * PI;
	
	LX = eigenval[X]/eigenval[imaj];
	LY = eigenval[Y]/eigenval[imaj];
	R2 = (LX * LX * LY * LY ) / (LX * LX * sin(phi) * sin(phi) + LY * LY * cos(phi) * cos(phi));  

	sigma = 0.15 + (.85 / (1 +  exp (20 * (0.8 - sqrt(R2) ))));

	theta = alpha * sigma * gasdev(&seed) * (PI / 2);

	E1[X] = sin(theta) * cos(phi);
	E1[Y] = sin(theta) * sin(phi);
	E1[imaj] = cos(theta);


	for (i=0; i<3; i++)
		for (Vout[i] = 0.,j=0; j<3; j++)
			Vout[i] += E1[j] * eigenvec[i+1][j+1];
	
	
	/* Find sign between Vin and Vout */
	for(ftmp =0., i = 0; i < 3; i++) ftmp += Vin[i] * Vout[i];
	sign = (ftmp < 0.0) ? -1.0 : +1.0;		

	/* Normalize Vout */
	for (mag = i = 0 ;i < 3; i++) mag += Vout[i] * Vout[i];	
	for (i = 0; i < 3; i++) Vout[i] /= sqrt( mag );

	for(i=0; i<3; i++) Vout[i] = sign * Vout[i];

	return 1;
}


/***************************************************************/
/*********************   PICo algorithm   **********************/
/*********** Behrens-like Method using actual error bars of the tensor ************/
/***************************************************************/

int BICo (float *Vin, float stdTheta, float stdPhi, int imaj, float **eigenvec, float *eigenval, float *Vout){
	int i,j,X,Y;
	float phi, theta, mag, sigma, E1[3], ftmp, sign;
	static long int seed = -127;
	float alpha = 1.0;
	
	/*figure which are the y and z vectors */
	switch ( imaj ){
		case 1: X = 1; Y = 2; break;
		case 2: X = 0; Y = 2; break;
		case 3: X = 0; Y = 1; break;
	}

	phi = stdPhi * gasdev(&seed) * alpha;
	theta = stdTheta * gasdev(&seed) * alpha;

	E1[X] = sin(theta) * cos(phi);
	E1[Y] = sin(theta) * sin(phi);
	E1[imaj-1] = cos(theta);


	for (i=0; i<3; i++)
		for (Vout[i] = 0.,j=0; j<3; j++)
			Vout[i] += E1[j] * eigenvec[i+1][j+1];
	
	
	/* Find sign between Vin and Vout */
	for(ftmp =0., i = 0; i < 3; i++) ftmp += Vin[i] * Vout[i];
	sign = (ftmp < 0.0) ? -1.0 : +1.0;		

	/* Normalize Vout */
	for (mag = i = 0 ;i < 3; i++) mag += Vout[i] * Vout[i];	
	for (i = 0; i < 3; i++) Vout[i] /= sqrt( mag );

	for(i=0; i<3; i++) Vout[i] = sign * Vout[i];

	return 1;
}

