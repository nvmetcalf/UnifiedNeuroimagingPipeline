#include <math.h>
/*$Header: /data/petsun4/data1/src_solaris/imglin/RCS/leaky_integrator.c,v 1.1 2012/08/16 03:22:29 avi Exp avi $*/
/*$Log: leaky_integrator.c,v $
 * Revision 1.1  2012/08/16  03:22:29  avi
 * Initial revision
 **/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define MAXL		256
#define L		512
#define N		10000	/* number of timepoints */

extern double	dnormal (void);

void errm () {
	fprintf (stderr, "memory allocation error\n");
	exit (-1);
}

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm ();
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm ();
	for (i = 1; i < n1; i++) a[i] = a[i - 1] + n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

double corrfac (double lambda) {
	double	A[6], q, t;
	int	k;
	A[0] =   0.143907463;	/* empirical 5th order polynomial fit */
	A[1] =   3.67965077;
	A[2] =  -9.55490456;
	A[3] =  15.8720961;
	A[4] = -13.7536817;
	A[5] =   4.62180455;

	if (lambda >= 1. || lambda <= 0.) return 1.;
	if (lambda > 0.02) {
		t = 1.;
		for (q = k = 0; k < 6; k++) {
			q += A[k]*t;
			t *= lambda;
		}
	} else {		/* empirical log-log fit */
		q = exp(0.257)*pow(lambda, 0.4783249);
	}
	return q;
}

int main (int argc, char *argv[]) {
	double	u[L], q, lambda = .1, rms;
	double	**x;
	long	iseed = 0;
	int	n = N;		/* size of sample */
	int	i, j, k;

	if (argc > 1) lambda = atof (argv[1]);
	if (argc > 2) {
		iseed  = atoi (argv[2]);
		srand48 (iseed);
	}

	x = calloc_double2 (L, N);
	for (j = 0; j < L; j++) x[j][0] = 0.0;
	for (i = 1; i < n; i++) {
		if (1) {
			for (j = 0; j < L; j++) x[j][i] = (1. - lambda)*x[j][i - 1] + lambda*dnormal();
		} else {
			for (j = 0; j < L; j++) x[j][i] = (1. - lambda)*x[j][i - 1] +        dnormal();
		}
		if (0) {for (j = 0; j < L; j++) printf ("%10.4f", x[j][i]);printf ("\n");}
	}
	q = 0.;
	for (i = 1000; i < N; i++) for (j = 0; j < L; j++) q += x[j][i]*x[j][i];
	rms = sqrt(q/((N - 1000)*L))/lambda;
	printf ("lambda = %.3f	rms = %.6f	1./rms = %.6f	corrfac = %.6f\n", lambda, rms, 1./rms, corrfac(lambda));

	free_double2 (x);
}
