c$Header: /data/petsun4/data1/src_solaris/imglin/RCS/gaussian.f,v 1.2 2012/09/17 23:17:45 avi Exp $
c$Log: gaussian.f,v $
c Revision 1.2  2012/09/17  23:17:45  avi
c linux compatible
c
c Revision 1.1  2008/08/26  21:46:50  avi
c Initial revision
c
      function gaussian(iflag)
c     returns a random N(0,1) value
c     avi snyder 01/01/87
      logical*4 init/.false./

      if(.not.init)then
        twopi=2.*atan2(0.,-1.)
        init=.true.
        iodd=1
      endif

      if(iodd.eq.1)then
        r=sqrt(-2.*alog(rand(iflag)))
        theta=twopi*(rand(iflag)-.5)
        gaussian=r*cos(theta)
        iodd=0
      else
        gaussian=r*sin(theta)
        iodd=1
      endif

      return
      end

      subroutine cgaussian(iflag,g)
      real*4 g
      g=gaussian(iflag)
      return
      end

      subroutine gautst
      parameter(n=10000)
      parameter(ns=100)
      real*4 x(n)

      a=rand(1)

      vt=0.
      at=0.
      do 4 j=1,ns
      do 2 i=1,n
    2 x(i)=gaussian(0)
      a=0.
      v=0.
      do 3 i=1,n
      a=a+x(i)
    3 v=v+x(i)**2
      a=a/float(n)
      v=(v-a**2)/float(n-1)
      at=at+a
      vt=vt+v
      write(*,"('j,iflag,mean,variance ',i6,2f10.4)")j,a,v
    4 continue
      vt=vt/float(ns)
      at=at/float(ns)
      write(*,"('j,iflag,mean,variance ',i6,2f10.4)")j,at,vt
      stop
      end
