      program peakchk
c $Header: /data/nil-bluearc/mintunf/jon/src/peakchk/RCS/peakchk.f,v 1.7 2011/04/29 14:14:16 jon Exp jon $

c------------------------------------------------------------c
c The purpose of this program is to read in a text file of four 
c columns of data, (frame, length, start time, and mean), find the 
c the peak value of the mean, the time corresponding to one half
c half the peak and finally the frame number corresponding to the 
c half peak time plus the time_interval.

c  Please Note: Start times larger than the start time of the last frame
c  plus the length of that frame will generate an error message. 
c  The user must check the data to validate.
c----------------------------------------------------------------------------c
  
      dimension frame(99),length(99),start(99),mean(99),datarray(99)
      character file_in*72,temp_arg*72,temp_arg2*72,string*72
      integer checkio
      integer ctr,row,i,i1,j,time_interval,total_time,frame
      integer startframe,lastframe
      
      real length,timetot,start,mean,datarray,half_peak
      real scanstarttime,time
      
      logical done,found,there
      
c----------------------------------------------------------------------------c
      write(*, "('# $Id: peakchk.f,v 1.7 2011/04/29 14:14:16 jon Exp jon $')")
           
c declare command line argument
      if (iargc().lt.2) then
	write(*,*)'Usage: peakchk dat_file total_time time_interval'
	write(*,*)'e.g.,  /home/usr/jon/bin/peakchk p5654ho1.glob.prm 60 8'
	write(*,*)'.prm file requires frame, length, start, and mean in four columns on the'
	write(*,*)'first line followed by four columns of data that start on the second line.'
	goto 1000
      end if

      call getarg(1,file_in)
      call getarg(2,temp_arg)
      call getarg(3,temp_arg2)

c use temp.txt as a temp file to write temp_arg
      open(1,file = 'temp.txt',status='unknown')
      write(1,*)temp_arg
      close(1)

c read temp_arg for total_time 
      open(2,file ='temp.txt',status='old')
      read(2,*),total_time
      close(2)
      
      print*,'# Total Time Interval=	',total_time

c clean up temp.txt file 
      string = 'rm temp.txt'
      call system (string)     
      
c use temp.txt as a temp file to write temp_arg2
      open(1,file = 'temp.txt',status='unknown')
      write(1,*)temp_arg2
      close(1)

c read temp_arg for total_time 
      open(2,file ='temp.txt',status='old')
      read(2,*),time_interval
      close(2)
            
      print*,'# Time Interval After Half-Peak= ',time_interval
      
c clean up temp.txt file 
      string = '/bin/rm temp.txt'
      call system (string)
c---------------------------------------------------------c
      done = .false.
      found = .false.
     
c check for file existence
 100  if(.not.done) then
          inquire (file=file_in, exist=there)
          if (.not.there) then
             print*,'ERROR File does not exist'
             print*,'Enter new file name or type QUIT to quit'
             read(*,150), file_in 
 150         format(A31)
             if(file_in(:4).eq.'QUIT') then
                done =.true.
                go to 100
             end if
           else
             done=.true.
             found=.true.
           end if
           go to 100
      end if
      
      if (found) then
            open (unit=10, file=file_in, iostat=checkio, status='unknown') 
      else
         print*,'ERROR file not found'
      end if 

c read dat file for header only
c	read(10,180)frame(1),length(1),start(1),mean(1)
 	read(10,180)start(1),mean(1),length(1),frame(1)
 180	format(4(A7))
c---------------------------------------------------------c
      i = 2
      ctr = 0
      timetot = 0
      checkio = 0
      
      do while(checkio.eq.0)
c         read(10,*,ERR = 275, iostat=checkio)frame(i),length(i),start(i),mean(i)
          read(10,*,ERR = 275, iostat=checkio)start(i),mean(i),length(i),frame(i)
          if(checkio .eq. 0) then
              datarray(i) = mean(i)
c              print*,checkio, frame(i), length(i), start(i), mean(i)
              ctr = ctr + 1
              i = i + 1
          end if
          if(checkio .gt. 0) then
             print*,'ERROR Reading File'
          end if
      end do
c---------------------------------------------------------c
 275  write(*,*)'# Total Input Frames= 	',ctr
      timetot = start(ctr+1) + length(ctr+1)
      print*,'# Total Time Of This Study=',timetot
c---------------------------------------------------------c
      if (time_interval  .gt. (timetot-total_time) .or. (time_interval.lt. 0))then
         print*,'ERROR time_interval ',time_interval,' out of range'
         goto 1000
      endif
      
      if (total_time .gt. (timetot+time_interval) .or. (total_time  .lt. 0)) then
         print*,'ERROR total_time ',total_time,' out of range'
         goto 1000
      endif
c---------------------------------------------------------c
c Bubble Sort 'datarray'

	 row = ctr + 1
	  
	 do 500 i=2,row
	    i1=i+1
	    do 400 j=i1,ctr
	        if (datarray(i) .ge. datarray(j)) then
	          continue
	        else
	            hold=datarray(i)
	            datarray(i)=datarray(j)
	            datarray(j)=hold
	        endif
 400	    continue
 500	 continue
c---------------------------------------------------------c 	 
c Spike? This code will check for one or more spikes (>20% rise).
c At this point datarray(2) is the largest value in the array.
c If a spike is found, mean(i) is changed to mean(i-1)+mean(i+1)/2,
c and the next largest value in datarray (j+1) is tested.

	 j = 2 
 550	 do 600 i=3,ctr	 
 	    if (mean(i) .eq. datarray(j)) then	    
 	        if ((mean(i)-mean(i-1)) .gt. (mean(i)*0.2)) then
 	           print*,'# Spike-Value=	',mean(i)
 	           mean(i) = (mean(i-1)+mean(i+1))/2
 	           j = j + 1
 	           goto 550
 	        else
c                  Peak Has Been Found
 	           print*,'# Peak-Value=		',mean(i)
 	           half_peak = mean(i)/2
 	           print*,'# Half-Peak-Value=	',half_peak
 	           goto 650
 	        endif
 	     endif 
 600	 continue
c--------------------------------------------------------------------------------c  
 650	 do 800 i=3,ctr
 	 
 	    if (mean(i) .gt. half_peak) then
	        
 	        if ((mean(i)-half_peak) .gt. (mean(i)-mean(i-1)/2)) then
 	           time = start(i)+time_interval
 	           print*,'# Half-Peak-Frame=	',frame(i)
 	        else
 	           time = start(i-1)+time_interval
 	           print*,'# Half-Peak-Frame=	',frame(i-1)
 	        endif
 	        
c               Find frame with the 'start time' closest to 'time'.

 	        do 700 j=i,ctr
 	           if (start(j) .gt. time)then
 	              if ((time).le.(start(j-1)+((start(j)-start(j-1))/2))) then
     			 startframe = frame(j-1)
     			 print*,'# Auto Integration Start Time=	',start(j-1)
     			 scanstarttime = start(j-1)
     			 time = start(j-1)+total_time
 	                 goto 825
 	              else
 	                 startframe = frame(j)
 	                 print*,'# Auto Integration Start Time=	',start(j)
 	                 scanstarttime = start(j)
			 time = start(j)+total_time
 	                 goto 825
 	              endif
 	           endif
 700            continue
 
 	     endif
 800	  continue
c--------------------------------------------------------------------------------c   
c 	 print*,'Calculate (Half-Peak time + ',time_interval,' Seconds)+total_time to final frame.'
c	 Note: how lastframe and Total Scan Time are determined to make sure
c              the last frame includes 'time'.

 825		found = .false.
		
  	        do 850 j=3,row
 	           if (start(j) .ge. time)then
 	                 lastframe = frame(j-1)
 	                 print*,'# Auto Integration Eval Time=	',start(j-1)
 	                 print*,'# Total Integration Time=	',start(j)-scanstarttime
 	                 found = .true.
 	                 goto 900
 	            endif
 850            continue
 
 900	  if (.not. found) then
             if(time .le. (start(row) + length(row))) then
                lastframe = row
                print*,'# Auto Integration Eval Time=	',start(row)
                print*,'# Total Integration Time=	',((start(row)+length(row))-scanstarttime)
             else
                print*,' '
                print*,'ERROR Please Check Data - Auto Integration Start time for summed frame length of',time,' could not be found'
             endif
          endif
          
          print*,' '
          
  	  print 950,'# Start Frame= ',startframe
 950	  format(A14,I3)
 
  	  print 975,'# Last Frame= ',lastframe
 975      format(A13,I3)  

 1000   end
