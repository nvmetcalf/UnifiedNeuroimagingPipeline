/*$Header$*/
/*$Log$*/
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>				/* R_OK */
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <float.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>
#include <librms.h>

#define CRIT		0.2	/* img2lmask inclusion threshold */
#define FBLUR		0.06	/* half frequency in reciprocal mm for gauss3diz */
#define FHALF		0.02	/* half frequency in reciprocal mm for img2lmask */
#define MAXL		256	/* maximum string length */
#define MAXR		160	/* maximum number of runs */
#define MAXF		2048	/* expected maximum number of frames per fMRI run */

/*************/
/* mode word */
/*************/
#define ENABLE		1
#define ALIGN3D		2
#define STRETCH		4
#define GRADCOMP	8
#define CROSSMODAL	256
#define QUIET		512
#define WRAP		1024
#define ENDSLICE	2048

/*************/
/* externals */
/*************/
extern void	alignmiz_ (int *nx, int *ny, int *nz, float *img1, float *img2, float *d2img2, int *mask,
			float *param, float *s4, float *mmppix, int *mode, float *err);			/* frmsfmri.f */ 
extern void	splinez_ (float *imag, int *nx, int *ny, int *nz, float *d2zi, float *scratch);		/* splinexyz.f */

void errd (char *program, char *file0, char *file1) {
	fprintf (stderr, "%s: %s %s dimension mismatch\n", program, file0, file1);
	exit (-1);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

/********************/
/* global variables */
/********************/
static float	*d2zi, *scratch;	/* computed second partials for spline interpolation */
static float	*img2;				/* unaligned frame */
static float	*imgf;				/* reference frame */
static float	*imgr;				/* aligned frame */
static float	*imgs;				/* scratch frame */
static int	*mask;				/* region in which to evaulate and compute realignment */
static float	crit = CRIT;			/* img2lmask inclusion threshold */
static float	fblur = FBLUR;			/* half frequency in reciprocal mm for gauss3diz */
static float	fhalf = FHALF;			/* half frequency in reciprocal mm for img2lmask */

void	filter (int threeD, float *imgs, int *imgdim, float *mmppix, float *pfblur);		/* below */
void	WintraT (FILE *fp, int frame, float *totalT, float* tp);				/* below */

static char rcsid[] = "$Id$";
int main (int argc, char *argv[]) {
	FILE		*imgfp, *mskfp, *avgfp, *matfp, *outfp;
	char		imgroot[MAXR][MAXL], mskroot[MAXR][MAXL];
	char		format[MAXR][MAXL];		/* anat/functional frame format */
	int		nfram[MAXR];			/* frames per run */
	int		matstat[MAXR];			/* set if mat file exists */
	int		orient[MAXR];			/* input orientation */
	int		isbig[MAXR], msbig[MAXR];	/* endian state of (4dfp) stacks and corresponding masks */
	char		imgfile[MAXL];
	char		matfile[MAXL];

	float		*rp, *intraR;			/* alignment parameters */
	float		*intraS;			/* intensity scaling parameters */
	float		intraT[16], totalT[16];		/* t4 matrices */
	float		*sp, *tp;				/* intensity scaling parameters */
	float		up[4] = {1., 0., 0., 0.};		/* unit intensity scaling parameters */

	float		voxdim[3], mmppix[3];
	int		imgdim[4], mskdim[4];
	int		mode = ENABLE | ALIGN3D | ENDSLICE | QUIET;	/* ordinary realignment mode */
	int		modef;						/* cross-modality realignment mode */
	int 		base_frame;					/* used as intraR pointer */
	int		nrun = 0, nframtot = 0;
	int		xdim, ydim, zdim, vdim;

/*********/
/* flags */
/*********/
	int		debug = 0;

/***********/
/* utility */
/***********/
	float		err;
	int		c, i, j, k, m, ierr;
	char		program[MAXL], *ptr, command[MAXL], *srgv[MAXL];

	fprintf (stdout, "%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'd': debug++;			break;
				case 'c': mode |= CROSSMODAL;		break;
				case 'g': mode |= GRADCOMP;		break;
				case 'p': mode &= ~ALIGN3D;		break;
				case 's': mode |= STRETCH;		break;
				case 'w': mode |= WRAP; 		break;
				case 'b': fblur = atof (ptr);		*ptr = '\0'; break;
			}
		} else {
			getroot (argv[i], imgroot[nrun++]);
		}	
	}

	if (!nrun) {
		fprintf (stderr, "Usage:\t%s <run_4dfp>\n", program);
		fprintf (stderr, "	option\n");
		fprintf (stderr, "	-d	debug mode\n");
		fprintf (stderr, "	-g	enable linear intensity gradient compensation\n");
		fprintf (stderr, "	-c	use cross-modal registration always\n");
		fprintf (stderr, "	-b<flt>	specify pre-blur in reciprocal mm (default=%.2f)\n", FBLUR);
		fprintf (stderr, "	-s	enable stretch\n");
		fprintf (stderr, "	-w	enable wrap addressing\n");
		exit (1);
	}

/**************************/
/* begin zeroth runs loop */
/**************************/
	for (i = 0;  i < nrun; i++) {
		sprintf (imgfile, "%s.4dfp.img", imgroot[i]);
		if (get_4dfp_dimoe (imgfile, imgdim, voxdim, orient + i, isbig + i)) errr (program, imgfile);
		if (!i) {
			xdim		= imgdim[0];
			ydim		= imgdim[1];
			zdim		= imgdim[2];
			mmppix[0]	= voxdim[0];
			mmppix[1]	= voxdim[1];
			mmppix[2]	= voxdim[2];
			vdim		= xdim * ydim * zdim;
		} else {
			ierr = (imgdim[0] != xdim || imgdim[1] != ydim || imgdim[2] != zdim);
			for (k = 0; k < 3; k++) ierr |= (fabs (mmppix[k] - voxdim[k]) > 1.e-4);
			ierr |= orient[i] - orient[0];
			if (ierr) errd (program, imgroot[0], imgroot[i]);
		}
		nframtot += (nfram[i] = imgdim[3]);
		sprintf (matfile, "%s_xr3d.mat", imgroot[i]);
	}

/************************/
/* end zeroth runs loop */
/************************/
	if (!(intraR	= (float *) calloc (nframtot * 12, sizeof (float)))
	||  !(intraS	= (float *) calloc (nframtot * 4,  sizeof (float)))
	||  !(scratch	= (float *) malloc (zdim * zdim * sizeof (float)))
	||  !(d2zi	= (float *) calloc (vdim,  sizeof (float)))
	||  !(imgf	= (float *) malloc (vdim * sizeof (float)))
	||  !(img2	= (float *) malloc (vdim * sizeof (float)))
	||  !(imgr	= (float *) malloc (vdim * sizeof (float)))
	||  !(imgs	= (float *) malloc (vdim * sizeof (float)))
	||  !(mask	= (int *)   malloc (vdim * sizeof (int)))) errm (program);

	base_frame = 0;
	for (i = 0; i < nrun; i++) {
		sprintf (matfile, "%s_xr3d.mat", imgroot[i]);
		sprintf (imgfile, "%s.4dfp.img", imgroot[i]);
		fprintf (stdout, "Reading: %s\n", imgfile);
		if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);

/*******************************/
/* prepare to self-align run i */
/*******************************/
		if (fseek (imgfp, (long) 0 * vdim * sizeof (float), SEEK_SET)
		||  gread ((char *) imgf, sizeof (float), vdim, imgfp, isbig[i])) errr (program, imgfile);

/**********************/
/* prepare run i mask */
/**********************/
		img2lmask (&xdim, &ydim, &zdim, imgf, mask, mmppix, &fhalf, &crit);

/**************************/
/* filter reference frame */
/**************************/
		filter (mode, imgf, imgdim, mmppix, &fblur);

/***************************/
/* align functional frames */ 
/***************************/
		printf ("Computing: %s to frame %d intra-run alignment\n", imgroot[i], 1);
		for (j = 0; j < nfram[i]; j++) {
			printf ("frame %4d ", j + 1); fflush (stdout);
			rp	= intraR + (base_frame + j) * 12;
			sp	= intraS + (base_frame + j) * 4;
			if (fseek (imgfp, (long) j * vdim * sizeof (float), SEEK_SET)
			||  gread ((char *) img2, sizeof (float), vdim, imgfp, isbig[i])) errr (program, imgfile);

			for (k = 0; k < vdim; k++) imgs[k] = img2[k];
			filter (mode, imgs, imgdim, mmppix, &fblur);
			if (mode & ALIGN3D) splinez_ (imgs, &xdim, &ydim, &zdim, d2zi, scratch);
			alignmiz_ (&xdim, &ydim, &zdim, imgf, imgs, d2zi, mask, rp, sp, mmppix, &mode, &err);
			for (k = 0; k < 12; k++) if (isnan (rp[k])) goto ERRC;
		}

/*****************/
/* save mat file */
/*****************/
		if (!(matfp = fopen (matfile, "w"))) errw (program, matfile);
		fprintf (stdout, "Writing: %s\n", matfile);
		for (j = 0; j < nfram[i]; j++) {
			rp = intraR + (base_frame + j) * 12;
			sp = intraS + (base_frame + j) * 4;
			param2warp_ (&mode, rp, totalT);
			WintraT (matfp, j, totalT, sp);
		}
		fclose (matfp);

LOOP:		base_frame	+= nfram[i];
	}
/***********************/
/* end main runs loops */
/***********************/

	free (intraR); free (intraS);
	free (scratch); free (d2zi);
	free (imgs); free (img2); free (imgr); free (imgf);
	free (mask);

	exit (0);
ERRC:	fprintf (stderr, "%s: convergence failed\n", program);		exit (-1);
}

void filter (int mode, float *imgs, int *imgdim, float *mmppix, float *pfblur) {
	extern void	gauss3diz (float *imag, int *pnx, int *pny, int *pnz, float *mmppix, float *pfhalf);	 /* gauss3diz.c */
	extern void	gauss2diz (float *imag, int *pnx, int *pny, int *pnz, float *mmppix, float *pfhalf);	 /* gauss2diz.c */

	if (mode & ALIGN3D) {
		gauss3diz (imgs, imgdim + 0, imgdim + 1, imgdim + 2, mmppix, pfblur);
	} else {
		gauss2diz (imgs, imgdim + 0, imgdim + 1, imgdim + 2, mmppix, pfblur);
	}
}

void WintraT (FILE *fp, int frame, float *totalT, float* tp) {
	int		k;

	fprintf (fp, "t4 frame %d\n", frame + 1);
	for (k = 0; k < 4; k++) fprintf (fp, "%10.6f%10.6f%10.6f%10.4f\n",
		totalT[0 + k], totalT[4 + k], totalT[8 + k], totalT[12 + k]);
	fprintf (fp, "s4 frame %d\n", frame + 1);
	fprintf (fp, "%10.6f%10.6f%10.6f%10.6f\n", tp[0], tp[1], tp[2], tp[3]);
}
