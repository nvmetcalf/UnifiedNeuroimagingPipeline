/*$Header: /home/usr/shimonyj/vto4dfp/RCS/vto4dfp.c,v 1.17 2010/02/12 06:35:10 avi Exp shimonyj $*/
/*$Log: vto4dfp.c,v $
 * Revision 1.17  2010/02/12  06:35:10  avi
 * re-code slice gap printrec to operate correctly on linux
 *
 * Revision 1.16  2010/02/12  05:45:11  avi
 * remove all declarations of type long to obtain 64-bit machine compatibility
 *
 * Revision 1.15  2010/02/12  04:13:22  avi
 * compiles and runs correctly on both sparc and 32-bit x86 machines
 *
 * Revision 1.14  2009/05/30  01:54:52  avi
 * debugging printf statements added
 *
 * Revision 1.13  2008/01/16  04:50:26  adrian
 * change procpar max line length to 4096
 *
 * Revision 1.12  2007/03/28  07:28:42  avi
 * restructure global header according to VnmrJ documentation
 * enable use of float or int fid data
 *
 * Revision 1.11  2006/12/24  06:33:12  avi
 * Solaris 10
 *
 * Revision 1.10  2006/02/20  07:59:42  avi
 * optionally correct reversed phase of odd echos in multiecho data
 *
 * Revision 1.9  2006/02/20  06:39:35  avi
 * typo
 *
 * Revision 1.8  2006/02/20  06:36:48  avi
 * clarify use of global vs. block headers
 *
 * Revision 1.7  2006/02/20  05:47:48  avi
 * accommodate multi-echo data
 *
 * Revision 1.6  2006/02/10  02:11:09  avi
 * correct voxel size output to ifh in interpolated case
 *
 * Revision 1.5  2006/02/02  22:02:37  adrian
 * corrected vmax and error in srgv array length
 *
 * Revision 1.4  2005/12/23  04:20:32  avi
 * option -m (scale output voxel size)
 * correctly compute slice center-to-center distance and report slice gap
 * compute maximum scale magnitude
 *
 * Revision 1.3  2005/12/22  06:34:14  avi
 * cleaning
 * option -o (specify 4dfp outroot)
 * option -D (suppress k-space DC offset removal)
 * option -c (output intensity scale)
 * better usage
 *
 * Revision 1.2  2005/12/21  23:59:33  adrian
 * increased size of MAXL
 *
 * Revision 1.1  2005/12/13  23:34:56  avi
 * Initial revision
 **/
/*******************************************************/
/* program to read raw varian data and convert to 4dfp */
/*******************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <util.h>
#include <Getifh.h>
#include <endianio.h>
#include <rec.h>

#define BLCK_HDR_SIZE	28
#define MAXL		256	/* max file name length */
#define MAXS		4096	/* max procpar line length */
#define OUTROOT		"fid"

/**************/
/* prototypes */
/**************/
int	shift_index (int indx, int n);				/* below */
int	power2 (int n);						/* below */
int	read_procpar (char *procpar_file, float *procpar);	/* below */

void errx (char* program, char* filespc) {
	fprintf (stderr, "%s: %s format error\n", program, filespc);
	exit (-1);
}

int split (char *string, char *srgv[], int maxp) {
	int	i, m;
	char	*ptr;

	i = m = 0;
	while (m < maxp) {
		while (!isgraph ((int) string[i]) && string[i]) i++;
		if (!string[i]) break;
		srgv[m++] = string + i;
		while (isgraph ((int) string[i])) i++;
		if (!string[i]) break;
		string[i++] = '\0';
	}
	return m;
}

typedef struct {
	int	jndex;
	float	position;
} SLICEPOS;

static int sliceorder (const void *ptri, const void *ptrj) {
	SLICEPOS	*i, *j;

	i = (SLICEPOS *) ptri;
	j = (SLICEPOS *) ptrj;
	return (j->position < i->position) ? 1 : -1;
}

/********************/
/* global variables */
/********************/
static char	program[MAXL];
static char	rcsid[] = "$Id: vto4dfp.c,v 1.17 2010/02/12 06:35:10 avi Exp shimonyj $";
static int	status = 0;

struct DATAFILEHEAD {
	int nblocks;		/* number of blocks in file */
	int ntraces;		/* number of traces per block */
	int np;			/* number of elements per trace */
	int ebytes;		/* number of bytes per element */
	int tbytes;		/* number of bytes per trace */
	int bbytes;		/* number of bytes per block */
	short vers_id;		/* software version, file_id status bits */
	short status;		/* status of whole file */
	int nbheaders;		/* number of block headers per block */
};

void swab_DATAFILEHEAD (struct DATAFILEHEAD *ptr) {
	swab4 ((char *) &ptr->nblocks);
	swab4 ((char *) &ptr->ntraces);
	swab4 ((char *) &ptr->np);
	swab4 ((char *) &ptr->ebytes);
	swab4 ((char *) &ptr->tbytes);
	swab4 ((char *) &ptr->bbytes);
	swab2 ((char *) &ptr->vers_id);
	swab2 ((char *) &ptr->status);
	swab4 ((char *) &ptr->nbheaders);
}

int main (int argc, char *argv[]) {
/************************************************/
/* datafile header structure taken VnmrJ manual */
/************************************************/
	struct DATAFILEHEAD datafilehead;
	int		si, sj;
	int		*blck;
	float		*fblck;
	int		phase_num, freq_num, img_sz, slice_num, eslice_num, vol_num, necho, iecho;
	int		phase_num2, freq_num2, img_sz2, num_img;
	float		procpar[8], *img, *mag, *slice, vmax, *phase;
	float		imag, real, sumi, sumr, cscale = 1.0, mscale = 1.0;
	char		fiddir[MAXL], proc_file[MAXL], fid_file[MAXL], outfile[MAXL], outroot[MAXL] = OUTROOT;
	char		hdr[BLCK_HDR_SIZE];	/* block header */
	SLICEPOS	*slicepos;
	FILE		*fp, *procfp;
	unsigned int	*nn, ivol, islc;

/*********************/
/* 4dfp dimensioning */
/*********************/
	int		imgdim[4], orient;
	float		voxdim[3];
	int		isbig = 1;	/* assume input binary data is bigendian */
	char		control = '\0';

/***********/
/* utility */
/***********/
	char		*str, command[MAXS], *srgv[MAXL];
	int		c, i, ii, j, k, l, m;
	double		q;

/*********/
/* flags */
/*********/
	int		cpmg_flag = 0;
	int		interp_flg = 0;
	int		noDC = 1;
	int		verbose = 0;
	int		phase_flag = 0;
	int		S_FLOAT;

	printf ("%s\n", rcsid);
	if (!(str = (char *)strrchr (argv[0], '/'))) str = argv[0]; else str++;
	strcpy (program, str);

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); str = command;
			while (c = *str++) switch (c) {
				case 'o': getroot (str, outroot);	*str = '\0'; break;
				case 'c': cscale = atof (str);		*str = '\0'; break;
				case 'm': mscale = atof (str);		*str = '\0'; break;
				case '@': control = *str++;		*str = '\0'; break;
				case 'I': interp_flg++;			break;
				case 'D': noDC = 0;			break;
				case 'F': cpmg_flag++;			break;
				case 'v': verbose++;			break;
				case 'p': phase_flag++;			break;
			}
		} else switch (k) {
			case 0:	strcpy (fiddir, argv[i]);		k++; break;
		}	
	} 
	if (k < 1) {
		printf ("Usage:\t%s <varian file path>\n", program);
		printf ("e.g.,\t%s /home/usr/shimonyj/vto4dfp/hard_010703 -odwi_010703\n", program);
		printf ("\toption\n");
		printf ("\t-v\tverbose mode\n");
		printf ("\t-D\tsuppress subtraction of k-space DC offset\n");
		printf ("\t-I\tperform Fourier interpolation; output voxel count will be quadrupled\n");
		printf ("\t-F\tphase reverse odd echos in multi-echo data\n");
		printf ("\t-p\toutput phase image in a separate file\n");
		printf ("\t-o<str>\tspecify 4dfp outroot (default=\"%s\")\n", OUTROOT);
		printf ("\t-c<flt>\tintensity scale output (mag) image by specified constant\n");
		printf ("\t-m<flt>\tscale voxel dimensions by specified constant\n");
		printf ("\t-@<b|l>\toutput big or little endian (default CPU endian)\n");
		printf ("N.B.:	%s expects <varian file path> to contain files \"fid\" and \"procpar\"\n", program);
		exit (1);
	}

/*******************************/
/* create file names from root */
/*******************************/
	sprintf (proc_file, "%s/procpar", fiddir);
	sprintf (fid_file,  "%s/fid",     fiddir);

/*************************/
/* read the procpar file */
/*************************/
	printf ("Reading: %s\n", proc_file);
	i = read_procpar (proc_file, procpar);
	slice_num = procpar[6];

/**************************************************/
/* get slice ordering and necho from procpar file */
/**************************************************/
	if (!(procfp = fopen (proc_file, "r"))) errr (program, proc_file);

	while (fgets (command, MAXS, procfp)) {
		if (!(m = split (command, srgv, MAXL))) continue;
		if (0) {
		} else if (!strcmp (srgv[0], "nf")) {
			fgets (command, MAXS, procfp);
			split (command, srgv, MAXL) - 1;
			k = atoi (srgv[1]);	/* recover nf = necho*slice_num */
			printf ("nf=%d slice_num=%d\n", k, slice_num);
			if (k % slice_num) errx (program, proc_file);
			necho = k/slice_num;
		} else if (!strcmp (srgv[0], "pss")) {
			fgets (command, MAXS, procfp);
			split (command, srgv, MAXL) - 1;
			k = atoi (srgv[0]);
			if (k != slice_num) errx (program, proc_file);
			if (!(slicepos = (SLICEPOS *) malloc (slice_num * sizeof (SLICEPOS)))) errm (program);
			for (k = 0; k < slice_num; k++) {
				slicepos[k].jndex = k;
				slicepos[k].position = atof (srgv[k + 1]);
			}

		}
	}

	fclose (procfp);
	if (verbose) printf ("necho=%d\n", necho);
	if (verbose) {
		printf ("before sort\n");
		for (k = 0; k < slice_num; k++) printf ("%10d%10.4f\n", slicepos[k].jndex, slicepos[k].position);
	}
	qsort ((void *) slicepos, slice_num, sizeof (SLICEPOS), sliceorder);
	if (verbose) {
		printf ("after sort\n");
		for (k = 0; k < slice_num; k++) printf ("%10d%10.4f\n", slicepos[k].jndex, slicepos[k].position);
	}
/***************************************************/
/* determine slice center-to-center distance in mm */
/***************************************************/
	q = slicepos[1].position - slicepos[0].position;
	for (k = 2; k < slice_num; k++) {
		if (fabs(1. - (slicepos[k].position - slicepos[k - 1].position)/q) > 1.e-5) {
			fprintf (stderr, "%s warning: slices are not evenly spaced\n", program);
		}
	}
	voxdim[2] = mscale*10.0*q;

/**************************/
/* plug in procpar values */
/**************************/
	voxdim[0] = mscale*procpar[0]*10.0/procpar[3];
	voxdim[1] = mscale*procpar[1]*10.0/procpar[4];
	freq_num	= (int) procpar[3];
	phase_num	= (int) procpar[4];
	orient		= (int) procpar[5];
	vol_num	= (int) procpar[7]/phase_num;

/********************************************/
/* calc the number of images and image size */
/********************************************/
	img_sz		= phase_num*freq_num;
	eslice_num	= necho*slice_num;
	num_img		= eslice_num*vol_num;	/* total number reconstructed 2D slices */

/*************************/
/* read the fid file hdr */
/*************************/
	if (!(fp = fopen (fid_file, "rb"))) errr (program, fid_file);	
	if (fread (&datafilehead, sizeof (struct DATAFILEHEAD), 1, fp) != 1) errr (program, fid_file);
	if (!CPU_is_bigendian ()) swab_DATAFILEHEAD (&datafilehead);
	if (verbose) {
		printf ("global data header\n");
		printf ("nblocks\t	%d\n", datafilehead.nblocks);
		printf ("ntraces\t	%d\n", datafilehead.ntraces);
		printf ("np		%d\n", datafilehead.np);
		printf ("ebytes		%d\n", datafilehead.ebytes);
		printf ("tbytes		%d\n", datafilehead.tbytes);
		printf ("bbytes		%d\n", datafilehead.bbytes);
		printf ("vers_id\t	%d\n", datafilehead.vers_id);
		printf ("status		%d\n", datafilehead.status);
		printf ("nbheaders	%d\n", datafilehead.nbheaders);
	}

/****************************/
/* error checking on header */
/****************************/
	if (datafilehead.nblocks != procpar[7])			printf ("conflict number of data blocks\n"); 
	if (datafilehead.ntraces != eslice_num)			printf ("conflict number traces per block\n");
	if (datafilehead.np != 2*freq_num)			printf ("conflict number freq encode elements\n");
	if (datafilehead.ebytes != 4)				printf ("number of bytes per element not 4\n");
	if (datafilehead.tbytes != 8*freq_num)			printf ("conflict number bytes per trace\n");
	if (datafilehead.bbytes != 8*freq_num*eslice_num + 28)	printf ("conflict number bytes per block\n");
	if (datafilehead.nbheaders != 1)			printf ("number of block headers != 1\n");

	if ((datafilehead.status & 0x3) != 1) {
		fprintf (stderr, "%s not a valid fid data file\n", fid_file);
		exit (-1);
	}
	S_FLOAT = datafilehead.status & 0x8;
	if (S_FLOAT) printf ("%s is float\n", fid_file);

/*********************************/
/* allocate memory original data */
/*********************************/
	if (!(blck =  (int *)   malloc (2*freq_num * sizeof (int))))   errm (program);
	if (!(fblck = (float *) malloc (2*freq_num * sizeof (float)))) errm (program);
	nn = lvector(1,2);
	img = vector(1,2*num_img*img_sz);

/************************/
/* check for power of 2 */
/************************/
	phase_num2 = power2(phase_num);
	freq_num2 = power2(freq_num);
	if (interp_flg) {
		phase_num2 *= 2; freq_num2 *= 2;
		voxdim[0] /= 2;  voxdim[1] /= 2;
	}
	img_sz2 = phase_num2*freq_num2;

/***************/
/* print stats */
/***************/
	printf ("dimensions: %d %d %d %d\n", freq_num, phase_num, slice_num, necho*vol_num);
	printf ("scaled voxel size (mm): %f %f %f\n", voxdim[0], voxdim[1], voxdim[2]);
	printf ("orient: %d (2: axial [varian cor]; 3: coronal [varian trans]; 4: sagittal)\n", orient);
	
/************************************/
/* allocate memory zero filled data */
/************************************/
	mag	= vector(0,num_img*img_sz2);
	phase	= vector(0,num_img*img_sz2);
	slice	= vector(1,2*img_sz2);
	nn[1]	= phase_num2;
	nn[2]	= freq_num2;
	if (verbose) printf ("size zero fill: %d %d\n", freq_num2, phase_num2, slice_num, vol_num);
	
/***********************************************/
/* loop to read the blocks = num_img*phase_num */
/***********************************************/
	for (i = 0; i < phase_num; i++)	{	/* loop on phase encodes */
	for (k = 0; k < vol_num; k++) {		/* loop on [diffusion] volumes */
		fread (hdr, 1, BLCK_HDR_SIZE, fp);		/* skip over block hdr */
		for (l = 0; l < slice_num; l++) {		/* loop on slices */
		for (iecho = 0; iecho < necho; iecho++) {	/* loop on echo */
		if (S_FLOAT) {
			if (gread ((char *) fblck, sizeof (float), freq_num*2, fp, isbig)) errr (program, fid_file);
		} else {
			if (gread ((char *)  blck, sizeof (int),   freq_num*2, fp, isbig)) errr (program, fid_file);
			for (j = 0; j < 2*freq_num; j++) fblck[j] = (float) blck[j];
		}
/*************************/
/* reorder phase encodes */
/*************************/
			ii = (cpmg_flag && iecho % 2) ? phase_num - 1 - i : i;
			for (j = 0; j < freq_num; j++) {
				img[(k*eslice_num + iecho*slice_num + l)*2*img_sz + ii*2*freq_num + 2*j+1] = fblck[2*j];
				img[(k*eslice_num + iecho*slice_num + l)*2*img_sz + ii*2*freq_num + 2*j+2] = fblck[2*j+1];
			}
		}}
	}}
	fclose(fp);

/****************************************/
/* fourier the data and store magnitude */
/****************************************/
	for (vmax = k = 0; k < num_img; k++) {	/* loop over slices */

/******************************************/
/* init slice array for case of zero fill */
/******************************************/
		for (i=1; i<=2*img_sz2; i++) slice[i] = 0.0;

/*********************/
/* put data in slice */
/*********************/
		sumr = sumi = 0.0;
		for (i=0; i<phase_num; i++) for (j=0; j<freq_num; j++) {
			si = i + (phase_num2 - phase_num)/2;
			sj = j + (freq_num2 - freq_num)/2;
			slice[si*2*freq_num2+2*sj+1] = real = img[k*2*img_sz+i*2*freq_num+2*j+1];
			slice[si*2*freq_num2+2*sj+2] = imag = img[k*2*img_sz+i*2*freq_num+2*j+2]; 
			sumr += real; sumi += imag;
		}
		sumr /= (float) img_sz2;
		sumi /= (float) img_sz2;

/*************************/
/* subtract DC component */
/*************************/
		if (noDC) for (i=1; i<=2*img_sz2; i+=2) {
			slice[i] -= sumr;
			slice[i+1] -= sumi;
		}

		fourn(slice, nn, 2, -1);	/* FOURIER */
/*************************/
/* store magnitude image */
/*************************/
		for (i = 0; i < phase_num2; i++) {
			si = shift_index(i, phase_num2);
			for (j = 0; j < freq_num2; j++) {
				sj = shift_index(j, freq_num2);
				sj = freq_num2 - sj - 1;
				l = i*freq_num2 + j;	/* old indx from fft */
				q = mag[k*img_sz2+sj*phase_num2+si] = cscale*sqrt(
				slice[2*l+1]*slice[2*l+1] + slice[2*l+2]*slice[2*l+2])/img_sz2;
				if (q > vmax) vmax = q;
				if (phase_flag) 
					phase[k*img_sz2+sj*phase_num2+si] = atan2(slice[2*l+2],slice[2*l+1]);
			}
		}
	}
	
/*********************/
/* output 4dfp image */
/*********************/
	sprintf (outfile, "%s.4dfp.img", outroot);
	printf ("Writing: %s\n", outfile);
	if ((fp = fopen (outfile, "wb")) == NULL) errw (program, outfile);
	for (ivol = 0; ivol < vol_num; ivol++) {
	for (iecho = 0; iecho < necho; iecho++) {
		for (islc = 0; islc < slice_num; islc++) {
			k = slicepos[islc].jndex;
			j = ((ivol*necho + iecho)*slice_num + k)*img_sz2;
			if (ewrite (mag + j, img_sz2, control, fp)) errw (program, outfile);
		}
	}}
	fclose (fp);


/*********************/
/* output 4dfp phase */
/*********************/
	if (phase_flag) {

		sprintf (outfile, "%s.phase.4dfp.img", outroot);
		printf ("Writing: %s\n", outfile);
		if ((fp = fopen (outfile, "wb")) == NULL) errw (program, outfile);
		for (ivol = 0; ivol < vol_num; ivol++) {
		for (iecho = 0; iecho < necho; iecho++) {
			for (islc = 0; islc < slice_num; islc++) {
				k = slicepos[islc].jndex;
				j = ((ivol*necho + iecho)*slice_num + k)*img_sz2;
				if (ewrite (phase + j, img_sz2, control, fp)) errw (program, outfile);
			}
		}}
		fclose (fp);

	}



/************************************/
/* write ifh and create analyze hdr */
/************************************/
	imgdim[3] = necho*vol_num;
	imgdim[2] = slice_num;
	imgdim[1] = freq_num2;
	imgdim[0] = phase_num2;
	writeifhe (program, outroot, imgdim, voxdim, orient, control);
	sprintf (command, "ifh2hdr %s -r%d", outroot, (int) (vmax + 0.5)); status |= system (command);
	sprintf (command, "cat %s.4dfp.ifh", outroot); status |= system (command);

/*******************/
/* create rec file */
/*******************/
	startrece (outfile, argc, argv, rcsid, control);
	sprintf (command, "Output voxel dimensions scaled by %10.4f\n", mscale); printrec (command);
	sprintf (command, "Output intensities      scaled by %10.4f\n", cscale); printrec (command);
	sprintf (command, "Maximum magnitude                 %10.4f\n", vmax);   printrec (command);
	q = voxdim[2] - mscale*procpar[2];
	sprintf (command, "Scaled slice gap = %.4f mm (%.4f percent gap)\n", q, 100.0*(q/voxdim[2]));
		printrec (command);
	endrec ();
	sprintf (command, "brec %s", outfile); system (command);

/********/
/* free */
/********/
	free_vector(slice,1,2*img_sz2);
	free_vector(mag,0,num_img*img_sz2);
	free_vector(phase,0,num_img*img_sz2);
	free_vector(img,1,2*num_img*img_sz);
	free_lvector(nn,1,2);
	free (blck); free (fblck);
	free (slicepos);
	exit (status);
}

/***************************************************************/
/* return shifted index of single dimension array for fft work */
/* assume n is even and indexing is from 0 to n-1	       */
/***************************************************************/
int shift_index (int indx, int n)
{
	if (indx >= 0 && indx < n/2) return (indx + n/2);
	else if (indx >= n/2 && indx < n) return (indx - n/2);
	else printf ("index_shift: bad index\n");
	return (-1);
}

/*************************************************************/
/* return the power of 2 that is equal or greater than input */
/*************************************************************/
int power2 (int n)
{
	int i = 1;

	while (i < n) i *= 2;
	return (i);
}

int read_procpar (char *procpar_file, float *procpar) {
/*
	procpar[0] = fov in read out 
	procpar[1] = fov in phase encode
	procpar[2] = slice thickness
	procpar[3] = number points in read out
	procpar[4] = number points in phase encode
	procpar[5] = orientation 2-axial 3-coronal 4-sagittal
	procpar[6] = number of slices
	procpar[7] = array dim in block
*/
	int	i, m;
	int	flro,flpe,fthk,fnp,fnv,forient,fns,farraydim;
	FILE	*fp;
	char	string[MAXS], *srgv[MAXL], *ptr;

/*********************/
/* open procpar file */
/*********************/
	if (!(fp = fopen (procpar_file, "r"))) errr (program, procpar_file);
	flro = flpe = fthk = fnp = fnv = forient = fns = farraydim = 0;
	while (fgets (string, MAXS, fp)) {
		if (!(m = split (string, srgv, MAXL))) continue;
		if (0) for (i = 0; i < m; i++) printf ("%d %s\n", i, srgv[i]);

		if (flro) {
			sscanf(srgv[1],"%f",procpar);
			flro = 0;
		}
		if (flpe) {
			sscanf(srgv[1],"%f",procpar+1);
			flpe = 0;
		}
		if (fthk) {
			sscanf(srgv[1],"%f",procpar+2);
			fthk = 0;
		}
		if (fnp) {
			sscanf(srgv[1],"%d",&i);
			procpar[3] = (float) i/2; /* return number of complex numbers */
			fnp = 0;
		}
		if (fnv) {
			sscanf(srgv[1],"%d",&i);
			procpar[4] = (float) i;
			fnv = 0;
		}
		if (forient) {
			     if (!strcmp(srgv[1], "\"trans\"")) procpar[5] = 3.0;
			else if (!strcmp(srgv[1], "\"cor\""))   procpar[5] = 2.0;
			else if (!strcmp(srgv[1], "\"sag\""))   procpar[5] = 4.0;
			else procpar[5] = 2.0;
			forient = 0;
		}
		if (fns) {
			sscanf(srgv[1],"%d",&i);
			procpar[6] = (float) i;
			fns = 0;
		}
		if (farraydim) {
			sscanf(srgv[1],"%d",&i);
			procpar[7] = (float) i;
			farraydim = 0;
		}

		if (!strcmp(srgv[0], "lro")) ++flro;
		if (!strcmp(srgv[0], "lpe")) ++flpe;
		if (!strcmp(srgv[0], "thk")) ++fthk;
		if (!strcmp(srgv[0], "np")) ++fnp;
		if (!strcmp(srgv[0], "nv")) ++fnv;
		if (!strcmp(srgv[0], "orient")) ++forient;
		if (!strcmp(srgv[0], "ns")) ++fns;
		if (!strcmp(srgv[0], "arraydim")) ++farraydim;
	}	/* end fgets loop */
	fclose (fp);

	if (0) for (i = 0; i < 6; i++) printf ("%f\n", procpar[i]);
	return (0);
}






