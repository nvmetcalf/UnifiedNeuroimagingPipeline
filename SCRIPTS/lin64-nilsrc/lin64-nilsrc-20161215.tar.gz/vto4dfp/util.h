/*$Header: /home/usr/shimonyj/vto4dfp/RCS/util.h,v 1.2 2010/02/12 05:46:44 avi Exp $*/
/*$Log: util.h,v $
 * Revision 1.2  2010/02/12  05:46:44  avi
 * long->int to obtain 64-bit machine compatibility
 *
 * Revision 1.1  2006/12/24  06:38:46  avi
 * Initial revision
 **/

/* header file for library routines */

/* definitions */
#define PI 		3.1415926536
#define TWOPI	6.28318530717959

#define SQR(a) ((a)*(a))
#define ABS(a) (((a) >= 0.0) ? (a) : -(a))

/* structures */
typedef struct FCOMPLEX {float r,i;} fcomplex;

/* utility */
void nrerror(char error_text[]);

int *ivector(int nl, int nh);
unsigned int *lvector(int nl, int nh);
int **imatrix (int nrl, int nrh, int ncl ,int nch);
float *vector(int nl, int nh);
float **matrix (int nrl, int nrh, int ncl ,int nch);
double *dvector(int nl, int nh);
double **dmatrix (int nrl, int nrh, int ncl ,int nch);
fcomplex *Cvector(int nl, int nh);
fcomplex **Cmatrix (int nrl, int nrh, int ncl ,int nch);

void free_ivector(int *v, int nl, int nh);
void free_lvector(unsigned int *v, int nl, int nh);
void free_imatrix(int **m, int nrl, int nrh, int ncl ,int nch);
void free_vector(float *v, int nl, int nh);
void free_matrix(float **m, int nrl, int nrh, int ncl ,int nch);
void free_dvector(double *v, int nl, int nh);
void free_dmatrix(double **m, int nrl, int nrh, int ncl ,int nch);
void free_Cvector(fcomplex *v, int nl, int nh);
void free_Cmatrix(fcomplex **m, int nrl, int nrh, int ncl ,int nch);

/* random */
float ran0(int *idum);
float ran1(int *idum);
float expdev(int *idum);
float gaussdev(int *idum);
float sindev(int *idum);

/* complex */
fcomplex Cadd(fcomplex a, fcomplex b);
fcomplex Csub(fcomplex a, fcomplex b);
fcomplex Cmul(fcomplex a, fcomplex b);
fcomplex Cdiv(fcomplex a, fcomplex b);
fcomplex Complex(float re, float im);
fcomplex Conjg(fcomplex z);
float	 Cabs(fcomplex z);
fcomplex Csqrt(fcomplex z);
fcomplex RCmul(float x, fcomplex a);
fcomplex RCconv(float r, float ang);
void	 Cavevar(fcomplex data[],unsigned int n,fcomplex *ave,float *var);

/* matrix */
void ludcmp(float **a, int n, int *indx, float *d);
void lubksb(float **a, int n, int *indx, float b[]);
void Mmul(float **a, float **b, int nra, int ncarb, int ncb, float **c);
void MVmul(float **a, float *b, int nra, int ncarb, float *c);
void CMmul(fcomplex **a, fcomplex **b, int nra, int ncarb, int ncb, fcomplex **c);
void CMVmul(fcomplex **a, fcomplex *b, int nra, int ncarb, fcomplex *c);

/* spherical harmonic */
fcomplex Ylm_test(int l, int m, float theta, float phi);
fcomplex sht(fcomplex *c, int lmax, float theta, float phi);
void shit(int np, int lmax, fcomplex *f, float *th, float *ph, fcomplex *clm);
void shit_init(int np,int lmax,float *th,float *ph,float **a,int *indx,fcomplex **Xtc);
void shit_calc(int np,int lmax,fcomplex *f,float **a,int *indx,fcomplex **Xtc,fcomplex *clm);
double gammln(float xx);
double factrl(int n);
float plgndr(int l, int m, float x);
fcomplex Ylm(int l, int m, float theta, float phi);

/* fourier */
void four1(float data[], unsigned int nn, int isign);
void fourn(float data[], unsigned int nn[], int ndim, int isign);

/* statistics */
void fit(float x[], float y[], int ndata, float sig[], int mwt, float *a,
	float *b, float *siga, float *sigb, float *chi2, float *q);
void ftest(float data1[], unsigned int n1, float data2[], unsigned int n2,
	float *f, float *prob);
void tptest(float data1[],float data2[],unsigned int n,float *t,float *prob);
void avevar(float data[],unsigned int n,float *ave,float *var);
float betai(float a,float b,float x);
