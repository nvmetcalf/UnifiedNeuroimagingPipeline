/*$Header: /data/petsun4/data1/src_solaris/interp_4dfp/RCS/tremor_quant.c,v 1.4 2016/12/09 05:06:47 avi Exp $*/
/*$Log: tremor_quant.c,v $
 * Revision 1.4  2016/12/09  05:06:47  avi
 * find correct low fundamental frequencies
 * option -f; analyze tremor at harmonic closest to specified carrier frequency
 *
 * Revision 1.3  2016/03/17  02:57:25  avi
 * analysis of filtered u^2 statistics
 *
 * Revision 1.2  2016/03/16  22:40:15  avi
 * basic functions established
 *
 * Revision 1.1  2016/03/14  23:45:04  avi
 * Initial revision
 **/
#include	<stdlib.h>
#include	<stdio.h>
#include	<math.h>
#include	<float.h>
#include	<stdlib.h>
#include	<unistd.h>		/* R_OK */
#include	<string.h>
#include	<assert.h>
#ifndef _FEATURES_H			/* defined by math.h in Linux */
	#include <sunmath.h>		/* isnormal() */
#endif
#include	<librms.h>

#define MAXL	256
#define NR	2048
#define NBIN	40			/* u^2 histogram */

/*************/
/* externals */
/*************/
extern void 	butt1dbs_  (float *data,          int *n, float *delta, float *fhalf_lo, int *iorder_lo, float *fhalf_hi, int *iorder_hi, float *a, float *b);
extern void	pbutt1dcs_ (float *data, int *n0, int *n, float *delta, float *fhalf_lo, int *iorder_lo, float *fhalf_hi, int *iorder_hi, float *a, float *b);

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation error\n", program);
	exit (-1);
}

void errr (char* program, char* file) {
	fprintf (stderr, "%s: $%s read error\n", program, file);
	exit (-1);
}

void errw (char* program, char* file) {
	fprintf (stderr, "%s: $%s write error\n", program, file);
	exit (-1);
}

double zero_mean (float *f, int npts) {
	int		i, n;
	double		u;

	for (u = n = i = 0; i < npts; i++) {n++; u += f[i];}
	u /= n;
	for (i = 0; i < npts; i++) f[i] -= u;
	return u;
}

double unit_var (float *f, int npts) {
	int		i, n;
	double		v;

	for (v = n = i = 0; i < npts; i++) {n++; v += f[i]*f[i];}
	v /= n;
	for (i = 0; i < npts; i++) f[i] /= sqrt (v);
	return v;
}

void usage (char* program) {
	printf ("Usage:	%s <ASCII tremor listing>\n", program);
	printf (" e.g.:	%s LowTremorNote.txt\n", program);
	printf ("	option\n");
	printf ("	-D	run demo\n");
	printf ("	-f<flt>	analyze tremor at harmonic closest to specified frequency (default f0)\n");
	exit (1);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

static char rcsid[] = "$Id: tremor_quant.c,v 1.4 2016/12/09 05:06:47 avi Exp $";
int main (int argc, char *argv[]) {
	char		infile[MAXL] = "";
	FILE		*fp;
	int		c, i, j, k, l;
	int		npts, margin, lpad, ionoff, imax;
        int		order_lo = 0,   order_hi = 2;
        float           fhalf_lo = 0.0, fhalf_hi = 20.0;
	float		*fpad, *spad, *h, *r;
	float		q, t, delta = 0.001, f0 = 100., twopi, sigma = 0.025;
	float		dHzmin = 1.e6, f1 = 0.;
	float		*a, *b;		/* scratch buffers used by Butterworth filters */

/************************************/
/* histogram of filtered u^2 values */
/************************************/
	int		hist[NBIN], nhist, kmax, klo, khi;
	float		fmean, FWHM, alpha, wlo, whi, amode;
	float		dhdk, d2hdk2, delk, hmax;

/***********/
/* utility */
/***********/
	char		*ptr, program[MAXL], command[MAXL], outfile[MAXL] = "tremor_quant.dat";

/*********/
/* flags */
/*********/
	int		status = 0;
	int		demo = 0;
	int		debug = 1;

	fprintf (stdout, "%s\n", rcsid);
	setprog (program, argv);
	twopi = 8.*atan(1.);

/******************************/
/* get command line arguments */
/******************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'D':demo++;		break;
				case 'f':f1 = atof (ptr);	*ptr = '\0'; break;
				default:			break;
			}
		} else switch (k) {
			case 0: strncpy (infile, argv[i], MAXL - 1); k++; break;
			default:	break;
		}
	}
	if (k < 1 && !demo) usage (program);

if (demo) {
	npts = lpad = 1000;
	printf ("original time series length %d padded to %d\n", npts, lpad);
	if (!(spad = (float *) calloc (lpad, sizeof (float)))) errm (program);

/*********************/
/* define timeseries */
/*********************/
	for (i = 0; i < lpad; i++) {
		t = delta*i;
		ionoff = (int) (t*10.);
		if (!(ionoff % 2)) { 
			spad[i] = cos(twopi*f0*t);
		}
	}
} else {
/*******************/
/* read timeseries */
/*******************/
	delta = 3./250000.;
	fprintf (stdout, "Reading: %s\n", infile);
	if (!(fp = fopen (infile, "r"))) errr (program, infile);
	npts = 0; while (fgets (command, MAXL, fp)) npts++;
	if (!(spad = (float *) calloc (npts, sizeof (float)))) errm (program);
	printf ("%s %d samples %.4f sec\n", infile, npts, npts*delta);
	rewind (fp);
	for (i = 0; i < npts; i++) fscanf (fp, "%f", spad + i);
	fclose (fp);
	zero_mean (spad, npts);
	unit_var  (spad, npts);

/**********************************/
/* compute lagged autocorrelation */
/**********************************/
	if (!(r = (float *) calloc (NR, sizeof (float)))) errm (program);
	for (k = 0; k < NR; k++) {
		if (!(k%100)) {printf (" %d", k); fflush (stdout);}
		for (i = 0; i < npts - k; i++) r[k] += spad[i]*spad[i + k];
	}
	for (k = 1; k < NR; k++) r[k] /= r[0]; r[0] = 1.;
	printf ("\n");
/*********************************/
/* output lagged autocorrelation */
/*********************************/
	sprintf (outfile, "%s.cor", infile);
	fprintf (stdout, "Writing: %s\n", outfile);
	if (!(fp = fopen (outfile, "w"))) errw (program, outfile);
	for (i = 0; i < NR; i++) fprintf (fp, "%10.6f %10.4f\n", i*delta, r[i]);
	fclose (fp);

/***************/
/* identify f0 */
/***************/
	k = imax = 0;
	for (i = 0; i < NR - 1; i++) {
		if (r[i] < 0. && !k) {
			imax = i;
			k++;
		}
		if (!k) continue;
		if (f1 > 0.) {
			if (r[i] > r[i + 1] && r[i] > r[i - 1]) {
				q = fabs (f1 - 1./(i*delta));
				if (q < dHzmin) {
					dHzmin = q;
					imax = i;
				}
			} else {
				continue;
			}
		} else {
			if (r[i] > r[imax]) imax = i;
		}
	}	
	q = imax + 0.5*(r[imax - 1] - r[imax + 1])/(r[imax - 1] - 2.*r[imax] + r[imax + 1]);
	f0 = 1./(q*delta);
	printf ("max=%d q=%.4f f0=%.4f\n", imax, q, f0);
	free (r);
	margin = (int) 3.*sigma/delta;
	lpad = npad_ (&npts, &margin);
	printf ("npts=%d margin=%d lpad=%d\n", npts, margin, lpad);
	if (!(spad = (float *) realloc (spad, lpad*sizeof (float)))) errm (program);
	for (i = npts; i < lpad; i++) spad[i] = 0.0;
}
	if (!(fpad = (float *) calloc (lpad,       sizeof (float)))) errm (program);
	if (!(h    = (float *) calloc (lpad,       sizeof (float)))) errm (program);
	if (!(a    = (float *) calloc (lpad/2 + 1, sizeof (float)))) errm (program);
	if (!(b    = (float *) calloc (lpad/2 + 1, sizeof (float)))) errm (program);

/*****************/
/* define kernel */
/*****************/
	for (i = 0; i < lpad/2; i++) {
		t = delta*i;
		h[i] = delta*cos(twopi*f0*t)*(sqrt(8./twopi)*(1./sigma))*exp(-0.5*t*t/(sigma*sigma));
		if (i) h[lpad - i] = h[i];
	}

/***********************************/
/* convolve timeseries with kernel */
/***********************************/
	conv_ (spad, h, fpad, &lpad);

/***************/
/* square u(t) */
/***************/
if (1)	for (i = 0; i < lpad; i++) fpad[i] *= fpad[i];

/**********/
/* filter */
/**********/
	printf ("fhalf_lo %.4f order_lo %d fhalf_hi %.4f order_hi %d\n", fhalf_lo, order_lo, fhalf_hi, order_hi);
	if (fhalf_lo <= 0.0 || order_lo < 0) order_lo = 0;
	if (fhalf_hi <= 0.0 || order_hi < 0) order_hi = 0;
if (1)	pbutt1dcs_ (fpad, &npts, &lpad, &delta, &fhalf_lo, &order_lo, &fhalf_hi, &order_hi, a, b);

/**********************************/
/* analyze filtered u^2 histogram */
/**********************************/
	for (fmean = 0, i = 0; i < npts; i++) fmean += fpad[i];
	fmean /= npts;
	alpha = 2.*fmean/NBIN;
	printf ("fmean=%.4f alpha=%.4f\n", fmean, alpha);
	for (k = 0; k < NBIN; k++) hist[k] = 0;
	for (nhist = i = 0; i < npts; i++) {
		k = (int) (fpad[i]/alpha);
		if (k < NBIN) {
			hist[k]++;
			nhist++;
		}
	}
	for (k = 0; k < NBIN; k++) printf ("%10d%10.4f%10d\n", k, (k + 0.5)*alpha, hist[k]);
	for (kmax = k = NBIN/4; k < NBIN; k++) if (hist[k] > hist[kmax]) kmax = k;
	dhdk   =  0.5*(hist[kmax + 1] - hist[kmax - 1]);
	d2hdk2 = hist[kmax - 1] - 2.*hist[kmax] + hist[kmax + 1];
	delk   = -0.5*dhdk/d2hdk2;
	hmax = hist[kmax] + dhdk*delk + 0.5*d2hdk2*delk*delk;
	printf ("dhdk=%.4f d2hdk2=%.4f delk=%.4f hmax=%.4f\n", dhdk, d2hdk2, delk, hmax);
	klo = khi = kmax;
	while (hist[klo] > hmax/2) klo--;
	while (hist[khi] > hmax/2) khi++;
	if (debug) printf ("klo=%d kmax=%d khi=%d\n", klo, kmax, khi);
	wlo = (hmax/2 - hist[klo])/(hist[klo + 1] - hist[klo]);
	if (debug) printf ("wlo=%.4f\n", wlo);
	whi = (hmax/2 - hist[khi - 1])/(hist[khi] - hist[khi - 1]);
	if (debug) printf ("whi=%.4f\n", whi);
	FWHM  = alpha*((khi - 1 + whi) - (klo + wlo));
	amode = alpha*(kmax + delk + 0.5);
	printf ("filtered u^2 histogram mode = %.4f FWHM = %.4f FWHM/mode = %.4f\n", amode, FWHM, FWHM/amode);
/*********************************/
/* output filtered u^2 histogram */
/*********************************/
	sprintf (outfile, "%s.mod.hist", infile);
	fprintf (stdout, "Writing: %s\n", outfile);
	if (!(fp = fopen (outfile, "w"))) errw (program, outfile);
	fprintf (fp, "%10.4f%10d\n", 0.,            0);
	for (k = 0; k < NBIN; k++) {
	fprintf (fp, "%10.4f%10d\n", alpha*k,       hist[k]);
	fprintf (fp, "%10.4f%10d\n", alpha*(k + 1), hist[k]);
	}
	fprintf (fp, "%10.4f%10d\n", alpha*NBIN,    0);
	fclose (fp);

/********************************************************/
/* output timeseries with filtered u^2 scaled to 5*mode */
/********************************************************/
	sprintf (outfile, "%s.mod", infile);
	fprintf (stdout, "Writing: %s\n", outfile);
	if (!(fp = fopen (outfile, "w"))) errw (program, outfile);
	for (i = 0; i < npts; i++) fprintf (fp, "%10.6f%10.4f%10.4f%10.6f\n", delta*i, spad[i], 5.*fpad[i]/amode, h[i]/h[0]);
	fclose (fp);

	free (a); free (b); free (fpad); free (spad); free (h);
	exit (0);
}
