/*$Header: /data/petsun4/data1/src_solaris/interp_4dfp/RCS/low_pass.c,v 1.1 2016/10/31 04:35:22 avi Exp $*/
/*$Log: low_pass.c,v $
 * Revision 1.1  2016/10/31  04:35:22  avi
 * Initial revision
 **/

#include	<stdlib.h>
#include	<stdio.h>
#include	<math.h>
#include	<stdlib.h>

extern int	npad_ (int *tdim, int *margin);						/* FORTRAN librms */
extern void	pbutt1dcs_ (float *data, int *n0, int *n, float *delta, float *fhalf_lo,
		int *iorder_lo, float *fhalf_hi, int *iorder_hi, float *a, float *b);	/* pbutt1dc.f */

void	low_pass (float *f, int npts, float TR_vol, char *program) {
	int		margin, tpad, i, k, mpad;
	float 		*a, *b, *fpad, w;
/*********************/
/* fliter parameters */
/*********************/
	int		order_lo = 0, order_hi = 2;
	float		fhalf_lo = 0, fhalf_hi = 0.1;	/* Hz */

	margin = 35/TR_vol;
	tpad = npad_ (&npts, &margin);
	if (0) printf ("original time series length %d padded to %d\n", npts, tpad);
	if (!(fpad =	(float *) calloc (tpad, sizeof (float)))) errm (program);
	if (!(a = (float *) calloc (tpad/2 + 1, sizeof (float)))) errm (program);
	if (!(b = (float *) calloc (tpad/2 + 1, sizeof (float)))) errm (program);

	for (i = 0; i < npts; i++) fpad[i] = f[i];
/*******************************************/
/* linearly interpolate over padded points */
/*******************************************/
	mpad = tpad - npts;
	for (i = 0; i < mpad; i++) {
		w = (float) (i + 1) / (float) (mpad + 1);
		fpad[npts + i] = w*f[0] + (1. - w)*f[npts - 1];
	}
	pbutt1dcs_ (fpad, &npts, &tpad, &TR_vol, &fhalf_lo, &order_lo, &fhalf_hi, &order_hi, a, b);
	for (i = 0; i < npts; i++) f[i] = fpad[i];

	free (a); free (b); free (fpad); 
}
