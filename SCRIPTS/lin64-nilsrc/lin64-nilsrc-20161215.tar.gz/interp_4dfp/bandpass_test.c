/*$Header: /data/petsun4/data1/src_solaris/interp_4dfp/RCS/bandpass_test.c,v 1.3 2012/04/16 23:43:25 avi Exp $*/
/*$Log: bandpass_test.c,v $
 * Revision 1.3  2012/04/16  23:43:25  avi
 * re-correct output
 *
 * Revision 1.2  2012/04/16  22:41:33  avi
 * correct output
 *
 * Revision 1.1  2012/04/16  04:42:35  avi
 * Initial revision
 **/
#include	<stdlib.h>
#include	<stdio.h>
#include	<math.h>
#include	<string.h>

#define MAXL		256
#define MARGIN		16
#define ORDER_LO	0
#define ORDER_HI	0
#define LSEED		0
#define NRLZ		4096

/*************/
/* externals */
/*************/
extern double dnormal ();
extern int npad_ (int *tdim, int *margin);	/* FORTRAN librms */
extern void  butt1db_  (float *data,          int *n, float *delta, float *fhalf_lo, int *iorder_lo, float *fhalf_hi, int *iorder_hi);
extern void pbutt1dcs_ (float *data, int *n0, int *n, float *delta, float *fhalf_lo, int *iorder_lo, float *fhalf_hi, int *iorder_hi, float *a, float *b);
extern void   fft_ (float *a, float *b, int *nseg, int *n, int *nspn, int *isn);		/* fftsol.f */
extern void realt_ (float *a, float *b, int *nseg, int *n, int *nspn, int *isn);		/* fftsol.f */

/***********/
/* globals */
/***********/
static char program[MAXL];
static char rcsid[] = "$Id: bandpass_test.c,v 1.3 2012/04/16 23:43:25 avi Exp $";

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation error\n", program);
	exit (-1);
}

void errw (char* program, char* filespc) {
	fprintf (stderr, "%s: %s write error\n", program, filespc);
	exit (-1);
}

void write_command_line (FILE *outfp, int argc, char *argv[]) {
	int		i;

	fprintf (outfp, "#%s", program);
	for (i = 1; i < argc; i++) fprintf (outfp, " %s", argv[i]);
	fprintf (outfp, "\n#%s\n", rcsid);
}

void usage (char* program) {
	printf ("Usage:\t%s <tdim> <TR_vol>\n", program);
	printf ("e.g.:\t%s 1000 1. -bl0.01 -ol2 -bh0.3 -oh3\n", program);
	printf ("\toption\n");
	printf ("\t-b[l|h]<flt>\tspecify low end or high end half frequency in hz\n");
	printf ("\t-o[l|h]<int>\tspecify low end or high end Butterworth filter order\n");
	printf ("\t-a\tretain DC (constant) component\n");
	printf ("\t-r\tretain linear trend\n");
	printf ("\t-I\tleaky integrate timeseries before filtering\n");
	printf ("\t-Z\tzero-pad before filtering (default = ramp pad)\n");
	printf ("\t-B\tcompute gain using correct Butterworth formula (default squared Butterworth gain)\n");
	printf ("N.B.:\ttimeseries is generated as random normal deviates\n");
	printf ("N.B.:\tomitting low  end order specification disables high pass component\n");
	printf ("N.B.:\tomitting high end order specification disables low  pass component\n");
	printf ("N.B.:\t<tdim> is number of steady-state time points\n");
	exit (1);
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

int main (int argc, char *argv[]) {
	char		outfile[MAXL] = "bandpass_test.dat";
	FILE		*fp;
	int		c, i, j, k, l;
	int		order_lo = ORDER_LO, order_hi = ORDER_HI;
	long		lseed = LSEED;
	int		nrlz = NRLZ;
	int		tdim, tdim_pad, tdim_pad_o2, margin = MARGIN, padlen;

	float		fhalf_lo = 0.0, fhalf_hi = 0.0, TR_vol;
	float		*a, *b;		/* scratch buffers used by fft */
	int		one = 1, mone = -1;

/****************************/
/* linear trend computation */
/****************************/
	float		*x, sy, sxy, sxx, a0, a1;
	float		*tpad, *ppad, q;

/***********/
/* utility */
/***********/
	char		*ptr, command[MAXL];

/*********/
/* flags */
/*********/
	int		status;
	int		keepDC = 0;
	int		keepramp = 0;
	int		B_flag = 0;
	int		integ = 0;
	int		zeropad = 0;

	fprintf (stdout, "%s\n", rcsid);
	setprog (program, argv);
/******************************/
/* get command line arguments */
/******************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'a': keepDC++;			break;
				case 'r': keepramp++;			break;
				case 'B': B_flag++;			break;
				case 'Z': zeropad++;			break;
				case 'I': integ++;			break;
				case 'o': switch (*ptr++) {
					case 'l': order_lo = atoi (ptr);	break;
					case 'h': order_hi = atoi (ptr);	break;
					default:  usage (program);		break;
					}				*ptr = '\0'; break;
				case 'b': switch (*ptr++) {
					case 'l': fhalf_lo = atof (ptr);	break;
					case 'h': fhalf_hi = atof (ptr);	break;
					default:  usage (program);      	break;
					}				*ptr = '\0'; break;
			}
		} else switch (k) {
		 	case 0: tdim = atoi (argv[i]);		k++; break;
		 	case 1: TR_vol = atof (argv[i]);	k++; break;
		}
	}
	if (k < 2) usage (program);
	printf ("fhalf_lo %.4f order_lo %d fhalf_hi %.4f order_hi %d\n", fhalf_lo, order_lo, fhalf_hi, order_hi);
	if (fhalf_lo <= 0.0 || order_lo < 0) order_lo = 0;
	if (fhalf_hi <= 0.0 || order_hi < 0) order_hi = 0;

/********************************/
/* allocate time series buffers */
/********************************/
	tdim_pad = npad_ (&tdim, &margin);
	tdim_pad_o2 = tdim_pad/2;
	padlen = tdim_pad - tdim;
	printf ("original time series length %d padded to %d\n", tdim, tdim_pad);
	if (!(ppad = (float *) calloc (tdim_pad,  sizeof (float)))) errm (program);
	if (!(tpad = (float *) malloc (tdim_pad * sizeof (float)))) errm (program);
	if (!(x =    (float *) malloc (tdim     * sizeof (float)))) errm (program);
	for (i = 0; i < tdim; i++) x[i] = -1. + 2.*i/(tdim - 1);
	sxx = ((float) tdim*(tdim+1)) / (3.*(tdim-1));
	if (!(a = (float *) calloc (tdim_pad/2 + 1, sizeof (float)))) errm (program);
	if (!(b = (float *) calloc (tdim_pad/2 + 1, sizeof (float)))) errm (program);

	srand48 ((long) lseed);		/* initialize random number generator */
	for (l = 0; l < nrlz; l++) {	/* realizations loop */
/***********************************************************/
/* populate tpad and optionally remove DC and linear trend */
/***********************************************************/
		q = sy = sxy = 0;
		for (k = -100; k < tdim; k++) {
			if (integ) {
				q *= 0.8;
				q += dnormal ();
			} else {
				q  = dnormal ();
			}
			if (k < 0) continue;
			tpad[k] = q;
			sy  += tpad[k];
			sxy += tpad[k]*x[k];
		}
		a0 = (keepDC)   ? 0. : sy/tdim;
		a1 = (keepramp) ? 0. : sxy/sxx;
/****************************/
/* remove mean and/or trend */
/****************************/
		for (k = 0; k < tdim; k++) tpad[k] -= (a0 + x[k]*a1);

/*******/
/* pad */
/*******/
		if (!l) printf ("padlen=%d\n", padlen);
		q = (tpad[0] - tpad[tdim - 1]) / (padlen + 1);
		if (zeropad) {
			for (       k = tdim; k < tdim_pad; k++) tpad[k] = 0.;
		} else {
			for (j = 1, k = tdim; k < tdim_pad; k++) tpad[k] = tpad[tdim - 1] + q*j++;
		}

		if (0 && !l) for (k = 0; k < tdim_pad; k++) printf ("%10d%10.4f\n", k, tpad[k]);
/**********/
/* filter */
/**********/
		if (B_flag) {
			pbutt1dcs_ (tpad, &tdim, &tdim_pad, &TR_vol, &fhalf_lo, &order_lo, &fhalf_hi, &order_hi, a, b);
		} else {
			 butt1db_  (tpad,        &tdim_pad, &TR_vol, &fhalf_lo, &order_lo, &fhalf_hi, &order_hi);
		}

/*********************************/
/* force timeseries to zero mean */
/*********************************/
		for (q = k = 0; k < tdim; k++) q += tpad[k];
		q /= tdim;
		for (q = k = 0; k < tdim; k++) tpad[k] -= q;

/************/
/* zero pad */
/************/
		for (k = tdim; k < tdim_pad; k++) tpad[k] = 0.;

/********************************/
/* compute and accumulate power */
/********************************/
		for (k = i = 0; i < tdim_pad/2; i++) {
			a[i] = tpad[k++];
			b[i] = tpad[k++];
		}
		fft_  (a, b, &one, &tdim_pad_o2, &one, &mone);
		realt_(a, b, &one, &tdim_pad_o2, &one, &mone);
		for (k = 0; k < tdim/2 + 1; k++) ppad[k] += (a[k]*a[k] + b[k]*b[k])/tdim;
	}	/* realizations loop */

/***********************/
/* write filtered tpad */
/***********************/
	printf ("Writing: %s\n", outfile);
	if (!(fp = fopen (outfile, "w"))) errw (program, outfile);
	write_command_line (fp, argc, argv);
	for (k = 0; k < tdim/2 + 1; k++) fprintf (fp, "%10.4f %9.4f\n", (float) k/(TR_vol*tdim), ppad[k]/nrlz);
	fclose (fp);

	free (a); free (b);
	free (tpad); free (ppad); free (x);

	exit (0);
}
