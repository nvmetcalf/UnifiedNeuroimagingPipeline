void	DC_trendout (float *data, int n) {
/****************************/
/* linear trend computation */
/****************************/
	int		k;
	float		sy, sxy, sxx, a[2];	/* coefficients */

	sxx = ((float) n*(n+1)) / (3.*(n-1));
/******************************/
/* remove DC and linear trend */
/******************************/
	for (sy = sxy = k = 0; k < n; k++) {
		sy  += data[k];
		sxy += data[k]*(-1. + 2.*k/(n - 1));
	}
	a[0] = sy/n;
	a[1] = sxy/sxx;
	for (k = 0; k < n; k++) data[k] -= (a[0] + (-1. + 2.*k/(n - 1))*a[1]);
}
