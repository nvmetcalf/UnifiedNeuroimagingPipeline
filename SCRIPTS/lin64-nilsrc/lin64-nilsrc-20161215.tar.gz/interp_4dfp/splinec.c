/*$Header: /data/petsun4/data1/src_solaris/interp_4dfp/RCS/splinec.c,v 1.3 2016/10/04 00:16:19 avi Exp $*/
/*$Log: splinec.c,v $
 * Revision 1.3  2016/10/04  00:16:19  avi
 * remove redundant code
 *
 * Revision 1.2  2016/10/03  05:37:57  avi
 * remove conflicting globals
 *
 * Revision 1.1  2016/10/03  05:28:24  avi
 * Initial revision
 **/

#include	<stdlib.h>
#include	<stdio.h>
#include	<math.h>
#include	<float.h>
#include	<stdlib.h>
#include	<string.h>

#define MAXL	256
#define N	100

void splinec (float *x, float *y, int n, float *y2) {
/***********************************************************************************/
/* given arrays x[0...n-1] and y[0...n-1] containing a tabulated function, yi      */
/* with ordered xi, this routine returns an array y2[0...n-1] that contains        */
/* the second derivatives of the interpolating function at the tabulated points xi */
/***********************************************************************************/
	int	i, k;
	float 	p, sig, *u;

	if (!(u = (float *) calloc (n, sizeof (float)))) {
		fprintf (stderr, "calloc failure in subroutine splinec()\n");
		exit (-1);
	}
	y2[0] = u[0] = 0.0; 
	for (i = 1; i < n-1; i++) {
		sig = (x[i] - x[i-1])/(x[i+1] - x[i-1]);
		p = sig*y2[i-1] + 2.0;
		y2[i] = (sig - 1.0)/p;
		u[i] = (y[i+1] - y[i])/(x[i+1] - x[i]) - (y[i] - y[i-1])/(x[i] - x[i-1]);
		u[i] = (6.0*u[i]/(x[i+1] - x[i-1]) - sig*u[i-1])/p;
	}
	y2[n-1] = 0.0; 
	for (k = n-2; k >= 0; k--) y2[k] = y2[k]*y2[k+1] + u[k];
	free (u);
}

float splintc (float *xa, float *ya, float *y2a, int n, float x) {
/*********************************************************************************************/
/* given the arrays xa[0...n-1], ya[0...n-1], y2a[1..n-1], which is the output from above    */
/* splinec and given a value of x, this routine returns a cubic-splinec interpolated value y */
/*********************************************************************************************/
	int	klo, khi, k;
	float	h, b, a;

	if (x <= xa[0])   return ya[0];
	if (x >= xa[n-1]) return ya[n-1];

	klo = 0; khi = n-1;
	while (khi - klo > 1) {
		k = (khi + klo) >> 1;
		if (xa[k] > x) khi = k; else klo = k;
	}	/* klo and khi now bracket input value of x */
	h = xa[khi] - xa[klo];
	if (h <= 0.0) {
		fprintf (stderr, "bad x input to routine splintc\n");
		exit (-1);
	}
	a = (xa[khi] - x)/h;
	b = (x - xa[klo])/h;
	return a*ya[klo] + b*ya[khi] + ((a*a*a - a)*y2a[klo] + (b*b*b - b)*y2a[khi])*(h*h)/6.0;
}

int splinec_test (int argc, char *argv[]) {
	float 	x[N], y[N], y2[N], twopi, xt, yt, del;
	int	i, j, k, nt;

	twopi = 8.*atan(1.);
if (0) {
	for (i = 0; i < N; i++) {
		x[i] = twopi*i/(float) N;
		y[i] = sin(x[i]);
	}
	splinec (x, y, N, y2);
	for (i = 0; i < N; i++) {
		xt = twopi*i/(float) N;
		yt = splintc (x, y, y2, N, xt);
		printf ("%10.6f%10.6f%10.6f\n", xt, yt, y[i]);
	}
	for (i = 1; i < N; i++) {
		xt = twopi*(i - 0.5)/(float) N;
		yt = splintc (x, y, y2, N, xt);
		printf ("%10.6f%10.6f%10.6f\n", xt, yt, 0.5*(y[i] + y[i-1]));
	}
}
	xt = 0.;
	for (i = 0; i < N; i++) {
		x[i] = xt;
		y[i] = sin(x[i]);
		xt += 2.*twopi*drand48()/(float) N;
	}
	splinec (x, y, N, y2);
	for (i = 0; i < N; i++) printf ("%10.6f%10.6f%10.6f\n", x[i], y[i], y2[i]);
	printf ("\n");
	xt = 0.;
	do {
		yt = splintc (x, y, y2, N, xt);
		printf ("%10.6f%10.6f%10.6f\n", xt, yt, sin(xt));
		xt += 2.*twopi*drand48()/(float) N;
	} while (xt < x[N-1]);
}
