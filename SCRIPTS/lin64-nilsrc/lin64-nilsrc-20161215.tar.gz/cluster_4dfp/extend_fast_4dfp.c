/*$Header: /data/petsun4/data1/src_solaris/cluster_4dfp/RCS/extend_fast_4dfp.c,v 1.3 2016/04/02 03:20:00 avi Exp $*/
/*$Log: extend_fast_4dfp.c,v $
 * Revision 1.3  2016/04/02  03:20:00  avi
 * saved result does not reflect final redundant loop operation
 *
 * Revision 1.2  2016/04/02  02:49:02  avi
 * tighter main loop code
 *
 * Revision 1.1  2016/03/31  04:41:10  avi
 * Initial revision
 **/
#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <float.h>
#include <unistd.h>
#include <assert.h>
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>

#define MAXL	256
/********************/
/* global variables */
/********************/
static char		rcsid[] = "$Id: extend_fast_4dfp.c,v 1.3 2016/04/02 03:20:00 avi Exp $";
static char		program[MAXL];

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

int main (int argc, char *argv[]) {
	FILE 		*imgfp, *outfp;
	char            imgroot[MAXL], imgfile[MAXL], resroot[MAXL], resfile[MAXL], outroot[MAXL], outfile[MAXL];
	IFH		ifh;
	char		control = '\0';
	int		ix, iy, iz, iv, it, nn, iter;
	int		dimension, xdim, ydim, zdim, imgdim[4], orient, orientr, isbig;
	float		voxdim[3];
	float		*fptr, *img1, *imgr, *imgg, *imgh, *imgo;
	float		q, dmax, d, vmax;
	char		string[MAXL], command[MAXL], *ptr;
	int		c, i, j, k, m, m0;

/*********/
/* flags */
/*********/
	int		status = 0;
	int		verbose = 0;
	int		G_flag = 0;

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) if (*argv[i] == '-') {
		strcpy (string, argv[i]); ptr = string;
		while (c = *ptr++) switch (c) {
			case 'G': G_flag++;		break;
			case 'v': verbose++;		break;
			case '@': control = *ptr++;	*ptr = '\0'; break;
		}
	} else switch (k) {
		case 0: getroot (argv[i], imgroot); k++;  break;
		case 1: getroot (argv[i], resroot); k++;  break;
		case 2: getroot (argv[i], outroot); k++;  break;
	}
	if (k < 3) {
		fprintf (stderr, "Usage:\t%s <(4dfp) mpr> <(4dfp) FAST restored mpr> <(4dfp) outroot>\n", program);
		fprintf (stderr, " e.g.,\t%s EP158_Post_mpr1 EP158_Post_mpr1_R EP158_Post_mpr1_RE\n", program);
		fprintf (stderr, "\toption\n");
		fprintf (stderr, "\t-v	verbose mode\n");
		fprintf (stderr, "\t-G	output gain field (default fully restored mpr)\n");
		fprintf (stderr, "\t-@<b|l>	output big or little endian (default input endian)\n");
		exit (1);
	}

/*****************************/
/* get 4dfp input dimensions */
/*****************************/
	sprintf (imgfile, "%s.4dfp.img", imgroot);
	if (get_4dfp_dimoe (imgfile, imgdim, voxdim, &orient, &isbig) < 0
	||  Getifh (imgfile, &ifh)) errr (program, imgroot);
	if (!control) control = (isbig) ? 'b' : 'l';
	dimension = imgdim[0]*imgdim[1]*imgdim[2];
	xdim = imgdim[0]; ydim = imgdim[1]; zdim = imgdim[2];
	sprintf (resfile, "%s.4dfp.img", resroot);
	if (get_4dfp_dimoe (resfile, imgdim, voxdim, &orientr, &isbig) < 0) errr (program, resroot);
	status = (xdim != imgdim[0] || ydim != imgdim[1] || zdim != imgdim[2] || orientr != orient);
	if (status) {
		fprintf (stderr, "%s: %s %s dimension mismatch\n", program, imgroot, resroot);
		exit (-1);
	}

	if (!(img1 = (float *) calloc (dimension, sizeof (float)))) errm (program);
	if (!(imgr = (float *) calloc (dimension, sizeof (float)))) errm (program);
	if (!(imgg = (float *) calloc (dimension, sizeof (float)))) errm (program);
	if (!(imgh = (float *) calloc (dimension, sizeof (float)))) errm (program);
	if (!(imgo = (float *) calloc (dimension, sizeof (float)))) errm (program);
/***************/
/* read images */
/***************/
	printf ("Reading: %s\n", imgfile);
	if (!(imgfp = fopen (imgfile, "rb"))
	|| eread  (img1, dimension, isbig, imgfp)
	|| fclose (imgfp)) errr (program, imgfile);
	printf ("Reading: %s\n", resfile);
	if (!(imgfp = fopen (resfile, "rb"))
	|| eread  (imgr, dimension, isbig, imgfp)
	|| fclose (imgfp)) errr (program, resfile);

/******************************/
/* compute defined gain field */
/******************************/
	for (i = 0; i < dimension; i++) if (imgr[i] != 0. && img1[i] != 0.) imgh[i] = imgg[i] = imgr[i]/img1[i];

	if (verbose) printf ("%10s%10s%10s\n", "iter", "voxels", "dmax"); fflush (stdout);
	m0 = iter = 0;
	while (1) {
		iter++;
/**********************************/
/* average over defined neighbors */
/**********************************/
		dmax = m = 0;
		for (iz = 0; iz < zdim; iz++) {
		for (iy = 0; iy < ydim; iy++) {
		for (ix = 0; ix < xdim; ix++) {
			iv = ix + xdim*(iy + ydim*iz);
			if (imgr[iv] != 0.0) continue;
			for (q = nn = j = 0; j < 6; j++) {
				it = -1; switch (j) {
					case 0:	if (ix > 0)		it = iv - 1;		break;
					case 1:	if (ix < xdim - 1)	it = iv + 1;		break;
					case 2:	if (iy > 0)		it = iv - xdim;		break;
					case 3:	if (iy < ydim - 1)	it = iv + xdim;		break;
					case 4:	if (iz > 0)		it = iv - xdim*ydim;	break;
					case 5:	if (iz < zdim - 1)	it = iv + xdim*ydim;	break;
				}
				if (it != -1 && imgg[it] > 0.) {
					q += imgg[it];
					nn++;
				}
			}
			if (nn) {
				imgh[iv] = q/nn;
				d = fabs (imgh[iv] - imgg[iv]);
				if (d > dmax) dmax = d;
				m++;
			}
		}}}
		if (m == m0) break;
		if (verbose) printf ("%10d%10d%10.6f\n", iter, m, dmax); fflush (stdout);
		m0 = m;
		fptr = imgg; imgg = imgh; imgh = fptr;
	}

	for (vmax = i = 0; i < dimension; i++) {
		if (G_flag) {
			imgo[i] = imgg[i];
		} else {
			imgo[i] = (imgr[i] > 0.) ? imgr[i] : img1[i]*imgg[i];
		}
		if (imgo[i] > vmax) vmax = imgo[i];
	}
/**********************/
/* write output image */
/**********************/
	sprintf (outfile, "%s.4dfp.img", outroot);
	fprintf (stdout, "Writing: %s\n", outfile);
	if (!(imgfp = fopen (outfile, "wb"))
	|| ewrite (imgo, dimension, control, imgfp)
	|| fclose (imgfp)) errw (program, imgfile);

/*******/
/* ifh */
/*******/
	ifh.matrix_size[3] = 1;		/* all output images are 1 volume */
	if (Writeifh (program, outroot, &ifh, control)) errw (program, outroot);

/*******/
/* hdr */
/*******/
	sprintf (command, "ifh2hdr %s -r%.0f", outroot, vmax + 0.5);
	printf ("%s\n", command);
	status |= system (command);

/*******/
/* rec */
/*******/
	startrece (outfile, argc, argv, rcsid, control);
	catrec (imgfile);
	catrec (resfile);
	endrec ();

	free (img1); free (imgo); free (imgr); free (imgg); free (imgh);
	exit (status);
}
