/*$Header: /data/petsun4/data1/src_solaris/perceptron_4dfp/RCS/perceptron_4dfp.c,v 1.8 2011/08/06 03:22:00 avi Exp $*/
/*$Log: perceptron_4dfp.c,v $
 * Revision 1.8  2011/08/06  03:22:00  avi
 * reorder w1 indices to speed executaion
 *
 * Revision 1.7  2011/08/04  07:42:34  avi
 * timing logging
 *
 * Revision 1.6  2011/08/03  06:29:47  avi
 * all functionality in place
 *
 * Revision 1.5  2011/08/03  03:00:28  avi
 * imgr values match Matlab
 *
 * Revision 1.4  2011/08/02  06:56:12  avi
 * compute correlation matrix input to perceptron
 *
 * Revision 1.3  2011/08/01  06:05:23  avi
 * corrrect string allocation
 *
 * Revision 1.2  2011/08/01  05:20:55  avi
 * format and fMRI preprocessing logiv
 *
 * Revision 1.1  2011/07/31  02:12:58  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* R_OK */
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <float.h>
#include <assert.h>
#ifndef _FEATURES_H		/* defined by math.h in Linux */
	#include <ieeefp.h>
	#include <sunmath.h>	/* isnormal() */
#endif
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>
#include <conc.h>		/* defines MAXL */

#define NHIDDEN	900		/* number of hidden nodes */

float rnan (void) {
	union {
		float		r;
		unsigned int	j;
        } word;
	word.j = 0x7fffffff;
	return word.r;
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

/*************/
/* externals */
/*************/
int	expandf (char *string, int len);			/* expandf.c */

/********************/
/* global variables */
/********************/
char		program[MAXL];
static char	rcsid[] = "$Id: perceptron_4dfp.c,v 1.8 2011/08/06 03:22:00 avi Exp $";

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm (program);
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

int **calloc_int2 (int n1, int n2) {
	int	i;
	int	**a;

	if (!(a = (int **) malloc (n1 * sizeof (int *)))) errm (program);
	if (!(a[0] = (int *) calloc (n1 * n2, sizeof (int)))) errm (program);
	for (i = 0; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_int2 (int **a) {
	free (a[0]);
	free (a);
}

void usage () {
	fprintf (stderr, "Usage:\t%s <(4dfp|conc) fMRI> <(4dfp) WBmask> <(4dfp) GMmask> <W1> <W2> [<(4dfp) outroot>]\n", program);
	fprintf (stderr, " e.g.:\t%s grp1_zfrm.lst grp1_N grp2_zfrm.lst grp2_N\n", program);
	fprintf (stderr, "	option\n");
	fprintf (stderr, "	-f<txt>	specify frames-to-count format (default all)\n");
	fprintf (stderr, "	-R	abbreviate output rec file\n");
	fprintf (stderr, "	-N\toutput undefined voxels as NaN\n");
	fprintf (stderr, "	-Z\toutput undefined voxels as 0\n");
	fprintf (stderr, "	-E\toutput undefined voxels as 1.E-37 (default)\n");
	fprintf (stderr, "	-@<b|l>\toutput big or little endian (default fMRI endian)\n");
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*fp, *imgfp;
	IFH		ifh;
	char		imgroot[MAXL], w1file[MAXL], w2file[MAXL], WBroot[MAXL], GMroot[MAXL];
	char		outroot[MAXL] = "", imgfile[MAXL], WBfile[MAXL], GMfile[MAXL], outfile[MAXL];
	float		amin = FLT_MAX, amax = -FLT_MAX;

/**********************/
/* image dimensioning */
/**********************/
	CONC_BLOCK	conc_block;		/* conc i/o control block */
	float		*imgt;			/* one volume */
	float		*imga;			/* voxelwise mean */
	float		*imgv;			/* voxelwise var */
	int		*imgm;			/* mask of voxels defined at all time points */
	int		*imgW;			/* mask of whole brain */
	int		*imgG;			/* mask of gray matter */
	int		jndex, imgdim[4], mskdim[4], vdim;
	int		isbig, isbigm, orient, orientm, nvoxW = 0, nvoxG = 0;
	float		voxdim[3], voxdimm[3];
	char		control = '\0';

/*************************/
/* timeseries processing */
/*************************/
	float		**imgb;			/* bold data with time as first index */
	char		*format;
	int		npts, nnez;

/**************/
/* perceptron */
/**************/
	float		**imgr;			/* perceptron input */
	double		*w1_0, **w1, **w2;	/* perceptron weights */
	float		**hidden;		/* hiden layer */
	float		**imgo;			/* perceptron output */
	double		const_a = 1.0;		/* y = a*tanh(b*hidden) */
	double		const_b = 0.1;		/* y = a*tanh(b*hidden) */
	int		nout;

/***********/
/* utility */
/***********/
	double		u;
	int		c, i, j, k, m, ii, jj;
	char		*ptr, *str, command[MAXL], *string;
	char		*srgv[NHIDDEN];		/* string field pointers */

/*********/
/* flags */
/*********/
	int		format_flag = 0;
	int		conc_flag = 0;
	int		defined;
	int		debug = 0;
	int		NaN_flag = 'E';		/* 'E' 1.e-37; 'Z' 0.0; 'N' NaN; */
	int		status = 0;
	int		saverec = 1;

	printf ("%s\n", rcsid);
	setprog (program, argv);
	if (!(format = (char *) calloc (1024, sizeof (char)))) errm (program);
	strcpy (format, "");
	if (!(string = (char *) calloc (NHIDDEN*16 + 4, sizeof (char)))) errm (program);

/************************/
/* process command line */
/************************/
	k = 0; for (i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'f': strncpy (format, ptr, 1023);	*ptr = '\0'; break;
				case 'R': saverec = 0;				break;
				case 'N': case 'Z': case 'E': NaN_flag = c;	break;
				case 'd': debug++;				break;
				case '@': control = *ptr++;			*ptr = '\0'; break;
			}
		} else switch (k) {
			case 0:	getroot (argv[i], imgroot);
				conc_flag = (strstr (argv[i], ".conc") == argv[i] + strlen (imgroot));
									k++; break;
			case 1:	getroot (argv[i], WBroot);		k++; break;
			case 2:	getroot (argv[i], GMroot);		k++; break;
			case 3:	strcpy  (w1file,  argv[i]);		k++; break;
			case 4:	strcpy  (w2file,  argv[i]);		k++; break;
			case 5:	getroot (argv[i], outroot);		k++; break;
		}	
	}
	if (k < 5) usage ();

/*****************************/
/* get 4dfp stack dimensions */
/*****************************/
	if (conc_flag) {
		conc_init (&conc_block, program);
		conc_open (&conc_block, imgroot);
		strcpy (imgfile, conc_block.lstfile);
		for (k = 0; k < 4; k++) imgdim[k] = conc_block.imgdim[k];
		for (k = 0; k < 3; k++) voxdim[k] = conc_block.voxdim[k];
		isbig  = conc_block.isbig;
		orient = conc_block.orient;
	} else {
		sprintf (imgfile, "%s.4dfp.img", imgroot);
		if (Getifh (imgfile, &ifh)) errr (program, imgfile);
		for (k = 0; k < 4; k++) imgdim[k] = ifh.matrix_size[k];
		for (k = 0; k < 3; k++) voxdim[k] = ifh.scaling_factor[k];
		isbig = strcmp (ifh.imagedata_byte_order, "littleendian");
		orient = ifh.orientation;
		if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);
		printf ("Reading: %s\n", imgfile);
	}
	if (!control) control = (isbig) ? 'b' : 'l';
	vdim = imgdim[0]*imgdim[1]*imgdim[2];
	if (!(imgt = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imga = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgv = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgW = (int *)   calloc (vdim, sizeof (int))))   errm (program);
	if (!(imgG = (int *)   calloc (vdim, sizeof (int))))   errm (program);
	if (!(imgm = (int *)   calloc (vdim, sizeof (int))))   errm (program);
	for (jndex = 0; jndex < vdim; jndex++) imgm[jndex] = 1;

/************************************************/
/* read masks and check dimensional consistency */
/************************************************/
	if (get_4dfp_dimoe (WBroot, mskdim, voxdimm, &orientm, &isbigm)) exit (-1);
	status = (orientm != orient);
	for (j = 0; j < 3; j++) status |= (mskdim[j] != imgdim[j]);
	for (j = 0; j < 3; j++) status |= (fabs (voxdimm[j] - voxdim[j]) > 1.e-4);
	if (status) {
		fprintf (stderr, "%s: %s %s dimension mismatch\n", program, WBroot, imgroot);
		exit (-1);
	}
	printf ("Reading: %s\n", WBroot);
	sprintf (WBfile, "%s.4dfp.img", WBroot);
	if (!(fp = fopen (WBfile, "rb")) || eread (imgt, vdim, isbigm, fp)
	|| fclose (fp)) errr (program, WBfile);
	for (i = 0; i < vdim; i++) if (isnormal(imgt[i]) && imgt[i] != (float) 1.e-37) {
		imgW[i] = 1;
		nvoxW++;
	}

	if (get_4dfp_dimoe (GMroot, mskdim, voxdimm, &orientm, &isbigm)) exit (-1);
	status = (orientm != orient);
	for (j = 0; j < 3; j++) status |= (mskdim[j] != imgdim[j]);
	for (j = 0; j < 3; j++) status |= (fabs (voxdimm[j] - voxdim[j]) > 1.e-4);
	if (status) {
		fprintf (stderr, "%s: %s %s dimension mismatch\n", program, GMroot, imgroot);
		exit (-1);
	}
	printf ("Reading: %s\n", GMroot);
	sprintf (GMfile, "%s.4dfp.img", GMroot);
	if (!(fp = fopen (GMfile, "rb")) || eread (imgt, vdim, isbigm, fp)
	|| fclose (fp)) errr (program, GMfile);
	for (i = 0; i < vdim; i++) if (isnormal(imgt[i]) && imgt[i] != (float) 1.e-37) {
		imgG[i] = 1;
		nvoxG++;
	}

/**************************************************/
/* read weights and check dimensional consistency */
/**************************************************/
	if (!(w1_0 = (double *) calloc (NHIDDEN, sizeof (double)))) errm (program);	/* bias column */
	w1 = calloc_double2 (NHIDDEN, nvoxG);
	printf ("Reading: %s\n", w1file);
	if (!(fp = fopen (w1file, "r"))) errr (program, w1file);
	for (k = 0; k <= nvoxG; k++) {
		if (!(fgets (string, NHIDDEN*16 + 1, fp))) errr (program, w1file);
		if (!strrchr (string, '\n')) {
			fprintf (stderr, "%s: %s exceeds line length limit (%d chars)\n", program, w1file, NHIDDEN*16);
			exit (-1);
		}
		ptr = string; while (ptr = strpbrk (ptr, "[],")) *ptr = '\x20';	/* convert '[', ']', ',' to space */
		if (!(m = split (string, srgv, NHIDDEN))) continue;
		if (m != NHIDDEN) {
			fprintf (stderr, "%s: %s column count not %d\n", program, w2file, NHIDDEN);
			exit (-1);
		}
		if (!k) {
			for (i = 0; i < NHIDDEN; i++) w1_0[i]  = atof (srgv[i]);
		} else {
			for (i = 0; i < NHIDDEN; i++) w1[i][k - 1] = atof (srgv[i]);
		}
	}
	assert (k == nvoxG + 1);
	if (ptr = (fgets (string, NHIDDEN*16 + 1, fp))) {
		fprintf (stderr, "%s: %s line count exceeds number of GM voxels + 1 (%d)\n", program, w1file, nvoxG + 1);
		exit (-1);
	}
	if (fclose (fp)) errr (program, w1file);
	for (i = 0; i < 10; i++) printf ("%10.6f", w1_0[i]); printf (" ...\n");

	if (!(fp = fopen (w2file, "r"))) errr (program, w2file);
	printf ("Reading: %s\n", w2file);
	for (k = 0; k < NHIDDEN; k++) {
		if (!(fgets (string, NHIDDEN*16 + 1, fp))) errr (program, w2file);
		if (!strrchr (string, '\n')) {
			fprintf (stderr, "%s: %s exceeds line length limit (%d chars)\n", program, w2file, NHIDDEN*16);
			exit (-1);
		}
		ptr = string; while (ptr = strpbrk (ptr, "[],")) *ptr = '\x20';	/* convert '[', ']', ',' to space */
		if (!(m = split (string, srgv, NHIDDEN))) continue;
		if (!k) {
			nout = m;
			w2 = calloc_double2 (NHIDDEN, nout);
		} else {
			if (m != nout) {
				fprintf (stderr, "%s: %s format error\n", program, w2file);
				exit (-1);
			}
		}
		for (i = 0; i < nout; i++) w2[k][i] = atof (srgv[i]);
	}
	assert (k == NHIDDEN);
	if (ptr = (fgets (string, NHIDDEN*16 + 1, fp))) {
		fprintf (stderr, "%s: %s line count exceeds (%d)\n", program, w2file, NHIDDEN);
		exit (-1);
	}
	if (fclose (fp)) errr (program, w2file);
	for (i = 0; i < nout; i++) printf ("%10.6f", w2[0][i]); printf ("\n");

/******************************/
/* set frames-to-count format */
/******************************/
	if (!(format = (char *) realloc (format, (imgdim[3] + 1)*sizeof (char)))) errm (program);
	if (strlen (format)) {
		if (k = expandf (format, imgdim[3] + 1)) exit (-1);
	} else {
		for (k = 0; k < imgdim[3]; k++) format[k] = '+';
		format[k] = '\0';
	}
	printf ("%s\n", format);
	npts = strlen (format);
	for (nnez = k = 0; k < imgdim[3]; k++) if (format[k] != 'x') nnez++;
	printf ("%s: format defined for %d frames, %d exluded\n", program, npts, npts - nnez);
	if (strlen (format) != imgdim[3]) {
		fprintf (stderr, "%s: format length mismatch\n", program);
		exit (-1);
	}

/********************************/
/* precondition fMRI timeseries */
/********************************/
	imgb = calloc_float2 (vdim, nnez);
	printf ("reading frame");
	for (k = i = 0; i < imgdim[3]; i++) {
		if (format[i] == 'x') continue;
		printf (" %d", i + 1); fflush (stdout);
		if (conc_flag) {
			conc_seek     (&conc_block, i);
			conc_read_vol (&conc_block, imgt);
		} else {
			if (fseek (imgfp, (long) i*vdim*sizeof(float), SEEK_SET)
			||  eread (imgt, vdim, isbig, imgfp)) errr (program, imgfile);
		}
		for (jndex = 0; jndex < vdim; jndex++) {
			if (!isnormal(imgt[jndex]) || imgt[jndex] == (float) 1.e-37) imgm[jndex] = 0;
			imga[jndex]	+= imgt[jndex];
			imgv[jndex]	+= imgt[jndex]*imgt[jndex];
			imgb[jndex][k]	=  imgt[jndex];
		}
		k++;
	} printf ("\n");  fflush (stdout);
	assert (k == nnez);
	for (jndex = 0; jndex < vdim; jndex++) {
		imga[jndex] /= nnez;
		imgv[jndex] /= nnez;
		imgv[jndex] -= imga[jndex]*imga[jndex];
		if (imgv[jndex] < 1.e-6) imgm[jndex] = 0;
	}
/*******************************/
/* remove mean from each voxel */
/*******************************/
	printf ("%s: removing mean from fMRI timeseries...\n", program);
	for (jndex = 0; jndex < vdim; jndex++) if (imgW[jndex] || imgG[jndex]) {
		for (k = 0; k < nnez; k++) imgb[jndex][k] -= imga[jndex];
	}

/********************************************************/
/* compute Pearson correlation for selected voxel pairs */
/********************************************************/
	get_time_usr (command), printf ("%s\n", command);
	printf ("%s: computing correlation matrix (%d rows)", program, nvoxW);
	imgr = calloc_float2 (nvoxW, nvoxG);		/* perceptron input */
	for (ii = i = 0; i < vdim; i++) if (imgW[i]) {
		if (!(ii % 1024)) printf (" %dk", ii/1024); fflush (stdout);
		for (jj = j = 0; j < vdim; j++) if (imgG[j]) {
			for (u = k = 0; k < nnez; k++) u += imgb[i][k]*imgb[j][k];
			imgr[ii][jj] = u/(nnez*sqrt(imgv[i]*imgv[j]));
			/* if (i == j) printf (" r=%.6f", imgr[ii][jj]); */
			jj++;
		}
		ii++;
	}
	printf ("\n");
	assert (ii == nvoxW && jj == nvoxG);
	if (0) for (ii = 0; ii < nvoxW; ii++) {
		for (jj = 0; jj < 10; jj++) printf ("%10.6f", imgr[ii][jj]);
		printf ("\n");
	}
	free_float2 (imgb);
	free (imga); free (imgv); 

/**********************/
/* hidden <- input*w1 */
/**********************/
	get_time_usr (command), printf ("%s\n", command);
	printf ("%s: computing hidden layer (%d rows)", program, nvoxW);
	hidden = calloc_float2 (nvoxW, NHIDDEN);
	for (i = 0; i < nvoxW; i++) {
		if (!(i % 1024)) printf (" %dk", i/1024); fflush (stdout);
		for (j = 0; j < NHIDDEN; j++) {
			u = w1_0[j];
			for (k = 0; k < nvoxG; k++) u += imgr[i][k]*w1[j][k];
			hidden[i][j] = const_a*tanh(const_b*u);
		}
	}
	printf ("\n");
	if (0)	for (i = 0; i < nvoxW; i++) {
		for (j = 0; j < NHIDDEN; j++) printf ("%10.6f", hidden[i][j]);
		printf ("\n");
	}

/*********************/
/* imgo <- hidden*w2 */
/*********************/
	get_time_usr (command), printf ("%s\n", command);
	printf ("%s: computing output volume", program, nvoxW);
	imgo = calloc_float2 (nout, nvoxW);
	for (j = 0; j < nout; j++) {
		printf (" %d", j + 1); fflush (stdout);
		for (i = 0; i < nvoxW; i++) {
			for (u = k = 0; k < NHIDDEN; k++) u += hidden[i][k]*w2[k][j];
			imgo[j][i] = u;
		}
	}
	printf ("\n");
	if (0)	for (i = 0; i < nvoxW; i++)  {
		for (j = 0; j < nout; j++) printf ("%10.6f", imgo[j][i]);
		printf ("\n");
	}

	if (!strlen (outroot)) goto DONE;
/****************/
/* write result */
/****************/
	amin = FLT_MAX; amax = -amin;
	sprintf (outfile, "%s.4dfp.img", outroot);
	printf ("Writing: %s\n", outfile);
	if (!(imgfp = fopen (outfile, "wb"))) errw (program, outfile);
	for (j = 0; j < nout; j++) {
		for (ii = i = 0; i < vdim; i++) {
			if (imgW[i]) {
				imgt[i] = imgo[j][ii++];
				if (imgt[i] > amax) amax = imgt[i];
				if (imgt[i] < amin) amin = imgt[i];
			} else switch (NaN_flag) {
				case 'Z': imgt[i] = 0.0;		break;
				case 'E': imgt[i] = (float) 1.e-37;	break;
				case 'N': imgt[i] = rnan ();		break;
			}
		}
		assert (ii == nvoxW);
		if (ewrite (imgt, vdim, control, imgfp)) errw (program, outfile);
	}
	if (fclose (imgfp)) errw (program, outfile);

/*******/
/* ifh */
/*******/
	imgdim[3] = nout;
	if (conc_flag) {
		writeifhmce (program, outfile, imgdim,
			conc_block.voxdim, conc_block.orient, conc_block.mmppix, conc_block.center, control);
	} else {
		writeifhmce (program, outfile, imgdim,
			ifh.scaling_factor, ifh.orientation, ifh.mmppix, ifh.center, control);
	}

/*******/
/* hdr */
/*******/
	sprintf (command, "ifh2hdr %s -r%.0fto%.0f", outroot, amin, amax);
	printf ("%s\n", command);
	status |= system (command);

/*******/
/* rec */
/*******/
	startrecle (outfile, argc, argv, rcsid, control);
	sprintf (command, "Hidden layer transform: y = %f*tanh(%f*x)\n", const_a, const_b);
	printrec (command);
	catrec (imgfile);
	catrec (WBfile);
	catrec (GMfile);
	endrec ();
	
DONE:	free (imgt); free (imgW); free (imgG); free (imgm);
	free (format); free (string);
	free (w1_0); free_double2 (w1); free_double2 (w2); free_float2 (imgr);
	free_float2 (hidden); free_float2 (imgo);
	get_time_usr (command), printf ("%s\n", command);
	exit (status);
}
