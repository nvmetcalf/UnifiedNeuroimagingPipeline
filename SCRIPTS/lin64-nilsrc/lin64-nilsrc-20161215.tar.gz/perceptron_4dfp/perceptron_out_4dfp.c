/*$Header: /data/petsun4/data1/src_solaris/perceptron_4dfp/RCS/perceptron_out_4dfp.c,v 1.1 2011/08/09 05:31:24 avi Exp $*/
/*$Log: perceptron_out_4dfp.c,v $
 * Revision 1.1  2011/08/09  05:31:24  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>		/* R_OK */
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <float.h>
#include <assert.h>
#ifndef _FEATURES_H		/* defined by math.h in Linux */
	#include <ieeefp.h>
	#include <sunmath.h>	/* isnormal() */
#endif
#include <endianio.h>
#include <Getifh.h>
#include <rec.h>

#define MAXL		256
#define TRAILER		"out"

float rnan (void) {
	union {
		float		r;
		unsigned int	j;
        } word;
	word.j = 0x7fffffff;
	return word.r;
}

void setprog (char *program, char **argv) {
	char *ptr;

	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; 
	else ptr++;
	strcpy (program, ptr);
}

/*************/
/* externals */
/*************/

/********************/
/* global variables */
/********************/
char		program[MAXL];
static char	rcsid[] = "$Id: perceptron_out_4dfp.c,v 1.1 2011/08/09 05:31:24 avi Exp $";

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm (program);
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

int **calloc_int2 (int n1, int n2) {
	int	i;
	int	**a;

	if (!(a = (int **) malloc (n1 * sizeof (int *)))) errm (program);
	if (!(a[0] = (int *) calloc (n1 * n2, sizeof (int)))) errm (program);
	for (i = 0; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_int2 (int **a) {
	free (a[0]);
	free (a);
}

void usage () {
	fprintf (stderr, "Usage:\t%s <(4dfp perceptron output>\n", program);
	fprintf (stderr, " e.g.:\t%s NC-11_perc\n", program);
	fprintf (stderr, "	option\n");
	fprintf (stderr, "	-a<str>	specify 4dfp output fileroot trailer (default = \"%s\")\n", TRAILER);
	fprintf (stderr, "	-R	abbreviate output rec file\n");
	fprintf (stderr, "	-N\toutput undefined voxels as NaN\n");
	fprintf (stderr, "	-Z\toutput undefined voxels as 0\n");
	fprintf (stderr, "	-E\toutput undefined voxels as 1.E-37 (default)\n");
	fprintf (stderr, "	-@<b|l>\toutput big or little endian (default fMRI endian)\n");
	exit (1);
}

int main (int argc, char *argv[]) {
	FILE		*imgfp;
	IFH		ifh;
	char		imgroot[MAXL], outroot[MAXL] = "", imgfile[MAXL], outfile[MAXL];
	char		trailer[MAXL] = TRAILER;

/**********************/
/* image dimensioning */
/**********************/
	float		*imgt;			/* one volume */
	float		*imga;			/* voxelwise mean */
	float		*imgv;			/* voxelwise var */
	float		**imgp;			/* perceptron result */
	int		imgdim[4], mskdim[4], vdim;
	int		isbig, isbigm, orient, orientm, nvoxW = 0, nvoxG = 0;
	float		voxdim[3], voxdimm[3];
	char		control = '\0';
	float		amin = FLT_MAX, amax = -FLT_MAX;

/***********/
/* utility */
/***********/
	double		u;
	int		c, i, j, k;
	char		*ptr, command[MAXL];
	char		*srgv[MAXL];		/* string field pointers */

/*********/
/* flags */
/*********/
	int		defined;
	int		debug = 0;
	int		NaN_flag = 'E';		/* 'E' 1.e-37; 'Z' 0.0; 'N' NaN; */
	int		status = 0;
	int		saverec = 1;

	printf ("%s\n", rcsid);
	setprog (program, argv);
/************************/
/* process command line */
/************************/
	k = 0; for (i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'R': saverec = 0;				break;
				case 'N': case 'Z': case 'E': NaN_flag = c;	break;
				case 'd': debug++;				break;
				case 'a': strncpy (trailer, ptr, MAXL - 1);	*ptr = '\0'; break;
				case '@': control = *ptr++;			*ptr = '\0'; break;
			}
		} else switch (k) {
			case 0:	getroot (argv[i], imgroot);			k++; break;
		}	
	}
	if (k < 1) usage ();

/*****************************/
/* get 4dfp stack dimensions */
/*****************************/
	sprintf (imgfile, "%s.4dfp.img", imgroot);
	if (Getifh (imgfile, &ifh)) errr (program, imgfile);
	for (k = 0; k < 4; k++) imgdim[k] = ifh.matrix_size[k];
	for (k = 0; k < 3; k++) voxdim[k] = ifh.scaling_factor[k];
	isbig = strcmp (ifh.imagedata_byte_order, "littleendian");
	orient = ifh.orientation;
	if (!control) control = (isbig) ? 'b' : 'l';

	vdim = imgdim[0]*imgdim[1]*imgdim[2];
	if (!(imgt = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imga = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgv = (float *) calloc (vdim, sizeof (float)))) errm (program);
	imgp = calloc_float2 (imgdim[3], vdim);

	if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);
	printf ("Reading: %s\n", imgfile);
	for (j = 0; j < imgdim[3]; j++) {
		if (eread (imgp[j], vdim, isbig, imgfp)) errr (program, imgfile);
	}

/***********/
/* process */
/***********/
	amin = FLT_MAX; amax = -amin;
	for (j = 0; j < imgdim[3]; j++) {
		for (i = 0; i < vdim; i++) {
			defined = (isnormal (imgp[j][i]) && imgp[j][i] != (float) 1.e-37);
			if (defined) {
				if (imgp[j][i] > amax) amax = imgp[j][i];
				if (imgp[j][i] < amin) amin = imgp[j][i];
			} else switch (NaN_flag) {
				case 'Z': imgp[j][i] = 0.0;		break;
				case 'E': imgp[j][i] = (float) 1.e-37;	break;
				case 'N': imgp[j][i] = rnan ();		break;
			}
		}
	}

/****************/
/* write result */
/****************/
	sprintf (outroot, "%s_%s", imgroot, trailer);
	sprintf (outfile, "%s.4dfp.img", outroot);
	printf ("Writing: %s\n", outfile);
	if (!(imgfp = fopen (outfile, "wb"))) errw (program, outfile);
	for (j = 0; j < imgdim[3]; j++) {
		if (ewrite (imgp[j], vdim, control, imgfp)) errw (program, outfile);
	}
	if (fclose (imgfp)) errw (program, outfile);

/*******/
/* ifh */
/*******/
	writeifhmce (program, outfile, imgdim,
		ifh.scaling_factor, ifh.orientation, ifh.mmppix, ifh.center, control);

/*******/
/* hdr */
/*******/
	sprintf (command, "ifh2hdr %s -r%.0fto%.0f", outroot, amin, amax);
	printf ("%s\n", command);
	status |= system (command);

/*******/
/* rec */
/*******/
	startrecle (outfile, argc, argv, rcsid, control);
	printrec (command);
	catrec (imgfile);
	endrec ();
	
DONE:	free (imgt); free (imga); free (imgv); free_float2 (imgp);
	exit (status);
}
