/*$Header: /data/petsun4/data1/src_solaris/actmapf_4dfp/RCS/glmB_4dfp.c,v 1.5 2015/07/04 02:37:33 avi Exp $*/
/*$Log: glmB_4dfp.c,v $
 * Revision 1.5  2015/07/04  02:37:33  avi
 * do not exit on ill-conditioned design matrix condition; set output result to 1.e-37; define imgc
 *
 * Revision 1.4  2015/05/18  03:40:06  avi
 * prevent ill-conditioned design matrices when number of samples < number of performance measures
 *
 * Revision 1.3  2015/05/18  02:10:43  avi
 * partial correlation enabled. version of Dec 9, 2012
 *
 * Revision 1.2  2012/12/07  02:13:03  avi
 * appears to work correctly
 *
 * Revision 1.1  2012/12/06  03:40:59  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <float.h>
#ifndef _FEATURES_H		/* defined by math.h in Linux */
	#include <sunmath.h>	/* isnormal() */
#endif
#include <string.h>
#include <unistd.h>			/* getpid () */
#include <Getifh.h>
#include <endianio.h>
#include <rec.h>
#include <conc.h>			/* defines MAXL */

#define MAXC		512		/* maximum number of input profle columns */	
#define CTRAIL		"pbeta"
#define BTRAIL		"tbeta"
#define PTRAIL		"pcorr"
#define TTRAIL		"tcorr"
#define MAX(a,b)	(a>b? a:b)
#define MIN(a,b)	(a<b? a:b)

int	expandf (char *string, int len);						/* expandf.c */
void	dmatinv_ (double *a, int *n, double *det);					/* dmatinv.f */
void    deigen_ (double *e, double *w, int *n);						/* deigen.f */

/********************/
/* global variables */
/********************/
static char	rcsid[] = "$Id: glmB_4dfp.c,v 1.5 2015/07/04 02:37:33 avi Exp $";
static char	program[MAXL];
static int	debug = 0;

double **calloc_double2 (int n1, int n2) {
	int	i;
	double	**a;

	if (!(a = (double **) malloc (n1 * sizeof (double *)))) errm (program);
	if (!(a[0] = (double *) calloc (n1 * n2, sizeof (double)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_double2 (double **a) {
	free (a[0]);
	free (a);
}

float **calloc_float2 (int n1, int n2) {
	int	i;
	float	**a;

	if (!(a = (float **) malloc (n1 * sizeof (float *)))) errm (program);
	if (!(a[0] = (float *) calloc (n1 * n2, sizeof (float)))) errm (program);
	for (i = 1; i < n1; i++) a[i] = a[0] + i*n2;
	return a;
}

void free_float2 (float **a) {
	free (a[0]);
	free (a);
}

double dzeromean (double *f, int npts) {
	int		i;
	double		u;

	for (u = i = 0; i < npts; i++) u += f[i];
	u /= npts;
	for (i = 0; i < npts; i++) f[i] -= u;
	if (debug) for (i = 0; i < npts; i++) {
		printf ("%4d %10.6f\n", i + 1, f[i]);
	}
	return u;
}

double dunitvar (double *f, int npts) {
	int		i;
	double		v;

	for (v = i = 0; i < npts; i++) v += f[i]*f[i];
	v /= npts;
	for (i = 0; i < npts; i++) f[i] /= sqrt (v);
	if (debug) for (i = 0; i < npts; i++) {
		printf ("%4d %10.6f\n", i + 1, f[i]);
	}
	return v;
}

void dmatlst (double **a, int n) {
	int	i, j;

	for (i = 0; i < n; i++) {
		for (j = 0; j < n; j++) printf ("%11.7f", a[j][i]);
		printf ("\n");
	}
}

int isvalid (float t) {
	return (isnormal (t) && t != (float) 1.e-37);
}

void usage (char *program) {
	fprintf (stderr, "Usage:\t%s <format> <profile> <4dfp|conc input>\n", program);
	fprintf (stderr, "e.g.,\t%s \"4x124+\" doubletask.txt b1_rmsp_dbnd_xr3d_norm\n", program);
	fprintf (stderr, "\toption\n");
	fprintf (stderr, "\t-D\tsave input image diagnostics (valid voxel count, mean, sd)\n");
	fprintf (stderr, "\t-o[str]\tsave partial beta images with specified trailer (default = \"%s\")\n", CTRAIL);
	fprintf (stderr, "\t-b[str]\tsave total   beta images with specified trailer (default = \"%s\")\n", BTRAIL);
	fprintf (stderr, "\t-p[str]\tsave partial corr images with specified trailer (default = \"%s\")\n", PTRAIL);
	fprintf (stderr, "\t-t[str]\tsave total   corr images with specified trailer (default = \"%s\")\n", TTRAIL);
	fprintf (stderr, "\t-@<b|l>\toutput big or little endian (default input endian)\n");
	fprintf (stderr, "N.B.:\tconc files must have extension \"conc\"\n");
	fprintf (stderr, "N.B.:\t<profile> lists regressor profiles (ASCII npts x ncol; '#' introduces comments)\n");
	fprintf (stderr, "N.B.:\t<profile> line limits are %d chars and %d fields\n", MAXC*10, MAXC);
	fprintf (stderr, "N.B.:\toptions -o -p require design matrix inversion; dimension limit 256\n");
	exit (1);
}

int main (int argc, char *argv[]) {
/**********************/
/* filename variables */
/**********************/
	FILE		*tmpfp, *imgfp, *outfp, *profp;
	char		coeroot[4*MAXL], coefile[4*MAXL];	/* coefficients image */
	char		imgroot[4*MAXL], imgfile[4*MAXL];	/* input 4dfp stack filename */
	char		outroot[4*MAXL], outfile[4*MAXL], tmpfile[4*MAXL], profile[4*MAXL];
	char		ctrail[MAXL] = CTRAIL;
	char		ptrail[MAXL] = PTRAIL;
	char		btrail[MAXL] = BTRAIL;
	char		ttrail[MAXL] = TTRAIL;

/**********************/
/* image dimensioning */
/**********************/
	CONC_BLOCK	conc_block;		/* conc i/o control block */
	IFH		ifhimg;
	float		**beta;			/* regression  coefficients */
	float		**imgr, **imgp;		/* total and partial correlation coefficients */
	float		**imgb;			/* bold data with voxel as first index */
	float		*imgt;			/* one volume */
	float		*imga;			/* voxelwise mean */
	float		*imgv;			/* voxelwise var */
	int		*imgn;			/* voxlewise count of valid voxels */
	char		*imgc;			/* voxlewise map of ill-conditioned voxels */
	float		voxdim[3], mmppix[3], center[3];
	int		jndex, imgdim[4], vdim;	/* image dimensions */
	int		isbig;
	char		control = '\0';

/*************************/
/* timeseries processing */
/*************************/
	char		*format;
	float		fmin, fmax;
	double		**f, **g, **a, **ainv, **ginvt, **e, **w, **omega, *sigma, det, cndnum;
	int		ppts, npts, nnez, ncol, ncolp1;
	int		ix, iy, iz;

/***********/
/* utility */
/***********/
	char		command[4*MAXL], string[MAXC*10 + 4], *ptr, *srgv[MAXC];
	int		c, i, j, k, m;
	double		q;
	float		t;

/*********/
/* flags */
/*********/
	int		conc_flag = 0;
	int		zeromean_flag = 1;
	int		save_pbeta = 0;
	int		save_tbeta = 0;
	int		save_pcorr = 0;
	int		save_tcorr = 0;
	int		save_diagn = 0;
	int		ginvt_flag;		/* invert design matrix */
	int		imgr_flag;
	int		status = 0;

	printf ("%s\n", rcsid);
	if (!(ptr = strrchr (argv[0], '/'))) ptr = argv[0]; else ptr++;
	strcpy (program, ptr);

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'd': debug++;			break;
				case 'Z': zeromean_flag = 0;		break;
				case 'D': save_diagn++; 		break;
				case '@': control = *ptr++;		*ptr = '\0'; break;
				case 'o': save_pbeta++;
					if (strlen (ptr)) strcpy (ctrail, ptr);	*ptr = '\0'; break;
				case 'b': save_tbeta++;
					if (strlen (ptr)) strcpy (btrail, ptr);	*ptr = '\0'; break;
				case 'p': save_pcorr++;
					if (strlen (ptr)) strcpy (ptrail, ptr);	*ptr = '\0'; break;
				case 't': save_tcorr++;
					if (strlen (ptr)) strcpy (ttrail, ptr);	*ptr = '\0'; break;
			}
		}
		else switch (k) {
			case 0:	m = strlen (argv[i]) + 2;
				if (!(format = (char *) calloc (m, sizeof (char)))) errm (program);
				strcpy  (format,  argv[i]);		k++; break;
			case 1:	strcpy  (profile, argv[i]);		k++; break;
			case 2:	getroot (argv[i], imgroot);
				conc_flag = (strstr (argv[i], ".conc") == argv[i] + strlen (imgroot));
									k++; break;
		}	
	}
	if (k < 3) usage (program);

/****************/
/* read profile */
/****************/
	printf ("Reading: %s\n", profile);
	if (!(profp = fopen (profile, "r"))) errr (program, profile);
	ppts = 0; while (fgets (string, MAXC*10 + 1, profp)) {
		if (!strrchr (string, '\n')) {
			fprintf (stderr, "%s: %s exceeds line length limit (%d chars)\n", program, profile, MAXC*10);
			exit (-1);
		}
		if (!(m = split (string, srgv, MAXC))) continue;
		if (!ppts) {
			ncol = m;
			printf ("ncol=%d\n", ncol);
		} else {
			if (m != ncol) {
				fprintf (stderr, "%s: %s format error\n", program, profile);
				exit (-1);
			}
		}
		ppts++;
	}

/****************/
/* parse format */
/****************/
	if (!(format = (char *) realloc (format, (ppts + 1)*sizeof (char)))) errm (program);
	if (k = expandf (format, ppts + 1)) exit (-1);
	printf ("%s\n", format);
	npts = strlen (format);
	for (nnez = k = 0; k < npts; k++) if (format[k] != 'x') nnez++;
	printf ("%s: time series defined for %d frames, %d excluded\n", program, npts, npts - nnez);
	if (ppts != npts) {
		fprintf (stderr, "%s: %s/format length mismatch\n", program, profile);
		exit (-1);
	}

	if (save_pcorr && ncol > 64) {
		fprintf (stderr, "%s: partial correlation matrix dimension limit (64) exceeded\n", program);
		exit (-1);
	}
	ginvt_flag = save_pbeta;
	if (ginvt_flag && ncol > 256) {
		fprintf (stderr, "%s: design matrix inversion dimension limit (256) exceeded\n", program);
		exit (-1);
	}

	f = calloc_double2 (ncol, nnez);	/* profile as read */
	g = calloc_double2 (ncol, nnez);	/* voxel-specific profile */
	if (!(sigma = (double *) malloc (ncol*sizeof (double)))) errm (program);
	rewind (profp);
	i = k = 0; while (fgets (string, MAXC*10 + 1, profp)) {
		if (!(m = split (string, srgv, MAXC))) continue;
		if (format[i] != 'x') {
			for (j = 0; j < ncol; j++) {
				if (isnan (q = atof (srgv[j]))) {
					fprintf (stderr, "%s: %s contains NaN\n", program, profile);
					exit (-1);
				}
				f[j][k] = q;
			}
			k++;
		}
		i++;
	}
	fclose (profp);
	assert (i == npts); assert (k == nnez);

/*****************************/
/* get 4dfp stack dimensions */
/*****************************/
	if (conc_flag) {
		conc_init (&conc_block, program);
		conc_open (&conc_block, imgroot);
		strcpy (imgfile, conc_block.lstfile);
		for (k = 0; k < 4; k++) imgdim[k] = conc_block.imgdim[k];
		isbig = conc_block.isbig;
	} else {
		sprintf (imgfile, "%s.4dfp.img", imgroot);
		if (Getifh (imgfile, &ifhimg)) errr (program, imgfile);
		for (k = 0; k < 4; k++) imgdim[k] = ifhimg.matrix_size[k];
		isbig = strcmp (ifhimg.imagedata_byte_order, "littleendian");
		if (!(imgfp = fopen (imgfile, "rb"))) errr (program, imgfile);
		printf ("Reading: %s\n", imgfile);
	}
	if (!control) control = (isbig) ? 'b' : 'l';
	vdim = imgdim[0]*imgdim[1]*imgdim[2];
	if (imgdim[3] < npts) {
		fprintf (stderr, "%s: more defined npts (%d) than frames (%d)\n", program, npts, imgdim[3]);
		exit (-1);
	}

	if (ginvt_flag || save_pcorr) {		/* allocate arrays used for profile algebra */
		ginvt	= calloc_double2 (ncol, nnez);
		a	= calloc_double2 (ncol, ncol);
		ainv	= calloc_double2 (ncol, ncol);
		e	= calloc_double2 (ncol, ncol);
		w	= calloc_double2 (ncol, ncol);
		beta	= calloc_float2  (ncol, vdim);
	}

	imgr_flag = save_tcorr || save_pcorr || save_tbeta;
	if (imgr_flag) {
		imgr = calloc_float2 (ncol, vdim);
	}
	if (save_pcorr) {
		imgp = calloc_float2 (ncol, vdim);
		ncolp1 = ncol + 1;
		omega = calloc_double2 (ncolp1, ncolp1);
	}

	if (!(imga = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgv = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgt = (float *) calloc (vdim, sizeof (float)))) errm (program);
	if (!(imgn = (int *)   calloc (vdim, sizeof (int))))   errm (program);
	if (!(imgc = (char *)  calloc (vdim, sizeof (char))))  errm (program);

/****************************************************/
/* load    imgb[jndex][iframe]                      */
/* compute valid voxel count          = imgn[jndex] */
/*         valid voxel value mean     = imga[jndex] */
/*         valid voxel value variance = imgv[jndex] */
/****************************************************/
	imgb = calloc_float2 (vdim, nnez);
	printf ("reading frame");
	for (k = i = 0; i < npts; i++) {
		if (format[i] == 'x') continue;
		printf (" %d", i + 1); fflush (stdout);
		if (conc_flag) {
			conc_seek     (&conc_block, i);
			conc_read_vol (&conc_block, imgt);
		} else {
			if (fseek (imgfp, (long) i*vdim*sizeof(float), SEEK_SET)
			||  eread (imgt, vdim, isbig, imgfp)) errr (program, imgfile);
		}
		for (jndex = 0; jndex < vdim; jndex++) {
			t = imgb[jndex][k] = imgt[jndex];
			if (isvalid (t)) {
				imgn[jndex]++;
				imga[jndex] += t;
				imgv[jndex] += t*t;
			}
		}
		k++;
	} printf ("\n");  fflush (stdout);
	assert (k == nnez);
	for (jndex = 0; jndex < vdim; jndex++) if (imgn[jndex]) {
		imga[jndex] /= imgn[jndex];
		imgv[jndex] /= imgn[jndex];
		imgv[jndex] -= imga[jndex]*imga[jndex];
	}

	if (save_diagn) for (i = 0; i < 3; i++) {
/***************************/
/* write diagnostic images */
/***************************/
		switch (i) {
			case 0:	sprintf (outroot, "%s_%s", imgroot, "nvox");
				for (jndex = 0; jndex < vdim; jndex++) imgt[jndex] = imgn[jndex];
				break;
			case 1: sprintf (outroot, "%s_%s", imgroot, "mean");
				for (jndex = 0; jndex < vdim; jndex++) imgt[jndex] = imga[jndex];
				break;
			case 2: sprintf (outroot, "%s_%s", imgroot, "sd");
				for (jndex = 0; jndex < vdim; jndex++) imgt[jndex] = sqrt(imgv[jndex]);;
				break;
		}
		sprintf (outfile, "%s.4dfp.img", outroot);
		printf ("Writing: %s\n", outfile);
		if (!(outfp = fopen (outfile, "wb"))) errw (program, outfile);
		if (ewrite (imgt, vdim, control, outfp)) errw (program, outfile);
		if (fclose (outfp)) errw (program, outfile);
		imgdim[3] = 1;
		if (conc_flag) {
			writeifhmce (program, outfile, imgdim,
				conc_block.voxdim, conc_block.orient, conc_block.mmppix, conc_block.center, control);
		} else {
			writeifhmce (program, outfile, imgdim,
				ifhimg.scaling_factor, ifhimg.orientation, ifhimg.mmppix, ifhimg.center, control);
		}
		fmin = FLT_MAX; fmax = -fmin;
		for (jndex = 0; jndex < vdim; jndex++) {
			fmin = MIN (fmin, imgt[jndex]);
			fmax = MAX (fmax, imgt[jndex]);
		}
		sprintf (command, "ifh2hdr -r%.0fto%.0f %s", 0., fmax, outfile);
		printf ("%s\n", command); status |= system (command);
		startrecle (outfile, argc, argv, rcsid, control);
		catrec (tmpfile);
		catrec (imgfile);
		endrec ();
	}

/***************************/
/* compute mapping results */
/***************************/
	printf ("processing slice");
	for (jndex = 0; jndex < vdim; jndex++) {
		m = imgdim[0]*imgdim[1];
		if (!(jndex % m)) printf (" %d", jndex/m + 1); fflush (stdout);
		for (k = i = 0; i < nnez; i++) {
			if (isvalid (imgb[jndex][i])) {
				for (j = 0; j < ncol; j++) g[j][k] = f[j][i];
				k++;
			}
		}
		assert (k == imgn[jndex]);
/**********************************************/
/* make input profile zero mean unit variance */
/**********************************************/
		for (j = 0; j < ncol; j++) {
			if (zeromean_flag) dzeromean (g[j], imgn[jndex]);
			sigma[j] = sqrt (dunitvar (g[j], imgn[jndex]));
		}

		if (ginvt_flag || save_pcorr) {
/***************************************************/
/* computation possible only if imgn[jndex] > ncol */
/***************************************************/
			if (imgn[jndex] <= ncol) continue;	/* next voxel */

/*****************************************************/ 
/* compute voxel-specific profile correlation matrix */
/*****************************************************/ 
			for (i = 0; i < ncol; i++) {
				for (j = i; j < ncol; j++) {
					for (q = k = 0; k < imgn[jndex]; k++) q += g[i][k]*g[j][k];
					a[i][j] = a[j][i] = q/imgn[jndex];
				}
			}

/************************/
/* invert design matrix */
/************************/
			for (i = 0; i < ncol; i++) for (j = 0; j < ncol; j++) ainv[i][j] = e[i][j] = a[i][j];
			deigen_ (e[0], w[0], &ncol);
			cndnum = e[0][0]/e[ncol - 1][ncol - 1];
			if (cndnum < 0. || cndnum > 1.e4) {
				k = jndex;
				iz = k/(imgdim[0]*imgdim[1]);	k %= imgdim[0]*imgdim[1];
				iy = k/ imgdim[0];		k %= imgdim[0];
				ix = k;
				assert (jndex == ix + imgdim[0]*(iy + iz*imgdim[1]));
				fprintf (stderr, "%s: ill-conditioned design matrix voxel index %d\n", program, jndex);
				fprintf (stderr, "ix=%d iy=%d iz=%d (counting from 1 without analyze<->4dfp flips)\n", ix + 1, iy + 1, iz + 1);
				fprintf (stderr, "condition_number=%12.6e\n", cndnum);
				imgc[jndex]++;
			}
			dmatinv_ (ainv[0], &ncol, &det);
			for (i = 0; i < imgn[jndex]; i++) for (j = 0; j < ncol; j++) {
				for (ginvt[j][i] = k = 0; k < ncol; k++) ginvt[j][i] += ainv[j][k]*g[k][i];
			}
		}
		if (0) {
			printf ("a   \n"); dmatlst (a,    ncol);
			printf ("ainv\n"); dmatlst (ainv, ncol);
			printf ("e\n");    dmatlst (e,    ncol);
			printf ("w\n");    dmatlst (w,    ncol);
		}
		for (j = 0; j < ncol; j++) {
			for (k = i = 0; i < nnez; i++) if (isvalid (imgb[jndex][i])) {
				if (ginvt_flag)	beta[j][jndex] += imgb[jndex][i]*ginvt[j][k];
				if (imgr_flag)  imgr[j][jndex] += imgb[jndex][i]*    g[j][k];
				k++;
			}
			assert (k == imgn[jndex]);
			if (imgn[jndex] > 1) {
				if (ginvt_flag)	beta[j][jndex] /= imgn[jndex];
				if (imgr_flag)  imgr[j][jndex] /= imgn[jndex]*sqrt(imgv[jndex]);
			}
		}
		if (save_pcorr && imgn[jndex] > 1) {
			omega[0][0] = 1.;
			for (j = 0; j < ncol; j++) {
				omega[j + 1][0] = omega[0][j + 1] = imgr[j][jndex];
				for (i = 0; i < ncol; i++) omega[j + 1][i + 1] = a[j][i];
			}
			dmatinv_ (omega[0], &ncolp1, &det);
			for (j = 0; j < ncol; j++) {
				imgp[j][jndex] = -omega[0][j + 1]/sqrt (omega[0][0]*omega[j + 1][j + 1]);
			}
		}
	} printf ("\n");  fflush (stdout);
	free_float2 (imgb); 

/********************************/
/* create temp process log file */
/********************************/
	sprintf (tmpfile, "temp%d", getpid ());
	if (!(tmpfp = fopen (tmpfile, "w"))) errw (program, tmpfile);
	fprintf (tmpfp, "Timepoint counts: counted=%d  skipped=%d\n", nnez, npts - nnez);
	fprintf (tmpfp, "%s\n", format);
	fclose (tmpfp);

	if (save_pbeta) {
/****************************************/
/* save partial regression coefficients */
/****************************************/
		sprintf (outroot, "%s_%s", imgroot, ctrail);
		sprintf (outfile, "%s.4dfp.img", outroot);
		fmin = FLT_MAX; fmax = -fmin;
		for (j = 0; j < ncol; j++) {
			for (jndex = 0; jndex < vdim; jndex++) {
				if (!imgc[jndex]) {	/* only count well-conditioned voxels */
					fmin = MIN (fmin, beta[j][jndex]);
					fmax = MAX (fmax, beta[j][jndex]);
				} else {
					beta[j][jndex] = 1.e-37;
				}
			}
		}
		printf ("Writing: %s\n", outfile);
		printf ("Max = %10.3f,\tMin = %10.3f\n", fmax, fmin);
		if (!(outfp = fopen (outfile, "wb")) || ewrite (beta[0], vdim*ncol, control, outfp)
		|| fclose (outfp)) errw (program, outfile);
		imgdim[3] = ncol;
		if (conc_flag) {
			writeifhmce (program, outfile, imgdim,
				conc_block.voxdim, conc_block.orient, conc_block.mmppix, conc_block.center, control);
		} else {
			writeifhmce (program, outfile, imgdim,
				ifhimg.scaling_factor, ifhimg.orientation, ifhimg.mmppix, ifhimg.center, control);
		}
		sprintf (command, "ifh2hdr -r%dto%d %s", (int) (fmin-0.5), (int) (fmax+0.5), outfile);
		printf ("%s\n", command); status |= system (command);
		startrecle (outfile, argc, argv, rcsid, control);
		catrec (tmpfile);
		catrec (imgfile);
		endrec ();
	}

	if (save_tcorr) {
/***************************************/
/* save total correlation coefficients */
/***************************************/
		sprintf (outroot, "%s_%s", imgroot, ttrail);
		sprintf (outfile, "%s.4dfp.img", outroot);
		fmin = FLT_MAX; fmax = -fmin;
		for (jndex = 0; jndex < vdim; jndex++) for (j = 0; j < ncol; j++) {
			if (!imgn[jndex]) {
				 imgr[j][jndex] = 1.e-37;
			} else {
				fmin = MIN (fmin, imgr[j][jndex]);
				fmax = MAX (fmax, imgr[j][jndex]);
			}
		}
		printf ("Writing: %s\n", outfile);
		printf ("Max = %10.6f,\tMin = %10.6f\n", fmax, fmin);
		if (!(outfp = fopen (outfile, "wb")) || ewrite (imgr[0], vdim*ncol, control, outfp)
		|| fclose (outfp)) errw (program, outfile);
		imgdim[3] = ncol;
		if (conc_flag) {
			writeifhmce (program, outfile, imgdim,
				conc_block.voxdim, conc_block.orient, conc_block.mmppix, conc_block.center, control);
		} else {
			writeifhmce (program, outfile, imgdim,
				ifhimg.scaling_factor, ifhimg.orientation, ifhimg.mmppix, ifhimg.center, control);
		}
		sprintf (command, "ifh2hdr -r-1to1 %s", outfile);
		printf ("%s\n", command); status |= system (command);
		startrecle (outfile, argc, argv, rcsid, control);
		catrec (tmpfile);
		catrec (imgfile);
		endrec ();
	}

	if (save_tbeta) {
/**************************************************/
/* compute and save total regression coefficients */
/**************************************************/
		sprintf (outroot, "%s_%s", imgroot, btrail);
		sprintf (outfile, "%s.4dfp.img", outroot);
		if (!(outfp = fopen (outfile, "wb"))) errw (program, outfile);
		printf ("Writing: %s\n", outfile);
		fmin = FLT_MAX; fmax = -fmin;
		for (j = 0; j < ncol; j++) {
			for (jndex = 0; jndex < vdim; jndex++) {
				if (!imgn[jndex]) {
					 imgt[jndex] = 1.e-37;
				} else {
					imgt[jndex] = imgr[j][jndex]*sqrt(imgv[jndex])/sigma[j];
					fmin = MIN (fmin, imgt[jndex]);
					fmax = MAX (fmax, imgt[jndex]);
				}
			}
			if (ewrite (imgt, vdim, control, outfp)) errw (program, outfile);
		}
		if (fclose (outfp)) errw (program, outfile);
		printf ("Max = %10.6f,\tMin = %10.6f\n", fmax, fmin);
		imgdim[3] = ncol;
		if (conc_flag) {
			writeifhmce (program, outfile, imgdim,
				conc_block.voxdim, conc_block.orient, conc_block.mmppix, conc_block.center, control);
		} else {
			writeifhmce (program, outfile, imgdim,
				ifhimg.scaling_factor, ifhimg.orientation, ifhimg.mmppix, ifhimg.center, control);
		}
		sprintf (command, "ifh2hdr -r%.0fto%.0f %s", fmin, fmax, outfile);
		printf ("%s\n", command); status |= system (command);
		startrecle (outfile, argc, argv, rcsid, control);
		catrec (tmpfile);
		catrec (imgfile);
		endrec ();
	}

	if (save_pcorr) {
/*****************************************************/
/* compute and save partial correlation coefficients */
/*****************************************************/
		sprintf (outroot, "%s_%s", imgroot, ptrail);
		sprintf (outfile, "%s.4dfp.img", outroot);
		fmin = FLT_MAX; fmax = -fmin;
		for (j = 0; j < ncol; j++) for (jndex = 0; jndex < vdim; jndex++) {
			if (!imgn[jndex] || imgc[jndex]) {
				imgp[j][jndex] = 1.e-37;
			} else {
				imgp[j][jndex] = MIN (imgp[j][jndex], +1.);
				imgp[j][jndex] = MAX (imgp[j][jndex], -1.);
				fmin = MIN (fmin, imgp[j][jndex]);
				fmax = MAX (fmax, imgp[j][jndex]);
			}
		}
		printf ("Writing: %s\n", outfile);
		printf ("Max = %10.6f,\tMin = %10.6f\n", fmax, fmin);
		if (!(outfp = fopen (outfile, "wb")) || ewrite (imgp[0], vdim*ncol, control, outfp)
		|| fclose (outfp)) errw (program, outfile);
		imgdim[3] = ncol;
		if (conc_flag) {
			writeifhmce (program, outfile, imgdim,
				conc_block.voxdim, conc_block.orient, conc_block.mmppix, conc_block.center, control);
		} else {
			writeifhmce (program, outfile, imgdim,
				ifhimg.scaling_factor, ifhimg.orientation, ifhimg.mmppix, ifhimg.center, control);
		}
		sprintf (command, "ifh2hdr -r-1to1 %s", outfile);
		printf ("%s\n", command); status |= system (command);
		startrecle (outfile, argc, argv, rcsid, control);
		catrec (tmpfile);
		catrec (imgfile);
		endrec ();
	}

DONE: 	remove (tmpfile);
	if (conc_flag) {
		conc_free (&conc_block);
	} else {
		if (fclose (imgfp)) errr (program, imgfile);
	}
	free (format);
	free_double2 (f); free_double2 (g); free (sigma);
	if (ginvt_flag || save_pcorr) {
		free_double2 (a); free_double2 (ainv); free_double2 (ginvt);
		free_double2 (e); free_double2 (w); free_float2 (beta);
	}
	if (save_pcorr) {
		free_double2 (omega);
		free_float2 (imgp);
	}
	if (imgr_flag) free_float2 (imgr);
	free (imgt); free (imga); free (imgv); free (imgn); free (imgc);

	exit (status);
}
