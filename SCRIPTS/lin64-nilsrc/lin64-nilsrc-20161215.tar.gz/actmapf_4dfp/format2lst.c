/*$Header: /data/petsun4/data1/src_solaris/actmapf_4dfp/RCS/format2lst.c,v 1.8 2016/12/07 02:23:19 avi Exp $*/
/*$Log: format2lst.c,v $
 * Revision 1.8  2016/12/07  02:23:19  avi
 * handle fmtfile formats of arbitrary length
 *
 * Revision 1.7  2016/06/12  00:08:31  avi
 * <format|fmtfile>
 *
 * Revision 1.6  2009/07/30  05:42:08  avi
 * linux compliant
 *
 * Revision 1.5  2005/08/30  21:52:22  avi
 * expanded format buffer size increased to 16384 chars
 *
 * Revision 1.4  2005/08/30  07:05:12  avi
 * -e option
 *
 * Revision 1.3  2004/05/16  01:11:54  avi
 * -w option
 *
 * Revision 1.2  1999/04/17  05:22:31  avi
 * correct MAXL (256)
 *
 * Revision 1.1  1999/04/16  05:15:19  avi
 * Initial revision
 **/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>			/* getpid (); R_OK */

#define	MAXL	256

/*************/
/* externals */
/*************/
extern int	expandf (char *string, int len);

void errm (char* program) {
	fprintf (stderr, "%s: memory allocation error\n", program);
	exit (-1);
}

void errr (char* program, char* filespc) {
	fprintf (stderr, "%s: %s read error\n", program, filespc);
	exit (-1);
}


static char rcsid[] = "$Id: format2lst.c,v 1.8 2016/12/07 02:23:19 avi Exp $";
int main (int argc, char *argv[]) {
	FILE		*fmtfp;
	char		*format, fmtspc[2*MAXL];
	long		ipos;
	int		nexpand;

/***********/
/* utility */
/***********/
	char		command[MAXL], *ptr, *fmtptr, program[MAXL];
	int		c, i, j, k, n;

/*********/
/* flags */
/*********/
	int		expand = 0;
	int		wei_flag = 0;
	int		debug = 0;

	if (ptr = strrchr (argv[0], '/')) ptr++; else ptr = argv[0];
	strcpy (program, ptr);

/************************/
/* process command line */
/************************/
	for (k = 0, i = 1; i < argc; i++) {
		if (*argv[i] == '-') {
			strcpy (command, argv[i]); ptr = command;
			while (c = *ptr++) switch (c) {
				case 'e': expand++;		break;
				case 'w': wei_flag++;		break;
				case 'd': debug++;		break;
			}
		}
		else switch (k) {
			case 0:	strncpy (fmtspc, argv[i], MAXL);
				fmtptr = argv[i];		k++; break;
		}	
	}
	if (k < 1) {
		printf ("Usage:\t%s <format|fmtfile>\n", program);
		printf ("e.g.,\t%s \"2x3-2+1-2+2-2+1-1+2-1+1-1+1-1+2-1+1-1+1-2+2-1+1-1+2-2+1-2+2-\"\n", program);
		printf ("\toptions\n");
		printf ("\t-w\tconvert {'x' '+' '-'} to {0.0 1.0 -1.0}\n");
		printf ("\t-e\texpand on single line\n");
		exit (1);
	}

	if (!(format = (char *) calloc (4*MAXL + 1, sizeof (char)))) errm (program);
	if (!access (fmtspc, R_OK)) {		/* is a file */
/***********************************/
/* read format from specified file */
/***********************************/
		if (!(fmtfp = fopen (fmtspc, "r"))) errr (program, fmtspc);
		fseek (fmtfp, 0l, SEEK_END);
		k = ftell (fmtfp) + 1;
		if (!(format = (char *) realloc ((void *) format, k*sizeof (char)))) errm (program);
		rewind (fmtfp);
		if (!(fgets (format, k, fmtfp))) errr (program, fmtspc);
		fclose (fmtfp);
	} else {
		strncpy (format, fmtptr, 4*MAXL);
	}
	nexpand = expandf (format, 0);	/* 0 flag means report expanded format length */
	if (nexpand == 1 || nexpand == -1) exit (-1);
	if (debug) printf("#nexpand=%d\n", nexpand);

	if (!(format = (char *) realloc (format, (nexpand + 1)*sizeof (char)))) errm (program);
	if (debug) printf ("#format=%s\n", format);
	if (expandf (format, nexpand + 1)) exit (-1);
	n = strlen (format);
	if (debug) printf("#n=%d\n", n);
	for (i = 0; i < n; i++) {
		if (wei_flag) {
			switch (format[i]) {
				case '+':	printf ("1.0");		break;
				case '-': 	printf ("-1.0");	break;
				default:	printf ("0.0");		break;
			}
		} else {
			printf ("%c", format[i]);
		}
		if (!expand) printf ("\n");
	}
	exit (0);
}
