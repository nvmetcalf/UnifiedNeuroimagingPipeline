"""
Precision functional mapping (PFM): template matching via
/gpfs/data/siegellab/PFM_tools/run_template_matching_v2.m

Inputs per session (frames censored with the pipeline's own temporal mask):
    InProcess/<sid>/Functional/Surface/<sid>_rsfMRI_<variant>.dtseries.nii
    InProcess/<sid>/Functional/TemporalMask/rsfMRI_tmask.txt        (1 = kept)
    [optional] InProcess/<sid>/Functional/Surface/rest_frames.txt   (1 = rest frame)

Two modes
  per-session : run_template_matching_v2(InProcess, <sid>, 'Runs', {<sid>})
                outputs: InProcess/<sid>/Functional/Surface/TemplateMatching/
  pooled      : all selected sessions of a subject are concatenated (weighted
                correlation over the concatenated series).  The script names its
                outputs after `session`, so pooled runs use a pseudo-session
                Projects/<proj>/TemplateMatching/<Subject>_pooled<N>/ whose
                Anatomical/ links to the first session's (same subject, same
                surfaces), keeping pooled and single-session results apart.

The GUI never passes Overwrite=true: for the HCP atlas that would delete the
SHARED group seed matrix.  "Rerun" instead deletes only this run's outputs and
its concatenated dconn before calling the script.
"""
import os
import re
import shlex

ATLASES = {
    "HCP_networks_wSCAN": ['Default', 'Visual', 'FrontoParietal', 'MedialVisual', 'DorsalAttention',
                           'Premotor', 'Language', 'Salience', 'ActionMode', 'SomatomotorHand', 'SomatomotorFace',
                           'Auditory', '', '', 'ParietalMemory', 'ContextualAssociation', 'SomatomotorFoot', 'SCAN'],
    "GLnets": ['DMN', 'Vis', 'FP', '', 'DAN', '', 'VAN', 'Sal', 'CO', 'SMd', 'SMl', 'Aud', 'Tpole', 'MTL',
               'PMN', 'PON'],
}
DEFAULT_VARIANT = "uout_bpss_sr_sm2.ctx"


def pfm_dir(cfg):
    return cfg.get("pfm_tools_dir") or "/gpfs/data/siegellab/PFM_tools"


def tm_script(cfg):
    return cfg.get("pfm_tm_script") or "run_template_matching_v2"


def variants(sdir, sid):
    """dtseries variants available for TM: the <variant> in <sid>_rsfMRI_<variant>.dtseries.nii"""
    d = os.path.join(sdir, "Functional", "Surface")
    out = []
    try:
        for n in sorted(os.listdir(d)):
            m = re.match(rf"^{re.escape(sid)}_rsfMRI_(.+)\.dtseries\.nii$", n)
            if m:
                out.append(m.group(1))
    except OSError:
        pass
    return out


def dtseries_path(sdir, sid, variant):
    return os.path.join(sdir, "Functional", "Surface", f"{sid}_rsfMRI_{variant}.dtseries.nii")


def tmask_path(sdir):
    return os.path.join(sdir, "Functional", "TemporalMask", "rsfMRI_tmask.txt")


def rest_frames_path(sdir):
    return os.path.join(sdir, "Functional", "Surface", "rest_frames.txt")


def out_dir(session_dir):
    return os.path.join(session_dir, "Functional", "Surface", "TemplateMatching")


def outputs(session_dir, session, atlas):
    d = out_dir(session_dir)
    base = os.path.join(d, f"{session}_TM_{atlas}")
    return {"mat": base + "_Zscored.mat", "assign": base + "_assignments.dscalar.nii",
            "clean": base + "_assignments_clean.dscalar.nii", "eta": base + "_eta.dscalar.nii",
            "concat_dir": os.path.join(d, "Concat")}


def session_status(sdir, sid):
    """{atlas: {'done': bool, 'mtime': str}} for single-session TM outputs."""
    import time
    st = {}
    for a in ATLASES:
        o = outputs(sdir, sid, a)
        if os.path.isfile(o["clean"]):
            st[a] = {"done": True, "mtime": time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(o["clean"]))),
                     "clean": o["clean"]}
        elif os.path.isfile(o["mat"]):
            st[a] = {"done": False, "partial": True}
    return st


def pooled_root(cfg, project):
    return os.path.join(cfg.projects_root, project, "TemplateMatching")


def pooled_name(subject, n):
    return f"{subject}_pooled{n}"


def list_pooled(cfg, project):
    """[{name, dir, atlases:{...}, sessions:[...]}] for existing pooled pseudo-sessions."""
    root = pooled_root(cfg, project)
    out = []
    try:
        names = sorted(os.listdir(root))
    except OSError:
        return out
    for n in names:
        d = os.path.join(root, n)
        if not os.path.isdir(d):
            continue
        sess = []
        try:
            with open(os.path.join(d, "sessions.txt")) as fh:
                sess = [l.strip() for l in fh if l.strip()]
        except OSError:
            pass
        out.append({"name": n, "dir": d, "atlases": session_status(d, n), "sessions": sess})
    return out


# ---------------------------------------------------------------------------
# job script
# ---------------------------------------------------------------------------
def _mstr(s):
    return "'" + str(s).replace("'", "''") + "'"


def build_matlab_driver(cfg, study_root, session, run_specs, atlas, rest_only, work_dir):
    """MATLAB code: per run, combine tmask (and rest_frames) into one weights file,
    then call run_template_matching_v2(..., 'Runs', runs, 'Atlas', atlas)."""
    lines = ["runs = {};"]
    for i, r in enumerate(run_specs, 1):
        w = os.path.join(work_dir, f"run{i}_weights.txt")
        lines += [
            f"tm = readmatrix({_mstr(r['tmask'])}, 'FileType','text'); tm = tm(:); tm = tm(~isnan(tm));",
        ]
        if rest_only:
            lines += [
                f"rf = readmatrix({_mstr(r['rest'])}, 'FileType','text'); rf = rf(:); rf = rf(~isnan(rf));",
                f"assert(numel(rf)==numel(tm), 'run {i}: rest_frames (%d) and tmask (%d) lengths differ', numel(rf), numel(tm));",
                "tm = double(tm>0 & rf>0);",
            ]
        lines += [
            f"fprintf('run {i}: %s  kept %d of %d frames\\n', {_mstr(r['sid'])}, sum(tm>0), numel(tm));",
            f"writematrix(tm, {_mstr(w)}, 'FileType','text');",
            f"runs{{end+1}} = struct('dtseries', {_mstr(r['dtseries'])}, 'tmask', {_mstr(w)});",
        ]
    lines += [
        f"cd({_mstr(pfm_dir(cfg))});",
        f"addpath({_mstr(pfm_dir(cfg))});",
        f"{tm_script(cfg)}({_mstr(study_root)}, {_mstr(session)}, 'Runs', runs, 'Atlas', {_mstr(atlas)});",
    ]
    return "\n".join(lines) + "\n"


def build_job(cfg, project, sessions, atlas, variant, pooled, rest_only, rerun, slurm_opts, out_log_dir, sbatch_header):
    """Return (name, sid_label, script_text, info).  sessions: list of (subject, sid)."""
    inproc = os.path.join(cfg.projects_root, project, "InProcess")
    subject = sessions[0][0]
    run_specs = []
    for _, sid in sessions:
        sdir = os.path.join(inproc, sid)
        run_specs.append({"sid": sid, "dtseries": dtseries_path(sdir, sid, variant),
                          "tmask": tmask_path(sdir), "rest": rest_frames_path(sdir)})
    if pooled:
        study_root = pooled_root(cfg, project)
        session = pooled_name(subject, len(sessions))
        session_dir = os.path.join(study_root, session)
    else:
        study_root = inproc
        session = sessions[0][1]
        session_dir = os.path.join(inproc, session)
    o = outputs(session_dir, session, atlas)
    tag = f"{session}_concat{len(run_specs)}runs"
    work = os.path.join(out_dir(session_dir), "unpgui_inputs")
    name = f"TM_{project}_{session}_{atlas}"
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", f"{session}_{atlas}")
    out = os.path.join(out_log_dir, f"{safe}_TM_%j.out")
    err = os.path.join(out_log_dir, f"{safe}_TM_%j.err")
    s = slurm_opts
    lines = sbatch_header(name, out, err, s.get("tm_partition", "cpu_short"), s.get("tm_cpus", 4),
                          s.get("tm_mem", "150G"), s.get("tm_time", "12:00:00"))
    q = shlex.quote
    lines += ["", f"umask {cfg.get('umask', '002')}",
              'START_TIME=$(date)',
              'SLURM_LOG=$(scontrol show job "$SLURM_JOB_ID" 2>/dev/null | sed -n "s/.*StdOut=//p" | head -1)',
              'echo "UNP_GUI template matching job $SLURM_JOB_ID on $(hostname) started $START_TIME"',
              f'echo "session={session} atlas={atlas} variant={variant} pooled={int(pooled)} rest_only={int(rest_only)}"']
    for line in cfg.get("tm_prologue") or ["module load matlab/R2024a"]:
        lines.append(line)
    # input checks
    for r in run_specs:
        lines += [f"[ -f {q(r['dtseries'])} ] || {{ echo 'missing {r['dtseries']}'; exit 3; }}",
                  f"[ -f {q(r['tmask'])} ] || {{ echo 'missing {r['tmask']}'; exit 3; }}"]
        if rest_only:
            lines += [f"[ -f {q(r['rest'])} ] || {{ echo 'missing {r['rest']}'; exit 3; }}"]
    if pooled:
        lines += [f"mkdir -p {q(os.path.join(session_dir, 'Functional', 'Surface'))} {q(os.path.join(session_dir, 'QC'))}",
                  f"printf '%s\\n' {' '.join(q(sid) for _, sid in sessions)} > {q(os.path.join(session_dir, 'sessions.txt'))}"]
    # the script derives surfaces as <study_root>/<session>/Anatomical/Surface/MNI152_T1_1mm_32k/<session>.*
    if pooled:
        first_sid = sessions[0][1]
        sd = os.path.join(session_dir, "Anatomical")
        lines += [
            "# surfaces must be named after the pseudo-session: link them under its own folder",
            f"rm -f {q(sd)}; mkdir -p {q(os.path.join(sd, 'Surface', 'MNI152_T1_1mm_32k'))}",
            f"for f in {q(os.path.join(inproc, first_sid, 'Anatomical', 'Surface', 'MNI152_T1_1mm_32k'))}/{first_sid}.*; do "
            f"ln -sfn \"$f\" {q(os.path.join(sd, 'Surface', 'MNI152_T1_1mm_32k'))}/\"$(basename \"$f\" | sed 's/^{first_sid}\\./{session}./')\"; done",
        ]
    lines += [f"mkdir -p {q(work)}"]
    # stale concatenated inputs are always rebuilt (variant / mask may differ from last time)
    lines += [f"rm -f {q(os.path.join(o['concat_dir'], tag))}.dtseries.nii {q(os.path.join(o['concat_dir'], tag))}.dconn.nii "
              f"{q(os.path.join(o['concat_dir'], tag))}_tmask.txt"]
    if rerun:
        lines += [f"rm -f {q(o['mat'])} {q(o['assign'])} {q(o['clean'])} {q(o['eta'])} "
                  f"{q(o['mat'].replace('_Zscored.mat', '.mat'))} {q(o['mat'].replace('.mat', '.dscalar.nii'))}"]
    driver = os.path.join(work, f"tm_driver_{atlas}.m")
    mcode = build_matlab_driver(cfg, study_root, session, run_specs, atlas, rest_only, work)
    lines += [f"cat > {q(driver)} <<'UNPGUI_EOF'", mcode.rstrip("\n"), "UNPGUI_EOF",
              f"cd {q(pfm_dir(cfg))}",
              f"matlab -nodisplay -nosplash -r \"try; run('{driver}'); catch e; disp(getReport(e)); exit(1); end; exit(0)\"",
              "status=$?",
              f"[ -f {q(o['clean'])} ] || {{ echo 'UNP_GUI: cleaned assignments not produced'; [ $status = 0 ] && status=2; }}",
              f"chgrp -Rf {q(cfg.get('study_group') or '')} {q(out_dir(session_dir))} {q(out_log_dir)} 2>/dev/null",
              f"chmod -Rf g+rwX {q(out_dir(session_dir))} {q(out_log_dir)} 2>/dev/null",
              'echo "template matching finished status=$status ($(date))"']
    info = {"session": session, "session_dir": session_dir, "outputs": o, "runs": [r["sid"] for r in run_specs],
            "pooled": pooled, "atlas": atlas, "variant": variant}
    return name, session, lines, info
