#!/bin/bash
# fix_perms.sh - make UNP_GUI (and optionally other paths) group-owned by the lab
# group with group read/write, execute where needed, and setgid on directories so
# that new files inherit the group.
#
#   ./fix_perms.sh                       # fixes the UNP_GUI folder itself
#   ./fix_perms.sh /gpfs/data/siegellab/UnifiedNeuroimagingPipeline/Projects/Anhedonia
#
GROUP="${UNP_GUI_GROUP:-siegellab}"
GUI_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGETS=("$@"); [ ${#TARGETS[@]} -eq 0 ] && TARGETS=("$GUI_DIR")
for t in "${TARGETS[@]}"; do
    echo "== $t"
    chgrp -R "$GROUP" "$t" 2>&1 | grep -v "Operation not permitted" | head -5
    chmod -R g+rwX "$t" 2>&1 | grep -v "Operation not permitted" | head -5
    find "$t" -type d -exec chmod g+s {} + 2>/dev/null
    find "$t" -type f \( -name "*.sh" -o -name "*.py" -o -name "*.csh" -o -name "*.sbatch" \) -exec chmod g+x,u+x {} + 2>/dev/null
done
echo "done. Sample:"; ls -ld "${TARGETS[0]}"; ls -l "${TARGETS[0]}" | head -8
